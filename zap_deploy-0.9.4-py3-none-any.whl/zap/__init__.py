"""Zap — Docker deployment and GitHub release CLI."""

__version__ = "0.9.4"
