"""``zap clean`` / ``zc`` command.

Delete all data for one tenant from a ZAP Postgres database.

Two layouts are supported, mirroring ``deploy-scripts/cleanup-tenant.sh``:

* ``multi-schema`` — one schema per tenant (inventory, production).
  The tenant schema is dropped with ``CASCADE``.
* ``single-schema`` — one shared schema, rows scoped by ``tenant_id``
  (employee, payroll, zapfiles, booking). Every table is discovered
  dynamically from the catalog, FK dependencies order the deletes
  child-first, and FK triggers are disabled only when the live FK graph
  has cycles that ordering cannot resolve.

The YAML config carries only the database connection; the tenant comes
from ``--tenant`` so one file serves every tenant::

    zc db.yaml --tenant alzone --mode single-schema --schema-name employee
    zc db.yaml --tenant alzone --mode multi-schema --dry-run

A service deployment YAML (the same file ``zd`` deploys) works too. Mode
comes from ``env.TENANCY_STRATEGY`` and the schema defaults to
``zap.name`` without its ``-api`` suffix, both overridable::

    zc employee-api/deployments/staging.yaml --tenant alzone --dry-run
"""

from __future__ import annotations

import csv
import os
import re
import shutil
import subprocess
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Annotated, Any, Literal

import typer
from pydantic import BaseModel, ConfigDict, Field, field_validator
from rich.console import Console
from rich.table import Table

from .config import (
    ConfigError,
    DeploymentConfig,
    build_config,
    parse_raw,
    resolve_config,
    resolve_service_dir,
)
from .doppler import DopplerError, _doppler_sections, fetch_secrets

app = typer.Typer(
    name="clean",
    help="Delete all data for one tenant.",
    no_args_is_help=True,
)

console = Console()
err_console = Console(stderr=True)

TENANT_RE = re.compile(r"^[a-zA-Z][a-zA-Z0-9_-]{0,62}$")
PROTECTED_SCHEMAS = frozenset({"public", "information_schema"})


class CleanError(ConfigError):
    """Any tenant-cleanup precondition or step failure."""


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class DbConfig(_Strict):
    url: str
    user: str = ""
    password: str = ""
    connect_timeout: int = 10
    maintenance_db: str = ""


def trim_api_suffix(name: str) -> str:
    """Strip one trailing ``-api`` from a service name for the schema default."""
    return name[:-4] if name.endswith("-api") else name


def normalize_mode(value: str) -> Literal["single-schema", "multi-schema"]:
    """Accept ``SINGLE_SCHEMA``/``single-schema`` spellings for both modes."""
    compact = value.strip().lower().replace("_", "-")
    if compact in ("single-schema", "single"):
        return "single-schema"
    if compact in ("multi-schema", "multi"):
        return "multi-schema"
    raise CleanError(
        f"invalid mode {value!r}: expected single-schema or multi-schema "
        "(SINGLE_SCHEMA / MULTI_SCHEMA also accepted)"
    )


class TargetConfig(_Strict):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    mode: Literal["single-schema", "multi-schema"] = "multi-schema"
    schema_name: str = Field(default="", alias="schema")
    tenant: str = ""
    tenant_id: str = ""
    app_name: str = ""

    @field_validator("mode", mode="before")
    @classmethod
    def _normalize_mode(cls, v: object) -> object:
        if isinstance(v, str):
            try:
                return normalize_mode(v)
            except CleanError:
                return v
        return v


class BackupConfig(_Strict):
    enabled: bool = True
    dir: str = "backups/tenant-cleanup"


class MigrateConfig(_Strict):
    """Seed-migration settings consumed by ``zap seed`` (ignored by clean)."""

    changelog_dir: str = ""
    tenants_file: str = ""
    app_name: str = ""


class CleanConfig(_Strict):
    version: Literal[1] = 1
    db: DbConfig
    target: TargetConfig = Field(default_factory=TargetConfig)
    backup: BackupConfig = Field(default_factory=BackupConfig)
    migrate: MigrateConfig = Field(default_factory=MigrateConfig)


@dataclass(frozen=True)
class OwnedTable:
    """A table holding this tenant's rows plus its tenant predicate."""

    name: str
    predicate: str
    depth: int


def clean_config_from_deployment(
    deploy_cfg: DeploymentConfig,
    config_path: str | Path,
    env: Mapping[str, str] | None = None,
) -> CleanConfig:
    """Derive a clean config from a service deployment config.

    Mode comes from ``env.TENANCY_STRATEGY``; the schema defaults to
    ``zap.name`` without its ``-api`` suffix in single-schema mode and
    stays empty (tenant name is used) in multi-schema mode. Migration
    paths follow the standard service layout around the config file.
    The maintenance database is ``DB_NAME`` from the YAML ``env:`` block,
    else from *env* (process environment merged with Doppler secrets).
    """
    env_map = deploy_cfg.env
    url = (
        env_map.get("DB_URL")
        or env_map.get("DB_JDBC_URL")
        or env_map.get("DB_DIRECT_URL")
        or ""
    )
    if not url:
        raise CleanError(
            "deployment config has no DB_URL (or DB_JDBC_URL/DB_DIRECT_URL) in env:"
        )
    raw_mode = (env_map.get("TENANCY_STRATEGY") or "").strip()
    if not raw_mode:
        raise CleanError(
            "deployment config has no TENANCY_STRATEGY in env: "
            "pass --mode explicitly."
        )
    mode = normalize_mode(raw_mode)
    service = deploy_cfg.zap.name
    schema_default = trim_api_suffix(service) if mode == "single-schema" else ""
    service_dir = resolve_service_dir(config_path, deploy_cfg.zap.service_dir)
    changelog_dir = service_dir / "src/main/resources/db/changelog"
    tenants_file = Path(config_path).resolve().parent / "tenants.properties"
    if not tenants_file.is_file():
        tenants_file = service_dir / "deployments/tenants.properties"
    return CleanConfig(
        version=1,
        db=DbConfig(
            url=url,
            user=env_map.get("DB_USER") or env_map.get("DB_USERNAME") or "",
            password=env_map.get("DB_PASS")
            or env_map.get("DB_PASSWORD")
            or env_map.get("DB_PWD")
            or "",
            maintenance_db=env_map.get("DB_NAME") or (env or {}).get("DB_NAME") or "",
        ),
        target=TargetConfig(mode=mode, schema=schema_default, app_name=service),
        migrate=MigrateConfig(
            changelog_dir=str(changelog_dir) if changelog_dir.is_dir() else "",
            tenants_file=str(tenants_file) if tenants_file.is_file() else "",
            app_name=service,
        ),
    )


def resolve_effective_config(config_file: str | Path) -> CleanConfig:
    """Load a zapclean (``db:``) or deployment (``zap:``) config as one CleanConfig."""
    try:
        raw = parse_raw(config_file)
    except ConfigError as exc:
        raise CleanError(str(exc)) from exc
    if "db" in raw:
        return load_clean_config(config_file)
    if "zap" in raw:
        secrets: dict[str, str] = {}
        for project, dconfig in _doppler_sections(raw):
            try:
                fetched = fetch_secrets(project, dconfig)
            except DopplerError as exc:
                raise CleanError(
                    f"doppler fetch failed ({project} / {dconfig}): {exc}"
                ) from exc
            secrets.update(fetched)
        merged_env = {**os.environ, **secrets}
        try:
            deploy_cfg = build_config(raw, merged_env)
        except ConfigError as exc:
            raise CleanError(f"deployment config error: {exc}") from exc
        return clean_config_from_deployment(deploy_cfg, config_file, merged_env)
    raise CleanError(
        "config has neither 'db:' (zapclean) nor 'zap:' (deployment) sections."
    )


def load_clean_config(path: str | Path, env: dict[str, str] | None = None) -> CleanConfig:
    """Load, interpolate, and validate a zapclean YAML config file."""
    raw = parse_raw(path)
    try:
        resolved = resolve_config(raw, env if env is not None else os.environ)
    except ConfigError as exc:
        raise CleanError(f"interpolation error: {exc}") from exc
    try:
        return CleanConfig.model_validate(resolved)
    except Exception as exc:
        raise CleanError(f"config validation failed:\n{exc}") from exc


def normalize_db_url(url: str) -> str:
    """Strip a JDBC prefix so the URL is usable as a libpq conninfo."""
    cleaned = url.strip()
    if cleaned.startswith("jdbc:"):
        cleaned = cleaned.removeprefix("jdbc:")
    if cleaned.startswith(("postgresql://", "postgres://")):
        return cleaned
    raise CleanError(
        "unsupported db.url: expected a PostgreSQL JDBC or libpq URL "
        "(jdbc:postgresql://... or postgresql://...)"
    )


def is_valid_identifier(value: str) -> bool:
    """Tenant ids and schema names share one strict shape."""
    return TENANT_RE.fullmatch(value) is not None


def ensure_safe_identifier(value: str, kind: str) -> str:
    """Validate a tenant id and return it, raising on mismatch."""
    if not is_valid_identifier(value):
        raise CleanError(f"invalid {kind}: {value!r}")
    return value


def ensure_safe_schema(schema: str) -> str:
    """Validate a schema name and refuse protected schemas."""
    ensure_safe_identifier(schema, "schema")
    lowered = schema.lower()
    if lowered in PROTECTED_SCHEMAS or lowered.startswith("pg_"):
        raise CleanError(f"refusing protected schema: {schema}")
    return schema


def quote_ident(name: str) -> str:
    """Quote a catalog identifier for dynamic SQL."""
    return '"' + name.replace('"', '""') + '"'


def safe_filename(value: str) -> str:
    """Make a catalog name safe for use as a file name."""
    return re.sub(r"[^A-Za-z0-9_.-]", "_", value)


def host_label(url: str) -> str:
    """Filesystem-safe ``host`` (plus port) label parsed from a db URL."""
    cleaned = url.strip()
    if cleaned.startswith("jdbc:"):
        cleaned = cleaned[len("jdbc:") :]
    host = cleaned.split("://", 1)[-1].split("/", 1)[0]
    return safe_filename(host) or "unknown-host"


def backup_base_dir(backup_root: Path, host: str, db_name: str) -> Path:
    """Backup root namespaced as ``<root>/<host>/<db>``."""
    return backup_root / host / db_name


def topo_delete_order(
    tables: list[str], edges: list[tuple[str, str]]
) -> tuple[list[str], list[str]]:
    """Order tables child-first for deletes using Kahn's algorithm.

    ``edges`` holds ``(child, parent)`` FK pairs inside one schema.
    A table is deletable once no remaining table references it, so the
    result deletes children before parents. Returns ``(order, cycles)``
    where ``cycles`` holds nodes no ordering could place.
    """
    wanted = set(tables)
    children_of: dict[str, set[str]] = {t: set() for t in tables}
    for child, parent in edges:
        if child in wanted and parent in wanted and child != parent:
            children_of[parent].add(child)
    remaining = set(tables)
    order: list[str] = []
    while remaining:
        ready = sorted(t for t in remaining if not (children_of[t] & remaining))
        if not ready:
            break
        order.extend(ready)
        remaining.difference_update(ready)
    cycles = sorted(remaining)
    return order, cycles


def delete_statement(schema: str, table: str, predicate: str) -> str:
    """Render one tenant-scoped DELETE with the ``t`` alias bound."""
    resolved = predicate.replace("{alias}", "t")
    return f"DELETE FROM {quote_ident(schema)}.{quote_ident(table)} t WHERE {resolved};"


def count_statement(schema: str, table: str, predicate: str) -> str:
    """Render one tenant-scoped row count with the ``t`` alias bound."""
    resolved = predicate.replace("{alias}", "t")
    return f"SELECT count(*) FROM {quote_ident(schema)}.{quote_ident(table)} t WHERE {resolved}"


def disable_triggers_sql(schema: str) -> str:
    """Disable every trigger (including FK enforcement) in one schema."""
    return (
        "DO $$ DECLARE r RECORD; BEGIN FOR r IN SELECT schemaname, tablename "
        f"FROM pg_tables WHERE schemaname = '{schema}' LOOP EXECUTE "
        "format('ALTER TABLE %I.%I DISABLE TRIGGER ALL', "
        "r.schemaname, r.tablename); END LOOP; END $$;"
    )


def enable_triggers_sql(schema: str) -> str:
    """Re-enable every trigger in one schema."""
    return (
        "DO $$ DECLARE r RECORD; BEGIN FOR r IN SELECT schemaname, tablename "
        f"FROM pg_tables WHERE schemaname = '{schema}' LOOP EXECUTE "
        "format('ALTER TABLE %I.%I ENABLE TRIGGER ALL', "
        "r.schemaname, r.tablename); END LOOP; END $$;"
    )


def disable_user_triggers_sql(schema: str) -> str:
    return (
        "DO $$ DECLARE r RECORD; BEGIN FOR r IN SELECT schemaname, tablename "
        f"FROM pg_tables WHERE schemaname = '{schema}' LOOP EXECUTE "
        "format('ALTER TABLE %I.%I DISABLE TRIGGER USER', "
        "r.schemaname, r.tablename); END LOOP; END $$;"
    )


def enable_user_triggers_sql(schema: str) -> str:
    return (
        "DO $$ DECLARE r RECORD; BEGIN FOR r IN SELECT schemaname, tablename "
        f"FROM pg_tables WHERE schemaname = '{schema}' LOOP EXECUTE "
        "format('ALTER TABLE %I.%I ENABLE TRIGGER USER', "
        "r.schemaname, r.tablename); END LOOP; END $$;"
    )


def utc_stamp() -> str:
    """Compact UTC timestamp used for backup directory names."""
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def connect(cfg: CleanConfig) -> Any:
    """Open a psycopg connection from a clean config."""
    import psycopg

    url = normalize_db_url(cfg.db.url)
    kwargs: dict[str, Any] = {"conninfo": url}
    if cfg.db.user:
        kwargs["user"] = cfg.db.user
    if cfg.db.password:
        kwargs["password"] = cfg.db.password
    kwargs["connect_timeout"] = cfg.db.connect_timeout
    return psycopg.connect(**kwargs)


def schema_exists(conn: Any, schema: str) -> bool:
    """Check that a schema exists in the connected database."""
    with conn.cursor() as cur:
        cur.execute("SELECT EXISTS (SELECT 1 FROM pg_namespace WHERE nspname = %s)", (schema,))
        row = cur.fetchone()
    return bool(row is not None and row[0])


def registry_exists(conn: Any) -> bool:
    """Check for the cross-tenant ``public.tenant_registry`` table."""
    with conn.cursor() as cur:
        cur.execute("SELECT to_regclass('public.tenant_registry') IS NOT NULL")
        row = cur.fetchone()
    return bool(row is not None and row[0])


def current_database(conn: Any) -> str:
    """Return the connected database name for backup paths."""
    with conn.cursor() as cur:
        cur.execute("SELECT current_database()")
        row = cur.fetchone()
    return str(row[0]) if row else "unknown"


def list_schema_tables(conn: Any, schema: str) -> list[str]:
    """List every base table in one schema, ordered by name."""
    with conn.cursor() as cur:
        cur.execute(
            "SELECT table_name FROM information_schema.tables "
            "WHERE table_type = 'BASE TABLE' AND table_schema = %s ORDER BY table_name",
            (schema,),
        )
        rows = cur.fetchall()
    return [str(r[0]) for r in rows]


def count_table(conn: Any, schema: str, table: str) -> int:
    """Count every row in one schema-qualified table."""
    with conn.cursor() as cur:
        cur.execute(f"SELECT count(*) FROM {quote_ident(schema)}.{quote_ident(table)}")
        row = cur.fetchone()
    return int(row[0]) if row else 0


def fetch_fk_edges(conn: Any, schema: str) -> list[tuple[str, str]]:
    """Fetch ``(child, parent)`` FK pairs wholly inside one schema."""
    with conn.cursor() as cur:
        cur.execute(
            "SELECT child.relname, parent.relname "
            "FROM pg_constraint con "
            "JOIN pg_class child ON child.oid = con.conrelid "
            "JOIN pg_namespace child_ns ON child_ns.oid = child.relnamespace "
            "JOIN pg_class parent ON parent.oid = con.confrelid "
            "JOIN pg_namespace parent_ns ON parent_ns.oid = parent.relnamespace "
            "WHERE con.contype = 'f' AND child_ns.nspname = %s "
            "AND parent_ns.nspname = %s",
            (schema, schema),
        )
        rows = cur.fetchall()
    return [(str(c), str(p)) for c, p in rows]


def fetch_fk_columns(cur: Any, schema: str) -> list[tuple[str, str, str, str, bool]]:
    """Every FK member column as (constraint, child, column, parent, nullable)."""
    cur.execute(
        "SELECT con.conname, child.relname, ca.attname, parent.relname, "
        "CASE WHEN cols.is_nullable = 'YES' THEN true ELSE false END "
        "FROM pg_constraint con "
        "JOIN pg_class child ON child.oid = con.conrelid "
        "JOIN pg_namespace child_ns ON child_ns.oid = child.relnamespace "
        "JOIN pg_class parent ON parent.oid = con.confrelid "
        "JOIN pg_namespace parent_ns ON parent_ns.oid = parent.relnamespace "
        "JOIN LATERAL unnest(con.conkey) AS ck(attnum) ON true "
        "JOIN pg_attribute ca ON ca.attrelid = child.oid AND ca.attnum = ck.attnum "
        "JOIN information_schema.columns cols ON cols.table_schema = child_ns.nspname "
        "AND cols.table_name = child.relname AND cols.column_name = ca.attname "
        "WHERE con.contype = 'f' AND child_ns.nspname = %s AND parent_ns.nspname = %s",
        (schema, schema),
    )
    rows = cur.fetchall()
    return [(str(a), str(b), str(c), str(d), bool(e)) for a, b, c, d, e in rows]


def cycle_break_updates(
    by_name: dict[str, OwnedTable],
    cycles: list[str],
    columns: list[tuple[str, str, str, str, bool]],
) -> tuple[list[tuple[str, list[str]]], set[tuple[str, str]]]:
    """Plan UPDATEs nulling nullable FKs between cycle members.

    Returns ([(child, [columns])], broken {(child, parent)} edges). A NULL in
    any MATCH SIMPLE FK member exempts the row, so one nulled column per
    constraint breaks that edge.
    """
    cset = set(cycles)
    per_child: dict[str, set[str]] = {}
    broken: set[tuple[str, str]] = set()
    for _con, child, column, parent, nullable in columns:
        if child in cset and parent in cset and child != parent and nullable and child in by_name:
            per_child.setdefault(child, set()).add(column)
            broken.add((child, parent))
    plans = [(child, sorted(cols)) for child, cols in sorted(per_child.items())]
    return plans, broken


def fetch_owned_tables(conn: Any, schema: str, tenant_id: str) -> list[OwnedTable]:
    """Discover tenant-owned tables and their tenant predicates.

    Tables carrying ``tenant_id`` are owned directly. Tables reachable
    through FKs from an owned table are owned transitively and get an
    ``EXISTS`` predicate against their tenant-owned ancestor.
    """
    ensure_safe_schema(schema)
    ensure_safe_identifier(tenant_id, "tenant id")
    tenant_literal = tenant_id.replace("'", "''")
    ownership_sql = (
        "WITH RECURSIVE tenant_tables AS ("
        " SELECT DISTINCT c.table_name::text AS table_name"
        " FROM information_schema.columns c"
        " JOIN information_schema.tables t"
        " ON t.table_schema = c.table_schema AND t.table_name = c.table_name"
        f" WHERE c.table_schema = '{schema}' AND c.column_name = 'tenant_id'"
        " AND t.table_type = 'BASE TABLE'),"
        " fk_edges AS ("
        " SELECT child.relname::text AS child_table,"
        " parent.relname::text AS parent_table,"
        " string_agg(format('{child}.%I = {parent}.%I', ca.attname, pa.attname),"
        " ' AND ' ORDER BY keys.ord) AS join_template"
        " FROM pg_constraint con"
        " JOIN pg_class child ON child.oid = con.conrelid"
        " JOIN pg_namespace child_ns ON child_ns.oid = child.relnamespace"
        " JOIN pg_class parent ON parent.oid = con.confrelid"
        " JOIN pg_namespace parent_ns ON parent_ns.oid = parent.relnamespace"
        " CROSS JOIN LATERAL unnest(con.conkey, con.confkey)"
        " WITH ORDINALITY AS keys(child_attnum, parent_attnum, ord)"
        " JOIN pg_attribute ca ON ca.attrelid = child.oid AND ca.attnum = keys.child_attnum"
        " JOIN pg_attribute pa ON pa.attrelid = parent.oid AND pa.attnum = keys.parent_attnum"
        f" WHERE con.contype = 'f' AND child_ns.nspname = '{schema}'"
        f" AND parent_ns.nspname = '{schema}'"
        " GROUP BY child.relname, parent.relname, con.oid),"
        " owned(table_name, predicate, depth, path) AS ("
        f" SELECT table_name, format('{{alias}}.tenant_id = %L', '{tenant_literal}') COLLATE \"default\", 0,"
        " ARRAY[table_name] FROM tenant_tables UNION ALL"
        " SELECT edge.child_table,"
        f" format('EXISTS (SELECT 1 FROM {quote_ident(schema)}.%I p%s WHERE %s AND (%s))',"
        " edge.parent_table, owned.depth + 1,"
        " replace(replace(edge.join_template, '{child}', '{alias}'),"
        " '{parent}', format('p%s', owned.depth + 1)),"
        " replace(owned.predicate, '{alias}', format('p%s', owned.depth + 1))) COLLATE \"default\","
        " owned.depth + 1, owned.path || edge.child_table"
        " FROM owned JOIN fk_edges edge ON edge.parent_table = owned.table_name"
        " WHERE NOT edge.child_table = ANY(owned.path)"
        " AND NOT EXISTS (SELECT 1 FROM tenant_tables tt WHERE tt.table_name = edge.child_table))"
        " SELECT table_name, string_agg(DISTINCT '(' || predicate || ')', ' OR '), max(depth)"
        " FROM owned GROUP BY table_name ORDER BY table_name"
    )
    with conn.cursor() as cur:
        cur.execute(ownership_sql)
        rows = cur.fetchall()
    owned: list[OwnedTable] = []
    for name, predicate, depth in rows:
        owned.append(OwnedTable(name=str(name), predicate=str(predicate), depth=int(depth)))
    return owned


def copy_query_to_csv(conn: Any, query: str, dest: Path) -> None:
    """Stream a ``COPY ... TO STDOUT`` query into a CSV file."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    with conn.cursor() as cur:
        with cur.copy(query) as copy:
            with dest.open("wb") as handle:
                while True:
                    block = copy.read()
                    if not block:
                        break
                    handle.write(bytes(block))


def copy_csv_to_table(conn: Any, schema: str, table: str, src: Path) -> None:
    """Stream a CSV file into a table via ``COPY ... FROM STDIN``."""
    with conn.cursor() as cur:
        with cur.copy(
            f"COPY {quote_ident(schema)}.{quote_ident(table)} "
            "FROM STDIN WITH (FORMAT CSV, HEADER)"
        ) as copy:
            with src.open("rb") as handle:
                while True:
                    block = handle.read(65536)
                    if not block:
                        break
                    copy.write(block)


def render_plan_table(
    title: str, rows: list[tuple[str, int]], order_note: str
) -> None:
    """Print the ordered delete plan with per-table row counts."""
    table = Table(title=title, show_lines=False)
    table.add_column("#", justify="right")
    table.add_column("table")
    table.add_column("rows", justify="right")
    for idx, (name, count) in enumerate(rows, start=1):
        table.add_row(str(idx), name, str(count))
    console.print(table)
    console.print(f"[dim]{order_note}[/dim]")


def confirm_destructive(value: str, assume_yes: bool) -> None:
    """Require typing the tenant/schema name unless ``--yes`` is given."""
    if assume_yes:
        return
    typed = typer.prompt(f"Type '{value}' to continue")
    if typed != value:
        raise typer.Exit(code=1)


def run_multi_schema(
    conn: Any,
    *,
    schema: str,
    app_name: str,
    dry_run: bool,
    assume_yes: bool,
    backup_root: Path | None,
    pg_url: str,
    db_user: str,
    db_password: str,
    host: str,
) -> None:
    """Drop one tenant schema and its registry mappings."""
    ensure_safe_schema(schema)
    if not schema_exists(conn, schema):
        raise CleanError(f"target schema '{schema}' does not exist")
    tables = list_schema_tables(conn, schema)
    counts = [(t, count_table(conn, schema, t)) for t in tables]
    total = sum(c for _, c in counts)
    render_plan_table(
        f"multi-schema cleanup: {schema} ({len(tables)} tables, {total} rows)",
        counts,
        "Deletes by DROP SCHEMA CASCADE; no FK ordering is needed.",
    )
    if dry_run:
        console.print("[bold green]Dry run — no changes made.[/bold green]")
        return
    confirm_destructive(schema, assume_yes)
    db_name = current_database(conn)
    if backup_root is not None:
        stamp = utc_stamp()
        backup_dir = backup_base_dir(backup_root, host, db_name) / schema / stamp
        backup_dir.mkdir(parents=True, exist_ok=True)
        with (backup_dir / "table-row-counts.csv").open(
            "w", encoding="utf-8", newline=""
        ) as handle:
            writer = csv.writer(handle)
            writer.writerow(["table_name", "row_count"])
            for name, count in counts:
                writer.writerow([name, count])
        if registry_exists(conn):
            filt = "schema_name = '" + schema.replace("'", "''") + "'"
            if app_name:
                filt += " AND application_name = '" + app_name.replace("'", "''") + "'"
            copy_query_to_csv(
                conn,
                "COPY (SELECT * FROM public.tenant_registry "
                f"WHERE {filt}) TO STDOUT WITH (FORMAT CSV, HEADER)",
                backup_dir / "tenant_registry.csv",
            )
        if shutil.which("pg_dump") and db_user:
            dump = backup_dir / "schema.dump"
            cmd = [
                "pg_dump",
                "--username",
                db_user,
                "--no-password",
                "--format=custom",
                f"--schema={schema}",
                "--file",
                str(dump),
                pg_url,
            ]
            dump_env = dict(os.environ)
            if db_password:
                dump_env["PGPASSWORD"] = db_password
            proc = subprocess.run(cmd, capture_output=True, text=True, env=dump_env)
            if proc.returncode != 0:
                err_console.print(f"[yellow]WARNING: pg_dump failed: {proc.stderr.strip()}[/yellow]")
            else:
                console.print(f"[green]Backup written to {backup_dir}[/green]")
        else:
            (backup_dir / "metadata.properties").write_text(
                f"created_at_utc={utc_stamp()}\nmode=multi-schema\n"
                f"host={host}\ndatabase={db_name}\ntarget_schema={schema}\n",
                encoding="utf-8",
            )
            console.print(f"[green]Backup written to {backup_dir}[/green]")
    with conn.cursor() as cur:
        cur.execute(f'DROP SCHEMA {quote_ident(schema)} CASCADE')
        if registry_exists(conn):
            if app_name:
                cur.execute(
                    "DELETE FROM public.tenant_registry "
                    "WHERE schema_name = %s AND application_name = %s",
                    (schema, app_name),
                )
            else:
                cur.execute(
                    "DELETE FROM public.tenant_registry WHERE schema_name = %s",
                    (schema,),
                )
    conn.commit()
    console.print(f"[bold green]Tenant schema '{schema}' was deleted.[/bold green]")


def run_single_schema(
    conn: Any,
    *,
    schema: str,
    tenant_id: str,
    app_name: str,
    dry_run: bool,
    assume_yes: bool,
    backup_root: Path | None,
    disable_triggers: str,
    host: str,
) -> None:
    """Delete one tenant's rows from a shared schema in FK-safe order."""
    if disable_triggers not in ("auto", "always", "never"):
        raise CleanError("--disable-triggers must be one of: auto, always, never")
    ensure_safe_schema(schema)
    ensure_safe_identifier(tenant_id, "tenant id")
    if not schema_exists(conn, schema):
        raise CleanError(f"target schema '{schema}' does not exist")
    owned = fetch_owned_tables(conn, schema, tenant_id)
    if not owned:
        raise CleanError(f"no tenant-owned tables found in schema '{schema}'")
    by_name = {t.name: t for t in owned}
    edges = [(c, p) for c, p in fetch_fk_edges(conn, schema) if c in by_name and p in by_name]
    order, cycles = topo_delete_order([t.name for t in owned], edges)
    ordered = order + cycles
    counts: list[tuple[str, int]] = []
    total = 0
    with conn.cursor() as cur:
        for name in ordered:
            cur.execute(count_statement(schema, name, by_name[name].predicate))
            row = cur.fetchone()
            found = int(row[0]) if row else 0
            counts.append((name, found))
            total += found
    note = "Delete order is child-first from the live FK graph."
    if cycles:
        note += f" {len(cycles)} table(s) form FK cycles and need triggers disabled: " + ", ".join(cycles)
    render_plan_table(
        f"single-schema cleanup: {tenant_id} in {schema} ({len(ordered)} tables, {total} rows)",
        counts,
        note,
    )
    if dry_run:
        console.print("[bold green]Dry run — no changes made.[/bold green]")
        return
    confirm_destructive(tenant_id, assume_yes)
    db_name = current_database(conn)
    if backup_root is not None:
        stamp = utc_stamp()
        backup_dir = (
            backup_base_dir(backup_root, host, db_name) / schema / f"tenant-{tenant_id}" / stamp
        )
        data_dir = backup_dir / "data"
        data_dir.mkdir(parents=True, exist_ok=True)
        with (backup_dir / "table-row-counts.csv").open(
            "w", encoding="utf-8", newline=""
        ) as handle:
            writer = csv.writer(handle)
            writer.writerow(["table_name", "row_count", "data_file"])
            for idx, (name, found) in enumerate(counts):
                data_file = f"{idx:03d}_{safe_filename(name)}.csv"
                predicate = by_name[name].predicate.replace("{alias}", "t")
                copy_query_to_csv(
                    conn,
                    f"COPY (SELECT t.* FROM {quote_ident(schema)}.{quote_ident(name)} t "
                    f"WHERE {predicate}) TO STDOUT WITH (FORMAT CSV, HEADER)",
                    data_dir / data_file,
                )
                writer.writerow([name, found, data_file])
        if registry_exists(conn):
            filt = "tenant_id = '" + tenant_id.replace("'", "''") + "'"
            if app_name:
                filt += " AND application_name = '" + app_name.replace("'", "''") + "'"
            copy_query_to_csv(
                conn,
                "COPY (SELECT * FROM public.tenant_registry "
                f"WHERE {filt}) TO STDOUT WITH (FORMAT CSV, HEADER)",
                backup_dir / "tenant_registry.csv",
            )
        (backup_dir / "metadata.properties").write_text(
            f"created_at_utc={stamp}\nmode=single-schema\n"
            f"host={host}\ndatabase={db_name}\ntarget_schema={schema}\ntenant_id={tenant_id}\n",
            encoding="utf-8",
        )
        console.print(f"[green]Backup written to {backup_dir}[/green]")
    needs_disable = disable_triggers == "always" or (disable_triggers == "auto" and bool(cycles))
    disabled = ""
    try:
        with conn.cursor() as cur:
            if needs_disable:
                cur.execute("SAVEPOINT zc_disable_all")
                try:
                    cur.execute(disable_triggers_sql(schema))
                    disabled = "all"
                    cur.execute("RELEASE SAVEPOINT zc_disable_all")
                except Exception as exc_all:
                    cur.execute("ROLLBACK TO SAVEPOINT zc_disable_all")
                    cur.execute("RELEASE SAVEPOINT zc_disable_all")
                    if disable_triggers == "always":
                        raise CleanError(
                            "disabling FK triggers failed: the database user needs "
                            f"trigger privileges on schema '{schema}': {exc_all}"
                        ) from exc_all
                    cur.execute("SAVEPOINT zc_disable_user")
                    try:
                        cur.execute(disable_user_triggers_sql(schema))
                        disabled = "user"
                        cur.execute("RELEASE SAVEPOINT zc_disable_user")
                    except Exception as exc_user:
                        cur.execute("ROLLBACK TO SAVEPOINT zc_disable_user")
                        cur.execute("RELEASE SAVEPOINT zc_disable_user")
                        err_console.print(
                            f"[yellow]WARNING: could not disable triggers ({exc_user}); "
                            "continuing with FK-ordered deletes.[/yellow]"
                        )
                    else:
                        err_console.print(
                            f"[yellow]WARNING: could not disable ALL triggers ({exc_all}); "
                            "disabled USER triggers only, FKs stay enforced.[/yellow]"
                        )
            final_order = ordered
            if cycles and disabled != "all":
                plans, broken = cycle_break_updates(
                    by_name, cycles, fetch_fk_columns(cur, schema)
                )
                nulled = 0
                for child, cols in plans:
                    predicate = by_name[child].predicate.replace("{alias}", "t")
                    assignments = ", ".join(f"{quote_ident(c)} = NULL" for c in cols)
                    cur.execute(
                        f"UPDATE {quote_ident(schema)}.{quote_ident(child)} t "
                        f"SET {assignments} WHERE {predicate}"
                    )
                    affected = getattr(cur, "rowcount", 0) or 0
                    if affected > 0:
                        nulled += int(affected)
                if broken:
                    remaining = [(c, p) for c, p in edges if (c, p) not in broken]
                    fresh_order, fresh_cycles = topo_delete_order(
                        [t.name for t in owned], remaining
                    )
                    if not fresh_cycles:
                        final_order = fresh_order
                        console.print(
                            f"[green]Broke {len(broken)} FK cycle edge(s), "
                            f"nulled {nulled} reference(s); reordered deletes.[/green]"
                        )
                    else:
                        err_console.print(
                            f"[yellow]WARNING: {len(fresh_cycles)} table(s) still form "
                            "FK cycles on NOT NULL references — a superuser "
                            "--disable-triggers=always run is needed.[/yellow]"
                        )
            for name in final_order:
                cur.execute(delete_statement(schema, name, by_name[name].predicate))
            if registry_exists(conn):
                if app_name:
                    cur.execute(
                        "DELETE FROM public.tenant_registry "
                        "WHERE tenant_id = %s AND application_name = %s",
                        (tenant_id, app_name),
                    )
                else:
                    cur.execute(
                        "DELETE FROM public.tenant_registry WHERE tenant_id = %s",
                        (tenant_id,),
                    )
            if disabled == "all":
                cur.execute(enable_triggers_sql(schema))
            elif disabled == "user":
                cur.execute(enable_user_triggers_sql(schema))
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    console.print(
        f"[bold green]Tenant '{tenant_id}' rows were deleted "
        f"from shared schema '{schema}'.[/bold green]"
    )


@dataclass(frozen=True)
class BackupEntry:
    """One backed-up table: expected rows plus its CSV data file."""

    table: str
    expected: int
    data_file: Path


def read_backup_manifest(backup_dir: Path) -> tuple[list[BackupEntry], dict[str, str]]:
    """Read ``table-row-counts.csv`` and ``metadata.properties``."""
    manifest_path = backup_dir / "table-row-counts.csv"
    if not manifest_path.is_file():
        raise CleanError(f"not a zc backup: {manifest_path} is missing.")
    entries: list[BackupEntry] = []
    with manifest_path.open("r", encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle):
            try:
                expected = int((row.get("row_count") or "0").strip())
            except ValueError as exc:
                raise CleanError(f"corrupt backup manifest row: {row}.") from exc
            table = (row.get("table_name") or "").strip()
            data_file = (row.get("data_file") or "").strip()
            if not table or not data_file:
                raise CleanError(f"corrupt backup manifest row: {row}.")
            entries.append(
                BackupEntry(
                    table=table, expected=expected, data_file=backup_dir / "data" / data_file
                )
            )
    meta: dict[str, str] = {}
    meta_path = backup_dir / "metadata.properties"
    if meta_path.is_file():
        for line in meta_path.read_text(encoding="utf-8").splitlines():
            key, sep, value = line.partition("=")
            if sep:
                meta[key.strip()] = value.strip()
    return entries, meta


def count_csv_rows(path: Path) -> int:
    """Count data rows in a CSV file, honouring quoted newlines."""
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle)
        next(reader, None)
        return sum(1 for _ in reader)


def csv_header(path: Path) -> list[str]:
    """Column names from a CSV header row."""
    with path.open("r", encoding="utf-8", newline="") as handle:
        header = next(csv.reader(handle), [])
    if not header:
        raise CleanError(f"backup file has no header row: {path}.")
    return header


def restore_registry_csv(conn: Any, csv_path: Path) -> int:
    """Restore registry rows, preserving any manually-rotated client ids."""
    columns = csv_header(csv_path)
    quoted_cols = ", ".join(quote_ident(c) for c in columns)
    with conn.cursor() as cur:
        cur.execute(
            "CREATE TEMP TABLE _zc_restore_registry "
            "(LIKE public.tenant_registry) ON COMMIT DROP"
        )
        with cur.copy(
            f"COPY _zc_restore_registry ({quoted_cols}) FROM STDIN WITH (FORMAT CSV, HEADER)"
        ) as copy:
            with csv_path.open("rb") as handle:
                while True:
                    block = handle.read(65536)
                    if not block:
                        break
                    copy.write(block)
        cur.execute(
            "INSERT INTO public.tenant_registry SELECT * FROM _zc_restore_registry "
            "ON CONFLICT (client_id, application_name) DO NOTHING"
        )
        return cur.rowcount if cur.rowcount is not None and cur.rowcount >= 0 else 0


def fix_sequences(conn: Any, schema: str, tables: list[str]) -> int:
    """Advance serial/identity sequences past restored maximums."""
    fixed = 0
    with conn.cursor() as cur:
        cur.execute(
            "SELECT table_name, column_name FROM information_schema.columns "
            "WHERE table_schema = %s AND table_name = ANY(%s) "
            "AND (is_identity = 'YES' OR column_default LIKE 'nextval%%')",
            (schema, tables),
        )
        serials = [(str(t), str(c)) for t, c in cur.fetchall()]
    for table, column in serials:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT pg_get_serial_sequence(%s, %s)",
                (f"{schema}.{table}", column),
            )
            row = cur.fetchone()
            seq = str(row[0]) if row and row[0] else ""
            if not seq:
                continue
            cur.execute(
                f"SELECT COALESCE(MAX({quote_ident(column)}), 0) "
                f"FROM {quote_ident(schema)}.{quote_ident(table)}"
            )
            maximum = cur.fetchone()
            top = int(maximum[0]) if maximum else 0
            if top > 0:
                cur.execute("SELECT setval(%s, %s)", (seq, top))
            else:
                cur.execute("SELECT setval(%s, 1, false)", (seq,))
            fixed += 1
    return fixed


def restore_multi_schema(
    conn: Any,
    *,
    schema: str,
    backup_dir: Path,
    pg_url: str,
    db_user: str,
    db_password: str,
) -> None:
    """Restore a whole-schema pg_dump backup, refusing to overwrite."""
    dump = backup_dir / "schema.dump"
    if not dump.is_file():
        raise CleanError(f"multi-schema backup has no schema.dump: {backup_dir}.")
    meta_path = backup_dir / "metadata.properties"
    if meta_path.is_file():
        for line in meta_path.read_text(encoding="utf-8").splitlines():
            key, sep, value = line.partition("=")
            if sep and key.strip() == "target_schema" and value.strip() != schema:
                raise CleanError(
                    f"backup is for schema '{value.strip()}', not '{schema}'."
                )
    if schema_exists(conn, schema):
        raise CleanError(
            f"schema '{schema}' already exists — refusing to overwrite. "
            "Drop it first if a full replace is intended."
        )
    if shutil.which("pg_restore") is None:
        raise CleanError("pg_restore is required to restore a schema dump.")
    cmd = [
        "pg_restore",
        "--username",
        db_user,
        "--no-password",
        "--dbname",
        pg_url,
        str(dump),
    ]
    restore_env = dict(os.environ)
    if db_password:
        restore_env["PGPASSWORD"] = db_password
    proc = subprocess.run(cmd, capture_output=True, text=True, env=restore_env)
    if proc.returncode != 0:
        raise CleanError(f"pg_restore failed: {proc.stderr.strip()}")
    registry_csv = backup_dir / "tenant_registry.csv"
    if registry_exists(conn) and registry_csv.is_file():
        try:
            with conn.cursor() as cur:
                cur.execute("BEGIN")
                restored = restore_registry_csv(conn, registry_csv)
                conn.commit()
            console.print(f"[green]Restored {restored} tenant_registry row(s).[/green]")
        except Exception:
            conn.rollback()
            raise
    console.print(f"[bold green]Schema '{schema}' was restored from {dump.name}.[/bold green]")


def run_restore(
    conn: Any,
    *,
    schema: str,
    tenant_id: str,
    backup_dir: Path,
    dry_run: bool,
    assume_yes: bool,
    disable_triggers: str = "auto",
) -> None:
    """Restore one tenant's rows from a zc backup directory."""
    if disable_triggers not in ("auto", "always", "never"):
        raise CleanError("--disable-triggers must be one of: auto, always, never")
    ensure_safe_schema(schema)
    ensure_safe_identifier(tenant_id, "tenant id")
    entries, meta = read_backup_manifest(backup_dir)
    if not entries:
        raise CleanError(f"backup holds no tables: {backup_dir}.")
    if meta.get("tenant_id") and meta["tenant_id"] != tenant_id:
        raise CleanError(
            f"backup is for tenant '{meta['tenant_id']}', not '{tenant_id}'."
        )
    if meta.get("target_schema") and meta["target_schema"] != schema:
        raise CleanError(
            f"backup is for schema '{meta['target_schema']}', not '{schema}'."
        )
    if not schema_exists(conn, schema):
        raise CleanError(f"target schema '{schema}' does not exist.")
    for entry in entries:
        if not entry.data_file.is_file():
            raise CleanError(f"backup data file is missing: {entry.data_file}.")
        actual = count_csv_rows(entry.data_file)
        if actual != entry.expected:
            raise CleanError(
                f"backup file {entry.data_file.name} holds {actual} rows, "
                f"manifest says {entry.expected} — backup is corrupt."
            )
    names = [entry.table for entry in entries]
    by_name = {entry.table: entry for entry in entries}
    edges = [
        (child, parent)
        for child, parent in fetch_fk_edges(conn, schema)
        if child in by_name and parent in by_name
    ]
    order, cycles = topo_delete_order(names, edges)
    restore_order = list(reversed(order)) + cycles
    rows = [(name, by_name[name].expected) for name in restore_order]
    total = sum(expected for _, expected in rows)
    needs_disable = disable_triggers == "always" or (disable_triggers == "auto" and bool(cycles))
    note = "Restore order is parent-first from the live FK graph."
    if needs_disable:
        note += " FK triggers stay disabled for the whole restore."
    elif cycles:
        note += f" {len(cycles)} table(s) form FK cycles; use --disable-triggers=always as superuser if this fails."
    render_plan_table(
        f"restore: {tenant_id} into {schema} ({len(rows)} tables, {total} rows)",
        rows,
        note,
    )
    if dry_run:
        console.print("[bold green]Dry run — no changes made.[/bold green]")
        return
    confirm_destructive(tenant_id, assume_yes)
    disabled = ""
    try:
        with conn.cursor() as cur:
            if needs_disable:
                cur.execute("SAVEPOINT zc_disable_all")
                try:
                    cur.execute(disable_triggers_sql(schema))
                    disabled = "all"
                    cur.execute("RELEASE SAVEPOINT zc_disable_all")
                except Exception as exc_all:
                    cur.execute("ROLLBACK TO SAVEPOINT zc_disable_all")
                    cur.execute("RELEASE SAVEPOINT zc_disable_all")
                    if disable_triggers == "always":
                        raise CleanError(
                            "disabling FK triggers failed: the database user needs "
                            f"trigger privileges on schema '{schema}': {exc_all}"
                        ) from exc_all
                    cur.execute("SAVEPOINT zc_disable_user")
                    try:
                        cur.execute(disable_user_triggers_sql(schema))
                        disabled = "user"
                        cur.execute("RELEASE SAVEPOINT zc_disable_user")
                    except Exception as exc_user:
                        cur.execute("ROLLBACK TO SAVEPOINT zc_disable_user")
                        cur.execute("RELEASE SAVEPOINT zc_disable_user")
                        err_console.print(
                            f"[yellow]WARNING: could not disable triggers ({exc_user}); "
                            "continuing with FK-ordered restore.[/yellow]"
                        )
                    else:
                        err_console.print(
                            f"[yellow]WARNING: could not disable ALL triggers ({exc_all}); "
                            "disabled USER triggers only, FKs stay enforced.[/yellow]"
                        )
            for name in restore_order:
                entry = by_name[name]
                columns = csv_header(entry.data_file)
                quoted_cols = ", ".join(quote_ident(c) for c in columns)
                cur.execute(f"SELECT count(*) FROM {quote_ident(schema)}.{quote_ident(name)}")
                before_row = cur.fetchone()
                before = int(before_row[0]) if before_row else 0
                with cur.copy(
                    f"COPY {quote_ident(schema)}.{quote_ident(name)} ({quoted_cols}) "
                    "FROM STDIN WITH (FORMAT CSV, HEADER)"
                ) as copy:
                    with entry.data_file.open("rb") as handle:
                        while True:
                            block = handle.read(65536)
                            if not block:
                                break
                            copy.write(block)
                cur.execute(f"SELECT count(*) FROM {quote_ident(schema)}.{quote_ident(name)}")
                after_row = cur.fetchone()
                after = int(after_row[0]) if after_row else 0
                if after - before != entry.expected:
                    raise CleanError(
                        f"restored {after - before} rows into {name}, "
                        f"expected {entry.expected} — rolling back."
                    )
            registry_csv = backup_dir / "tenant_registry.csv"
            if registry_exists(conn) and registry_csv.is_file():
                restored = restore_registry_csv(conn, registry_csv)
                console.print(f"[green]Restored {restored} tenant_registry row(s).[/green]")
            if disabled == "all":
                cur.execute(enable_triggers_sql(schema))
            elif disabled == "user":
                cur.execute(enable_user_triggers_sql(schema))
        fixed = fix_sequences(conn, schema, names)
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    console.print(
        f"[bold green]Tenant '{tenant_id}' ({total} rows) was restored "
        f"into '{schema}'. Sequences advanced on {fixed} column(s).[/bold green]"
    )


@app.command()
def clean(
    config_file: Annotated[
        Path,
        typer.Argument(help="Path to the zapclean YAML config (db url + credentials).", metavar="CONFIG"),
    ],
    tenant: Annotated[
        str | None,
        typer.Option("--tenant", help="Tenant alias to delete (overrides target.tenant)."),
    ] = None,
    mode: Annotated[
        str | None,
        typer.Option("--mode", help="multi-schema or single-schema (defaults to target.mode, or env.TENANCY_STRATEGY for deployment configs)."),
    ] = None,
    schema_name: Annotated[
        str | None,
        typer.Option("--schema-name", help="Shared schema for single-schema (defaults to target.schema, or zap.name minus -api for deployment configs)."),
    ] = None,
    tenant_id: Annotated[
        str | None,
        typer.Option("--tenant-id", help="Logical tenant_id override (defaults to --tenant)."),
    ] = None,
    app_name: Annotated[
        str | None,
        typer.Option("--app-name", help="Scope tenant_registry cleanup to one application."),
    ] = None,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="Preview the plan without deleting anything."),
    ] = False,
    yes: Annotated[
        bool,
        typer.Option("--yes", help="Skip the interactive confirmation."),
    ] = False,
    no_backup: Annotated[
        bool,
        typer.Option("--no-backup", help="Delete without creating a backup."),
    ] = False,
    backup_dir: Annotated[
        Path | None,
        typer.Option("--backup-dir", help="Backup root (overrides backup.dir)."),
    ] = None,
    disable_triggers: Annotated[
        str,
        typer.Option(
            "--disable-triggers",
            help="FK trigger handling for single-schema: auto, always, or never.",
        ),
    ] = "auto",
    restore: Annotated[
        Path | None,
        typer.Option(
            "--restore",
            help="Restore a zc backup directory instead of deleting.",
        ),
    ] = None,
) -> None:
    """Delete all data for one tenant, or restore a previous backup."""
    try:
        cfg = resolve_effective_config(config_file)
    except CleanError as exc:
        err_console.print(f"[bold red]ERROR:[/bold red] {exc}")
        raise typer.Exit(code=1) from exc

    if mode is not None:
        try:
            cfg.target.mode = normalize_mode(mode)
        except CleanError as exc:
            err_console.print(f"[bold red]ERROR:[/bold red] {exc}")
            raise typer.Exit(code=1) from exc
    resolved_mode = cfg.target.mode
    resolved_tenant = tenant or cfg.target.tenant
    resolved_schema = schema_name or cfg.target.schema_name
    resolved_tenant_id = tenant_id or cfg.target.tenant_id or resolved_tenant
    resolved_app = app_name or cfg.target.app_name

    if not resolved_tenant and not resolved_tenant_id:
        err_console.print("[bold red]ERROR:[/bold red] provide --tenant or target.tenant in the config.")
        raise typer.Exit(code=1)
    if disable_triggers not in ("auto", "always", "never"):
        err_console.print("[bold red]ERROR:[/bold red] --disable-triggers must be auto, always, or never.")
        raise typer.Exit(code=1)

    try:
        if resolved_mode == "multi-schema":
            target_schema = resolved_schema or resolved_tenant
            if not target_schema:
                raise CleanError("multi-schema needs --tenant or target.schema for the schema name.")
            ensure_safe_schema(target_schema)
            target_tenant = resolved_tenant_id
        else:
            if not resolved_schema:
                raise CleanError("single-schema needs --schema-name or target.schema.")
            if not resolved_tenant_id:
                raise CleanError("single-schema needs --tenant or --tenant-id.")
            ensure_safe_schema(resolved_schema)
            ensure_safe_identifier(resolved_tenant_id, "tenant id")
            target_schema = resolved_schema
            target_tenant = resolved_tenant_id
    except CleanError as exc:
        err_console.print(f"[bold red]ERROR:[/bold red] {exc}")
        raise typer.Exit(code=1) from exc

    try:
        conn = connect(cfg)
    except Exception as exc:
        err_console.print(f"[bold red]ERROR:[/bold red] could not connect to the database: {exc}")
        raise typer.Exit(code=1) from exc

    backup_root: Path | None
    if no_backup or not cfg.backup.enabled:
        backup_root = None
    else:
        backup_root = backup_dir or Path(cfg.backup.dir)

    console.print(f"[bold]Mode:[/bold] {resolved_mode}")
    console.print(f"[bold]Tenant:[/bold] {target_tenant}")
    console.print(f"[bold]Schema:[/bold] {target_schema}")
    host = host_label(cfg.db.url)

    try:
        if restore is not None:
            if resolved_mode == "multi-schema":
                if dry_run:
                    console.print(
                        f"[bold]Restore plan:[/bold] pg_restore schema '{target_schema}' "
                        f"from {restore} (refuses to overwrite)."
                    )
                    console.print("[bold green]Dry run — no changes made.[/bold green]")
                else:
                    confirm_destructive(target_tenant or target_schema, yes)
                    restore_multi_schema(
                        conn,
                        schema=target_schema,
                        backup_dir=restore,
                        pg_url=normalize_db_url(cfg.db.url),
                        db_user=cfg.db.user,
                        db_password=cfg.db.password,
                    )
            else:
                run_restore(
                    conn,
                    schema=target_schema,
                    tenant_id=target_tenant,
                    backup_dir=restore,
                    dry_run=dry_run,
                    assume_yes=yes,
                    disable_triggers=disable_triggers,
                )
        elif resolved_mode == "multi-schema":
            run_multi_schema(
                conn,
                schema=target_schema,
                app_name=resolved_app,
                dry_run=dry_run,
                assume_yes=yes,
                backup_root=backup_root,
                pg_url=normalize_db_url(cfg.db.url),
                db_user=cfg.db.user,
                db_password=cfg.db.password,
                host=host,
            )
        else:
            run_single_schema(
                conn,
                schema=target_schema,
                tenant_id=target_tenant,
                app_name=resolved_app,
                dry_run=dry_run,
                assume_yes=yes,
                backup_root=backup_root,
                disable_triggers=disable_triggers,
                host=host,
            )
    except CleanError as exc:
        err_console.print(f"[bold red]ERROR:[/bold red] {exc}")
        raise typer.Exit(code=1) from exc
    except Exception as exc:
        err_console.print(f"[bold red]ERROR:[/bold red] cleanup failed: {exc}")
        raise typer.Exit(code=1) from exc
    finally:
        conn.close()


if __name__ == "__main__":
    app()
