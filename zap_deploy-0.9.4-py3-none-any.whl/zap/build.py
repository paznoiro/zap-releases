"""``zap build`` / ``zb`` command.

Build the service from local source, then build a Docker image from it and
push it to the registry (ghcr), tagged with a tag you provide or a local git
short-sha. Pair with ``zd <cfg> --tag <tag>`` to deploy that specific build —
a local alternative to ``zr`` (which triggers the build via GitHub Actions
from origin/main).

    zb employee-api/deployments/production.yaml
    zb employee-api/deployments/production.yaml --tag v1.2.3
    zd employee-api/deployments/production.yaml --tag v1.2.3

The image repo is taken from the config's ``env.IMAGE_REPO``. The build
context and Dockerfile resolve against the service directory
(``zap.service_dir``, relative to the config file), so ``zb`` works from any
cwd — same anchoring as ``zd``.

A runtime-only Dockerfile (one ``FROM``) copies an artifact it does not
build, so ``zb`` compiles it first — Gradle, Maven, Go and Node are detected
from the service directory, and a ``build:`` section overrides the guess. A
multi-stage Dockerfile builds inside the image and is left alone.
"""

from __future__ import annotations

import contextlib
import os
import shlex
import shutil
import subprocess
import time
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console

from .config import (
    BuildConfig,
    ConfigError,
    DeploymentConfig,
    build_config,
    parse_raw,
    resolve_service_dir,
)
from .doppler import DopplerError, _doppler_sections, fetch_secrets
from .project import (
    BuildError,
    BuildPlan,
    detect,
    detect_jib,
    is_runtime_only,
    plan_from_config,
    stage_artifacts,
    stale_artifacts,
)

app = typer.Typer(
    name="build",
    help="Build and push the service image from local source.",
    no_args_is_help=True,
)

console = Console()
err_console = Console(stderr=True)


def _local_tag(service_dir: Path) -> str:
    """Return the git short SHA at *service_dir*, or ``latest`` if not a repo."""
    res = subprocess.run(
        ["git", "-C", str(service_dir), "rev-parse", "--short", "HEAD"],
        capture_output=True,
        text=True,
    )
    if res.returncode == 0 and res.stdout.strip():
        return res.stdout.strip()
    return "latest"


def _run(
    cmd: list[str],
    cwd: Path | None = None,
    env: dict[str, str] | None = None,
) -> int:
    # Inherit stdio so the user sees live build/push progress.
    merged = {**os.environ, **env} if env else None
    return subprocess.run(cmd, cwd=cwd, env=merged).returncode


def _jib_credentials() -> dict[str, str]:
    """Registry credentials for ``./gradlew jib`` (push), in priority order.

    An explicit ``JIB_USERNAME``/``JIB_PASSWORD`` wins — CI sets these from
    ``github.actor``/``secrets.GITHUB_TOKEN``. Locally they fall back to
    ``GH_REGISTRY_USER``/``GH_REGISTRY_TOKEN`` so a push works once those are
    exported. Returns an empty dict when nothing is set (Jib then reads
    ``~/.docker/config.json`` if it can, or the push fails with a 401).
    """
    creds: dict[str, str] = {}
    user = os.environ.get("JIB_USERNAME") or os.environ.get("GH_REGISTRY_USER")
    token = os.environ.get("JIB_PASSWORD") or os.environ.get("GH_REGISTRY_TOKEN")
    if user and token:
        creds["JIB_USERNAME"] = user
        creds["JIB_PASSWORD"] = token
    return creds


def resolve_plan(
    cfg: BuildConfig,
    service_dir: Path,
    dockerfile: Path,
    platform: str,
) -> tuple[BuildPlan | None, str]:
    """Decide what to compile before ``docker build``, and say why.

    Returns ``(plan, reason)``; ``plan`` is ``None`` when there is nothing to
    pre-build, in which case *reason* explains the skip. A Jib project has no
    Dockerfile — Jib builds and pushes the image itself, so the returned plan
    carries ``image_builder="jib"`` and the caller skips ``docker build``.
    """
    if cfg.skip:
        return None, "build.skip is set"
    if cfg.command:
        return (
            plan_from_config(cfg.command, cfg.workdir, cfg.stage, service_dir),
            "",
        )
    if not dockerfile.is_file():
        jib_plan = detect_jib(service_dir)
        if jib_plan is not None:
            return jib_plan, ""
        return None, f"{dockerfile.name} not found"
    if not is_runtime_only(dockerfile):
        return None, "multi-stage Dockerfile builds from source itself"
    plan = detect(service_dir, platform)
    if plan is None:
        return None, "no supported build tool detected in the service directory"
    if cfg.stage:
        plan = plan_from_config(
            plan.command, cfg.workdir, cfg.stage, service_dir
        )
    return plan, ""


def run_build(
    config: DeploymentConfig,
    service_dir: Path,
    config_file: Path | str,
    image_tag: str,
    *,
    platform: str = "linux/amd64",
    file: str = "Dockerfile",
    no_cache: bool = False,
    no_compile: bool = False,
    build_arg: list[str] | None = None,
    no_push: bool = False,
) -> str:
    """Build and push ``config.env.IMAGE_REPO:image_tag``; return the ref.

    Shared by ``zb`` and ``zbd``. Raises ``typer.Exit(1)`` on failure so
    callers stop before deploying.
    """
    repo = config.env.get("IMAGE_REPO", "")
    ref = f"{repo}:{image_tag}"

    try:
        plan, reason = resolve_plan(
            config.build, service_dir, service_dir / file, platform
        )
    except BuildError as exc:
        err_console.print(f"[bold red]ERROR:[/bold red] {exc}")
        raise typer.Exit(code=1) from exc

    if plan is None:
        console.print(f"[dim]==> No source build: {reason}[/dim]")
    elif no_compile:
        console.print("[yellow]==> Skipping the source build (--no-compile)[/yellow]")
        for dest, problem in stale_artifacts(plan, service_dir):
            err_console.print(
                f"[bold yellow]WARNING:[/bold yellow] {dest} is {problem} — "
                f"{ref} would ship code older than this checkout."
            )
    elif plan.image_builder == "jib":
        console.print(f"[bold]==> Building {ref} with Jib[/bold]")
        console.print(f"[dim]    workdir: {plan.workdir}[/dim]")
        task = "jibDockerBuild" if no_push else "jib"
        jib_cmd = list(plan.command[:-1]) + [
            plan.command[-1].replace("jib", task, 1)
        ]
        jib_env = {**plan.env, "JIB_IMAGE": ref}
        if not no_push:
            jib_env.update(_jib_credentials())
        printable = " ".join(shlex.quote(part) for part in jib_cmd)
        console.print(f"[bold]    {printable}[/bold]")
        if _run(jib_cmd, cwd=plan.workdir, env=jib_env) != 0:
            err_console.print(
                f"[bold red]ERROR:[/bold red] jib build failed for {ref}"
            )
            raise typer.Exit(code=1)
        if no_push:
            console.print(f"[bold green]==> Built {ref} (not pushed).[/bold green]")
            console.print(
                f"[dim]    deploy with: zd {config_file} --tag {shlex.quote(image_tag)}[/dim]"
            )
        else:
            console.print(f"[bold green]==> Pushed {ref}.[/bold green]")
            console.print(
                f"[dim]    deploy with: zd {config_file} --tag {shlex.quote(image_tag)}[/dim]"
            )
        return ref
    else:
        started = time.time()
        printable = " ".join(shlex.quote(part) for part in plan.command)
        console.print(f"[bold]==> Building source ({plan.tool}): {printable}[/bold]")
        console.print(f"[dim]    workdir: {plan.workdir}[/dim]")
        if _run(plan.command, cwd=plan.workdir, env=plan.env) != 0:
            err_console.print(
                f"[bold red]ERROR:[/bold red] source build failed: {printable}"
            )
            raise typer.Exit(code=1)
        try:
            for source, dest in stage_artifacts(plan, service_dir, started):
                console.print(f"[green]    staged {source.name} -> {dest}[/green]")
        except BuildError as exc:
            err_console.print(f"[bold red]ERROR:[/bold red] {exc}")
            raise typer.Exit(code=1) from exc

    with contextlib.chdir(service_dir):
        cmd = ["docker", "build", "--platform", platform, "-t", ref, "-f", file]
        if no_cache:
            cmd.append("--no-cache")
        for ba in build_arg or []:
            cmd += ["--build-arg", ba]
        cmd.append(".")

        console.print(f"[bold]==> Building {ref} (platform {platform})[/bold]")
        console.print(f"[dim]    context: {service_dir}[/dim]")
        if _run(cmd) != 0:
            err_console.print(
                f"[bold red]ERROR:[/bold red] docker build failed for {ref}"
            )
            raise typer.Exit(code=1)

        if no_push:
            console.print(f"[bold green]==> Built {ref} (not pushed).[/bold green]")
            console.print(
                f"[dim]    deploy with: zd {config_file} --tag {shlex.quote(image_tag)}[/dim]"
            )
            return ref

        console.print(f"[bold]==> Pushing {ref}[/bold]")
        if _run(["docker", "push", ref]) != 0:
            err_console.print(
                f"[bold red]ERROR:[/bold red] docker push failed for {ref}"
            )
            err_console.print(
                "[yellow]    tip: authenticate first, e.g. "
                "echo $GITHUB_TOKEN | docker login ghcr.io -u <user> --password-stdin[/yellow]"
            )
            raise typer.Exit(code=1)

        console.print(f"[bold green]==> Pushed {ref}.[/bold green]")
        console.print(
            f"[dim]    deploy with: zd {config_file} --tag {shlex.quote(image_tag)}[/dim]"
        )
        return ref


@app.command()
def build(
    config_file: Annotated[
        Path,
        typer.Argument(
            help="Path to the deployment YAML config "
            "(e.g. employee-api/deployments/production.yaml).",
            metavar="CONFIG",
        ),
    ],
    tag: Annotated[
        str | None,
        typer.Option("--tag", help="Image tag (default: git short sha, or 'latest')."),
    ] = None,
    no_push: Annotated[
        bool,
        typer.Option("--no-push", help="Build only; don't push to the registry."),
    ] = False,
    platform: Annotated[
        str,
        typer.Option("--platform", help="Target platform (default linux/amd64)."),
    ] = "linux/amd64",
    file: Annotated[
        str,
        typer.Option("--file", "-f", help="Dockerfile path (relative to service dir)."),
    ] = "Dockerfile",
    no_cache: Annotated[
        bool,
        typer.Option("--no-cache", help="Disable the Docker build cache."),
    ] = False,
    no_compile: Annotated[
        bool,
        typer.Option(
            "--no-compile",
            help="Skip the source build; ship the artifact already on disk.",
        ),
    ] = False,
    build_arg: Annotated[
        list[str] | None,
        typer.Option(
            "--build-arg",
            help="KEY=VAL build arg (repeatable).",
        ),
    ] = None,
) -> None:
    """Build and push the service image from local source."""
    if not shutil.which("docker"):
        err_console.print("[bold red]ERROR:[/bold red] docker is required but not installed.")
        raise typer.Exit(code=1)

    config_path = Path(config_file).resolve()
    try:
        raw = parse_raw(config_path)
        secrets: dict[str, str] = {}
        for project, dconfig in _doppler_sections(raw):
            console.print(
                f"[bold]==> Fetching secrets from Doppler "
                f"({project} / {dconfig})[/bold]"
            )
            fetched = fetch_secrets(project, dconfig)
            console.print(
                f"[green]    {len(fetched)} secrets loaded for {project} "
                f"({dconfig})[/green]"
            )
            secrets.update(fetched)
        config = build_config(raw, {**os.environ, **secrets})
    except (ConfigError, DopplerError) as exc:
        err_console.print(f"[bold red]ERROR:[/bold red] {exc}")
        raise typer.Exit(code=1) from exc

    repo = config.env.get("IMAGE_REPO", "")
    if not repo:
        err_console.print(
            "[bold red]ERROR:[/bold red] IMAGE_REPO is not set in the config's env: section."
        )
        raise typer.Exit(code=1)

    try:
        service_dir = resolve_service_dir(config_path, config.zap.service_dir)
    except ConfigError as exc:
        err_console.print(f"[bold red]ERROR:[/bold red] {exc}")
        raise typer.Exit(code=1) from exc
    image_tag = tag or _local_tag(service_dir)

    run_build(
        config,
        service_dir,
        config_file,
        image_tag,
        platform=platform,
        file=file,
        no_cache=no_cache,
        no_compile=no_compile,
        build_arg=build_arg,
        no_push=no_push,
    )
