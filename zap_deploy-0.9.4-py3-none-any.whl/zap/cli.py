"""``zap`` — top-level CLI grouping ``deploy``, ``release``, ``build`` and ``clean``."""

from __future__ import annotations

import typer

from . import __version__
from .build import build as _build
from .builddeploy import builddeploy as _builddeploy
from .clean import clean as _clean
from .deploy import deploy as _deploy
from .release import release as _release
from .seed import seed as _seed

app = typer.Typer(
    name="zap",
    help="Zap — Docker deployment and GitHub release CLI.",
    no_args_is_help=True,
)

app.command(name="deploy")(_deploy)
app.command(name="release")(_release)
app.command(name="build")(_build)
app.command(name="build-deploy")(_builddeploy)
app.command(name="clean")(_clean)
app.command(name="seed")(_seed)


@app.command()
def version() -> None:
    """Print the zap CLI version."""
    typer.echo(f"zap {__version__}")


if __name__ == "__main__":
    app()
