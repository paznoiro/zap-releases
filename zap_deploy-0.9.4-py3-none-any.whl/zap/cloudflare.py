"""``zap deploy`` backend for Cloudflare (``cloudflare:`` configs).

While the Docker backend deploys over SSH, this backend deploys locally
through ``wrangler``.

Workers: it ensures the D1 databases, KV namespaces and queues exist
(reusing them by name when they are already deployed, creating them
otherwise), renders a per-environment Wrangler config from the checked-in
local base plus the names in the deployment YAML, applies D1 migrations,
builds the site bundle, uploads secrets, runs ``wrangler deploy`` and
finally hits the health check URL.

Pages (``cloudflare.pages``): it ensures the Pages project exists, attaches
the custom domains and their DNS CNAMEs through the Cloudflare API (wrangler
has no command for either), builds the site, uploads secrets, runs
``wrangler pages deploy`` and hits the health check URL.
"""

from __future__ import annotations

import contextlib
import json
import os
import re
import shutil
import subprocess
import tempfile
import time
import urllib.error
import urllib.request
from collections.abc import Iterable, Iterator, Mapping
from pathlib import Path
from typing import Any
from urllib.parse import quote, urlencode

from rich.console import Console
from rich.json import JSON
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from . import __version__
from .config import CloudflareConfig, CloudflarePages, ConfigError, DeploymentConfig

console = Console()
err_console = Console(stderr=True)

USER_AGENT = f"zap-cli/{__version__}"


class CloudflareError(ConfigError):
    """A Cloudflare deployment precondition or step failed."""


def check_dependencies(config: DeploymentConfig) -> None:
    deps = ["wrangler"]
    if config.cloudflare is not None and config.cloudflare.site_build:
        deps += ["node", "npm"]
    if config.doppler.project or config.doppler.projects:
        deps.append("doppler")
    console.print("[bold]==> Checking dependencies...[/bold]")
    missing: list[str] = []
    for cmd in deps:
        if shutil.which(cmd):
            console.print(f"  [green][OK][/green] {cmd}")
        else:
            console.print(f"  [red][MISSING][/red] {cmd} is required but not installed.")
            missing.append(cmd)
    if missing:
        raise CloudflareError("Please install missing dependencies before deploying.")


class Wrangler:
    def __init__(self, service_dir: Path, env: Mapping[str, str], out: Console) -> None:
        self.service_dir = service_dir
        self.env = dict(env)
        self.out = out

    def run(self, args: list[str], *, input_text: str | None = None) -> str:
        res = subprocess.run(
            ["wrangler", *args],
            cwd=self.service_dir,
            env=self.env,
            input=input_text,
            capture_output=True,
            text=True,
        )
        if res.returncode != 0:
            detail = (res.stderr or res.stdout).strip().splitlines()
            tail = "\n".join(detail[-8:])
            raise CloudflareError(f"wrangler {' '.join(args)} failed:\n{tail}")
        return res.stdout


def wrangler_env(config: DeploymentConfig, env_vars: Mapping[str, str]) -> dict[str, str]:
    cf = config.cloudflare
    assert cf is not None
    token = env_vars.get("CLOUDFLARE_API_TOKEN", "")
    if not token:
        raise CloudflareError("CLOUDFLARE_API_TOKEN is not set (Doppler or environment)")
    account = env_vars.get("CLOUDFLARE_ACCOUNT_ID", "") or cf.account_id
    if not account:
        raise CloudflareError("CLOUDFLARE_ACCOUNT_ID is not set (Doppler or environment)")
    env = dict(os.environ)
    env.update(
        {
            "CLOUDFLARE_API_TOKEN": token,
            "CLOUDFLARE_ACCOUNT_ID": account,
            "WRANGLER_SEND_METRICS": "false",
        }
    )
    return env


def _names_from_json(stdout: str, *keys: str) -> list[str]:
    try:
        data = json.loads(stdout)
    except json.JSONDecodeError:
        return []
    names: list[str] = []
    if isinstance(data, list):
        for entry in data:
            if isinstance(entry, dict):
                for key in keys:
                    value = entry.get(key)
                    if isinstance(value, str) and value:
                        names.append(value)
                        break
    return names


def _read_config_string(text: str, key: str) -> str:
    match = re.search(r'"' + re.escape(key) + r'"\s*:\s*"([^"]*)"', text)
    return match.group(1) if match else ""


def _write_config_string(text: str, key: str, value: str) -> tuple[str, bool]:
    escaped = value.replace("\\", "\\\\")
    pattern = re.compile(r'("' + re.escape(key) + r'"\s*:\s*")([^"]*)(")')
    updated, count = pattern.subn(
        lambda m: m.group(1) + escaped + m.group(3), text, count=1
    )
    return updated, count > 0


def _rebase_relative_paths(
    text: str,
    from_dir: Path,
    to_dir: Path,
) -> tuple[str, list[str]]:
    """Rewrite config-relative paths in a copied wrangler config.

    Wrangler resolves ``migrations_dir`` and the assets ``directory`` against
    the config file's directory. When the generated copy lives somewhere else
    than the base (e.g. ``.wrangler/``), a base-relative path would silently
    point at a different location — rebase it so both configs resolve to the
    same target. Absolute paths and targets that do not exist under the base
    are left untouched.
    """
    if from_dir == to_dir:
        return text, []
    changes: list[str] = []
    # key -> target kind. "directory" only matches the assets block (the only
    # top-level key of that name whose value is a path); "main" is the
    # entry-point file; "$schema" the JSON-schema file in node_modules.
    targets: dict[str, str] = {
        "migrations_dir": "dir",
        "directory": "dir",
        "main": "file",
        "$schema": "file",
    }
    for key, kind in targets.items():
        value = _read_config_string(text, key)
        if not value or os.path.isabs(value):
            continue
        target = from_dir / value
        if kind == "dir" and not target.is_dir():
            continue
        if kind == "file" and not target.is_file():
            continue
        try:
            rebased = os.path.relpath(target, to_dir)
        except ValueError:
            continue
        if rebased == value:
            continue
        text, hit = _write_config_string(text, key, rebased)
        if hit:
            changes.append(f"{key} -> {rebased}")
    return text, changes


def ensure_d1(w: Wrangler, name: str) -> tuple[str, bool]:
    ids = _ids_from_json(w.run(["d1", "list", "--json"]), "name", "uuid")
    if name in ids:
        w.out.print(f"    D1 '{name}' already exists")
        return ids[name], False
    w.out.print(f"    D1 '{name}' missing — creating")
    w.run(["d1", "create", name])
    ids = _ids_from_json(w.run(["d1", "list", "--json"]), "name", "uuid")
    if name not in ids:
        raise CloudflareError(f"D1 database '{name}' not found after create")
    return ids[name], True


def _ids_from_json(stdout: str, name_key: str, id_key: str) -> dict[str, str]:
    try:
        data = json.loads(stdout)
    except json.JSONDecodeError:
        return {}
    ids: dict[str, str] = {}
    if isinstance(data, list):
        for entry in data:
            if isinstance(entry, dict):
                name = entry.get(name_key)
                ident = entry.get(id_key)
                if isinstance(name, str) and isinstance(ident, str):
                    ids[name] = ident
    return ids


def ensure_kv(w: Wrangler, title: str) -> tuple[str, bool]:
    listed = w.run(["kv", "namespace", "list"])
    ids = _ids_from_json(listed, "title", "id")
    if title in ids:
        w.out.print(f"    KV '{title}' already exists")
        return ids[title], False
    w.out.print(f"    KV '{title}' missing — creating")
    w.run(["kv", "namespace", "create", title])
    ids = _ids_from_json(w.run(["kv", "namespace", "list"]), "title", "id")
    if title not in ids:
        raise CloudflareError(f"KV namespace '{title}' not found after create")
    return ids[title], True


def ensure_queue(w: Wrangler, name: str) -> bool:
    listed = w.run(["queues", "list"])
    known = set(_names_from_json(listed, "queue_name", "queue", "name"))
    if not known and name in listed:
        return False
    if name in known:
        w.out.print(f"    queue '{name}' already exists")
        return False
    w.out.print(f"    queue '{name}' missing — creating")
    w.run(["queues", "create", name])
    return True


def _sub_binding_value(text: str, binding: str, key: str, value: str) -> tuple[str, bool]:
    pattern = re.compile(
        r'("binding"\s*:\s*"' + re.escape(binding) + r'"[^}]*?"' + re.escape(key) + r'"\s*:\s*")([^"]*)(")',
        re.DOTALL,
    )

    def replace(match: re.Match[str]) -> str:
        if match.group(2) == value:
            return match.group(0)
        return match.group(1) + value + match.group(3)

    updated, count = pattern.subn(replace, text, count=1)
    return updated, count > 0 and updated != text


def patch_wrangler_config(
    text: str,
    cf: CloudflareConfig,
    *,
    d1_ids: Mapping[str, tuple[str, str]] | None = None,
    kv_ids: Mapping[str, str] | None = None,
) -> tuple[str, list[str]]:
    changes: list[str] = []
    if cf.worker:
        match = re.search(r'^(\s*"name"\s*:\s*")([^"]*)(")', text, flags=re.MULTILINE)
        if match is not None and match.group(2) != cf.worker:
            text = text[: match.start()] + match.group(1) + cf.worker + match.group(3) + text[match.end() :]
            changes.append(f"worker name -> {cf.worker}")
    for binding, (name, ident) in (d1_ids or {}).items():
        if name:
            text, hit = _sub_binding_value(text, binding, "database_name", name)
            if hit:
                changes.append(f"d1 {binding} database_name -> {name}")
        text, hit = _sub_binding_value(text, binding, "database_id", ident)
        if hit:
            changes.append(f"d1 {binding} database_id -> {ident}")
    for binding, ident in (kv_ids or {}).items():
        text, hit = _sub_binding_value(text, binding, "id", ident)
        if hit:
            changes.append(f"kv {binding} id -> {ident}")
    for old, new in cf.queues.items():
        if not new or new == old:
            continue
        for key in ("queue", "dead_letter_queue"):
            pattern = re.compile(
                r'("' + re.escape(key) + r'"\s*:\s*")' + re.escape(old) + r'(")'
            )
            text, count = pattern.subn(lambda m: m.group(1) + new + m.group(2), text)
            if count:
                changes.append(f"{key} {old} -> {new}")
    if cf.custom_domains:
        text, domain_changes = _ensure_custom_domains(text, cf.custom_domains)
        changes.extend(domain_changes)
    return text, changes


def _unique_domains(domains: Iterable[str]) -> list[str]:
    seen: set[str] = set()
    wanted: list[str] = []
    for domain in domains:
        domain = domain.strip()
        if domain and domain not in seen:
            seen.add(domain)
            wanted.append(domain)
    return wanted


def _ensure_custom_domains(text: str, domains: list[str]) -> tuple[str, list[str]]:
    wanted = _unique_domains(domains)
    missing = [
        domain
        for domain in wanted
        if not re.search(
            r'"pattern"\s*:\s*"' + re.escape(domain) + r'"', text
        )
    ]
    if not missing:
        return text, []
    entries = ",\n    ".join(
        '{"pattern": "' + domain + '", "custom_domain": true}'
        for domain in missing
    )
    bounds = _routes_array_bounds(text)
    if bounds is None:
        insert_at = text.rfind("}")
        if insert_at == -1:
            return text, []
        prefix = text[:insert_at].rstrip()
        needs_comma = prefix.endswith(('"', "}", "]")) and not prefix.endswith("{")
        block = '\n  "routes": [\n    ' + entries + "\n  ]\n"
        if needs_comma:
            block = "," + block
        return text[:insert_at].rstrip() + block + text[insert_at:], [
            f"custom domain {domain}" for domain in missing
        ]
    start, end = bounds
    inner = text[start + 1 : end]
    if inner.strip():
        replacement = inner.rstrip() + ",\n    " + entries + "\n  "
    else:
        replacement = "\n    " + entries + "\n  "
    return text[: start + 1] + replacement + text[end:], [
        f"custom domain {domain}" for domain in missing
    ]


def _routes_array_bounds(text: str) -> tuple[int, int] | None:
    match = re.search(r'"routes"\s*:\s*\[', text)
    if match is None:
        return None
    start = text.index("[", match.start())
    in_string = False
    escaped = False
    line_comment = False
    block_comment = False
    depth = 0
    i = start
    while i < len(text):
        ch = text[i]
        nxt = text[i + 1] if i + 1 < len(text) else ""
        if line_comment:
            if ch == "\n":
                line_comment = False
        elif block_comment:
            if ch == "*" and nxt == "/":
                block_comment = False
                i += 1
        elif in_string:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == '"':
                in_string = False
        elif ch == "/" and nxt == "/":
            line_comment = True
            i += 1
        elif ch == "/" and nxt == "*":
            block_comment = True
            i += 1
        elif ch == '"':
            in_string = True
        elif ch == "[":
            depth += 1
        elif ch == "]":
            depth -= 1
            if depth == 0:
                return start, i
        i += 1
    return None


def _deploy_flags(config: DeploymentConfig) -> list[str]:
    cf = config.cloudflare
    assert cf is not None
    flags: list[str] = []
    if cf.environment:
        flags += ["--env", cf.environment]
    if cf.worker:
        flags += ["--name", cf.worker]
    return flags


def _render_site_file(content: object) -> str:
    if isinstance(content, str):
        return content
    return json.dumps(content, indent=2, ensure_ascii=False) + "\n"


@contextlib.contextmanager
def _site_files(files: Mapping[str, object], service_dir: Path, out: Console) -> Iterator[None]:
    """Write ``site_files`` for the duration of the site build only.

    A file left behind would be picked up by the next local build of the
    same tree, so each one is removed afterwards (or restored, if it was
    there before), along with any directory created for it.
    """
    written: list[tuple[Path, bytes | None, list[Path]]] = []
    try:
        for name, content in files.items():
            path = service_dir / name
            new_dirs: list[Path] = []
            parent = path.parent
            while not parent.exists():
                new_dirs.append(parent)
                parent = parent.parent
            original = path.read_bytes() if path.is_file() else None
            path.parent.mkdir(parents=True, exist_ok=True)
            written.append((path, original, new_dirs))
            path.write_text(_render_site_file(content))
            out.print(f"    wrote {name}")
        yield
    finally:
        for path, original, new_dirs in reversed(written):
            if original is None:
                path.unlink(missing_ok=True)
            else:
                path.write_bytes(original)
            for directory in new_dirs:
                with contextlib.suppress(OSError):
                    directory.rmdir()


def _run_site_build(cf: CloudflareConfig, service_dir: Path, out: Console) -> None:
    if not cf.site_build:
        return
    out.print(f"[bold]==> Building site: {cf.site_build}[/bold]")
    env = {**os.environ, **cf.site_env}
    for key, value in cf.site_env.items():
        out.print(f"    {key}={value}")
    with _site_files(cf.site_files, service_dir, out):
        res = subprocess.run(cf.site_build, shell=True, cwd=service_dir, env=env)
    if res.returncode != 0:
        raise CloudflareError(f"site build failed: {cf.site_build}")


def _upload_secrets(
    wrangler: Wrangler,
    out: Console,
    names: list[str],
    env_vars: Mapping[str, str],
    *,
    prefix: list[str],
    suffix: list[str],
) -> None:
    for name in names:
        value = env_vars.get(name, "")
        if not value:
            raise CloudflareError(f"secret '{name}' is not set (Doppler or environment)")
        wrangler.run([*prefix, name, *suffix], input_text=value)
        out.print(f"    {name}")


def _wait_for(target: str, *, attempts: int = 24, delay: float = 5) -> None:
    """Poll *target* until it answers.

    Sends a ``zap-cli`` User-Agent: Cloudflare's browser integrity check
    answers 403 to urllib's default ``Python-urllib/x.y``, so a healthy site
    behind a Cloudflare zone could never pass a plain ``urlopen``.
    """
    request = urllib.request.Request(target, headers={"User-Agent": USER_AGENT})
    for _ in range(attempts):
        try:
            with urllib.request.urlopen(request, timeout=10):
                return
        except Exception:
            time.sleep(delay)
    raise CloudflareError(f"target did not answer: {target}")


def _json_object(raw: bytes) -> dict[str, Any]:
    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, UnicodeDecodeError):
        return {}
    return data if isinstance(data, dict) else {}


def _api_errors(payload: Mapping[str, Any]) -> str:
    messages: list[str] = []
    for error in payload.get("errors") or []:
        if isinstance(error, dict):
            code = error.get("code")
            message = error.get("message", "")
            messages.append(f"[{code}] {message}" if code else str(message))
    return "; ".join(messages) or "no error details"


class CloudflareApi:
    """The few Cloudflare REST calls wrangler has no command for.

    Pages custom domains and their DNS records are only reachable through the
    API, so a Pages deploy talks to it directly with the same token wrangler
    uses.
    """

    base_url = "https://api.cloudflare.com/client/v4"

    def __init__(self, token: str, account_id: str) -> None:
        self.token = token
        self.account_id = account_id

    def request(
        self,
        method: str,
        path: str,
        body: Mapping[str, object] | None = None,
    ) -> tuple[int, dict[str, Any]]:
        data = None if body is None else json.dumps(body).encode()
        req = urllib.request.Request(
            self.base_url + path,
            data=data,
            method=method,
            headers={
                "Authorization": f"Bearer {self.token}",
                "Content-Type": "application/json",
                "User-Agent": USER_AGENT,
            },
        )
        try:
            with urllib.request.urlopen(req, timeout=30) as res:
                return res.status, _json_object(res.read())
        except urllib.error.HTTPError as exc:
            return exc.code, _json_object(exc.read())
        except urllib.error.URLError as exc:
            raise CloudflareError(f"Cloudflare API {method} {path} unreachable: {exc.reason}") from exc

    def call(
        self,
        method: str,
        path: str,
        body: Mapping[str, object] | None = None,
        *,
        missing_ok: bool = False,
    ) -> Any:
        status, payload = self.request(method, path, body)
        if missing_ok and status == 404:
            return None
        if status >= 400 or payload.get("success") is False:
            raise CloudflareError(
                f"Cloudflare API {method} {path} failed (HTTP {status}): {_api_errors(payload)}"
            )
        return payload.get("result")

    def _pages_path(self, project: str = "") -> str:
        path = f"/accounts/{self.account_id}/pages/projects"
        return f"{path}/{quote(project, safe='')}" if project else path

    def get_pages_project(self, name: str) -> dict[str, Any] | None:
        result = self.call("GET", self._pages_path(name), missing_ok=True)
        return result if isinstance(result, dict) else None

    def create_pages_project(self, name: str, production_branch: str) -> dict[str, Any]:
        result = self.call(
            "POST",
            self._pages_path(),
            {"name": name, "production_branch": production_branch},
        )
        return result if isinstance(result, dict) else {}

    def pages_domains(self, project: str) -> list[str]:
        result = self.call("GET", self._pages_path(project) + "/domains")
        return [
            entry["name"]
            for entry in result or []
            if isinstance(entry, dict) and isinstance(entry.get("name"), str)
        ]

    def add_pages_domain(self, project: str, domain: str) -> None:
        self.call("POST", self._pages_path(project) + "/domains", {"name": domain})

    def find_zone(self, hostname: str) -> tuple[str, str] | None:
        labels = hostname.split(".")
        for start in range(len(labels) - 1):
            candidate = ".".join(labels[start:])
            query = urlencode({"name": candidate, "account.id": self.account_id})
            for zone in self.call("GET", f"/zones?{query}") or []:
                if (
                    isinstance(zone, dict)
                    and zone.get("name") == candidate
                    and isinstance(zone.get("id"), str)
                ):
                    return zone["id"], candidate
        return None

    def dns_records(self, zone_id: str, name: str) -> list[dict[str, Any]]:
        query = urlencode({"name": name})
        result = self.call("GET", f"/zones/{zone_id}/dns_records?{query}")
        return [record for record in result or [] if isinstance(record, dict)]

    def create_cname(self, zone_id: str, name: str, target: str) -> None:
        self.call(
            "POST",
            f"/zones/{zone_id}/dns_records",
            {"type": "CNAME", "name": name, "content": target, "proxied": True, "ttl": 1},
        )


class CloudflareDeployer:
    def __init__(
        self,
        config: DeploymentConfig,
        service_dir: Path,
        wrangler: Wrangler,
        *,
        out: Console,
        env_vars: Mapping[str, str],
    ) -> None:
        self.config = config
        self.service_dir = service_dir
        self.wrangler = wrangler
        self.out = out
        self.env_vars = dict(env_vars)

    def run(self) -> None:
        cf = self.config.cloudflare
        assert cf is not None
        self.ensure_resources()
        self.apply_migrations()
        self.build_site()
        self.put_secrets()
        self.deploy()
        self.healthcheck()

    def wrangler_config_path(self) -> Path:
        cf = self.config.cloudflare
        assert cf is not None
        return self.service_dir / cf.config

    def deploy_config_path(self) -> Path:
        cf = self.config.cloudflare
        assert cf is not None
        if cf.generated_config:
            return self.service_dir / cf.generated_config
        return self.wrangler_config_path()

    def ensure_resources(self) -> None:
        cf = self.config.cloudflare
        assert cf is not None
        d1_ids: dict[str, tuple[str, str]] = {}
        kv_ids: dict[str, str] = {}
        has_resources = bool(cf.d1 or cf.kv or cf.queues)
        wants_config = bool(
            cf.generated_config
            or cf.patch_config
            and (cf.d1 or cf.kv or cf.queues or cf.worker or cf.custom_domains)
        )
        if not has_resources and not wants_config:
            return
        if has_resources:
            self.out.print("[bold]==> Ensuring Cloudflare resources exist[/bold]")
        for d1_entry in cf.d1:
            if not d1_entry.database:
                raise CloudflareError(f"d1 binding '{d1_entry.binding}' has no database name")
            ident, _ = ensure_d1(self.wrangler, d1_entry.database)
            d1_ids[d1_entry.binding] = (d1_entry.database, ident)
        for kv_entry in cf.kv:
            if not kv_entry.namespace:
                raise CloudflareError(f"kv binding '{kv_entry.binding}' has no namespace")
            ident, _ = ensure_kv(self.wrangler, kv_entry.namespace)
            kv_ids[kv_entry.binding] = ident
        for old, new in cf.queues.items():
            ensure_queue(self.wrangler, new or old)
        if cf.generated_config:
            base = self.wrangler_config_path()
            if not base.is_file():
                raise CloudflareError(f"wrangler config not found: {base}")
            out = self.deploy_config_path()
            text, changes = patch_wrangler_config(base.read_text(), cf, d1_ids=d1_ids, kv_ids=kv_ids)
            text, migrations_changes = _rebase_relative_paths(text, base.parent, out.parent)
            changes.extend(migrations_changes)
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text(text)
            for change in changes:
                self.out.print(f"    {change}")
            if not changes:
                self.out.print(f"    generated config up to date: {out}")
            else:
                self.out.print(f"    generated {out} from {base}")
        elif cf.patch_config:
            path = self.wrangler_config_path()
            if not path.is_file():
                raise CloudflareError(f"wrangler config not found: {path}")
            text, changes = patch_wrangler_config(path.read_text(), cf, d1_ids=d1_ids, kv_ids=kv_ids)
            path.write_text(text)
            for change in changes:
                self.out.print(f"    {change}")
            if not changes:
                self.out.print("    config already up to date")

    def apply_migrations(self) -> None:
        cf = self.config.cloudflare
        assert cf is not None
        if not cf.migrate or not cf.d1:
            return
        self.out.print("[bold]==> Applying D1 migrations (remote)[/bold]")
        path = self.deploy_config_path()
        for d1_entry in cf.d1:
            self.wrangler.run(
                ["d1", "migrations", "apply", d1_entry.database, "--remote", "--config", str(path)]
            )

    def build_site(self) -> None:
        cf = self.config.cloudflare
        assert cf is not None
        _run_site_build(cf, self.service_dir, self.out)

    def put_secrets(self) -> None:
        cf = self.config.cloudflare
        assert cf is not None
        if not cf.secrets:
            return
        self.out.print("[bold]==> Uploading worker secrets[/bold]")
        _upload_secrets(
            self.wrangler,
            self.out,
            cf.secrets,
            self.env_vars,
            prefix=["secret", "put"],
            suffix=_deploy_flags(self.config),
        )

    def deploy(self) -> None:
        cf = self.config.cloudflare
        assert cf is not None
        self.out.print("[bold]==> Deploying worker[/bold]")
        args = ["deploy", "--config", str(self.deploy_config_path())]
        for key, value in cf.vars.items():
            args += ["--var", f"{key}:{value}"]
        for domain in cf.custom_domains:
            args += ["--domain", domain]
        args += _deploy_flags(self.config)
        self.wrangler.run(args)

    def healthcheck(self) -> None:
        target = self.config.healthcheck.target
        if self.config.healthcheck.type != "curl" or not target:
            return
        self.out.print(f"[bold]==> Waiting for worker to answer at {target}[/bold]")
        _wait_for(target)


class PagesDeployer:
    def __init__(
        self,
        config: DeploymentConfig,
        service_dir: Path,
        wrangler: Wrangler,
        api: CloudflareApi,
        *,
        out: Console,
        env_vars: Mapping[str, str],
    ) -> None:
        self.config = config
        self.service_dir = service_dir
        self.wrangler = wrangler
        self.api = api
        self.out = out
        self.env_vars = dict(env_vars)

    @property
    def cf(self) -> CloudflareConfig:
        cf = self.config.cloudflare
        assert cf is not None
        return cf

    @property
    def pages(self) -> CloudflarePages:
        pages = self.cf.pages
        assert pages is not None
        return pages

    def run(self) -> None:
        project = self.ensure_project()
        self.ensure_domains(project)
        self.build_site()
        self.put_secrets()
        self.deploy()
        self.healthcheck()

    def ensure_project(self) -> dict[str, Any]:
        pages = self.pages
        self.out.print("[bold]==> Ensuring Pages project exists[/bold]")
        project = self.api.get_pages_project(pages.project)
        if project is None:
            self.out.print(
                f"    Pages project '{pages.project}' missing — creating "
                f"(production branch '{pages.branch}')"
            )
            return self.api.create_pages_project(pages.project, pages.branch)
        self.out.print(f"    Pages project '{pages.project}' already exists")
        production = project.get("production_branch")
        if isinstance(production, str) and production and production != pages.branch:
            raise CloudflareError(
                f"Pages project '{pages.project}' publishes branch '{production}' to "
                f"production, but this config uploads branch '{pages.branch}' — that "
                f"would only be a preview deployment. Set cloudflare.pages.branch: {production}"
            )
        return project

    def ensure_domains(self, project: Mapping[str, Any]) -> None:
        domains = _unique_domains(self.cf.custom_domains)
        if not domains:
            return
        pages = self.pages
        subdomain = project.get("subdomain")
        target = subdomain if isinstance(subdomain, str) and subdomain else f"{pages.project}.pages.dev"
        self.out.print("[bold]==> Ensuring custom domains[/bold]")
        attached = set(self.api.pages_domains(pages.project))
        for domain in domains:
            if domain in attached:
                self.out.print(f"    {domain} already attached to '{pages.project}'")
            else:
                self.api.add_pages_domain(pages.project, domain)
                self.out.print(f"    {domain} attached to '{pages.project}'")
            self.ensure_dns(domain, target)

    def ensure_dns(self, domain: str, target: str) -> None:
        zone = self.api.find_zone(domain)
        if zone is None:
            self.out.print(
                f"[yellow]    WARNING: no zone for {domain} in this account — add a "
                f"proxied CNAME {domain} -> {target} where its DNS lives[/yellow]"
            )
            return
        zone_id, zone_name = zone
        records = self.api.dns_records(zone_id, domain)
        if not records:
            self.api.create_cname(zone_id, domain, target)
            self.out.print(f"    DNS CNAME {domain} -> {target} created in {zone_name}")
            return
        record = records[0]
        if record.get("type") == "CNAME" and record.get("content") == target:
            self.out.print(f"    DNS CNAME {domain} -> {target} already set")
            return
        self.out.print(
            f"[yellow]    WARNING: {domain} already has a {record.get('type')} record -> "
            f"{record.get('content')} in {zone_name}; left unchanged (Pages expects a "
            f"CNAME to {target})[/yellow]"
        )

    def build_site(self) -> None:
        _run_site_build(self.cf, self.service_dir, self.out)

    def put_secrets(self) -> None:
        if not self.cf.secrets:
            return
        self.out.print("[bold]==> Uploading Pages secrets[/bold]")
        _upload_secrets(
            self.wrangler,
            self.out,
            self.cf.secrets,
            self.env_vars,
            prefix=["pages", "secret", "put"],
            suffix=["--project-name", self.pages.project],
        )

    def deploy(self) -> None:
        pages = self.pages
        output = self.service_dir / pages.output_dir
        if not output.is_dir():
            raise CloudflareError(f"Pages output directory not found: {output}")
        self.out.print(f"[bold]==> Deploying {pages.output_dir} to Pages '{pages.project}'[/bold]")
        stdout = self.wrangler.run(
            [
                "pages",
                "deploy",
                pages.output_dir,
                "--project-name",
                pages.project,
                "--branch",
                pages.branch,
                "--commit-dirty=true",
            ]
        )
        for line in stdout.splitlines():
            if ".pages.dev" in line:
                self.out.print(f"    {line.strip()}")

    def healthcheck(self) -> None:
        target = self.config.healthcheck.target
        if self.config.healthcheck.type != "curl" or not target:
            return
        self.out.print(f"[bold]==> Waiting for Pages to answer at {target}[/bold]")
        _wait_for(target)


def _run_pages_deploy(
    config: DeploymentConfig,
    service_dir: Path,
    env: Mapping[str, str],
    env_vars: Mapping[str, str],
) -> None:
    """Deploy a Pages project with a throwaway wrangler cache.

    ``wrangler pages`` stores the account it last used in
    ``node_modules/.cache/wrangler/pages.json`` and prefers it over
    ``CLOUDFLARE_ACCOUNT_ID``, so deploying one service directory to a second
    account would reuse the first one. ``WRANGLER_CACHE_DIR`` points wrangler
    at an empty cache for this run instead.
    """
    with tempfile.TemporaryDirectory(prefix="zap-wrangler-") as cache_dir:
        wrangler = Wrangler(service_dir, {**env, "WRANGLER_CACHE_DIR": cache_dir}, console)
        api = CloudflareApi(env["CLOUDFLARE_API_TOKEN"], env["CLOUDFLARE_ACCOUNT_ID"])
        PagesDeployer(config, service_dir, wrangler, api, out=console, env_vars=env_vars).run()


def run_cloudflare_deploy(
    config: DeploymentConfig,
    service_dir: Path,
    *,
    env_vars: Mapping[str, str] | None = None,
) -> None:
    cf = config.cloudflare
    assert cf is not None
    merged = dict(os.environ if env_vars is None else env_vars)
    env = wrangler_env(config, merged)
    if cf.pages is not None:
        _run_pages_deploy(config, service_dir, env, merged)
        target = config.healthcheck.target or f"{cf.pages.project}.pages.dev"
        console.print(f"[bold]==> Pages answering on {target}.[/bold]")
        console.print("[bold green]==> Deploy Completed Successfully![/bold green]")
        return
    wrangler = Wrangler(service_dir, env, console)
    deployer = CloudflareDeployer(config, service_dir, wrangler, out=console, env_vars=merged)
    deployer.run()
    console.print(f"[bold]==> Worker answering on {config.healthcheck.target or cf.worker}.[/bold]")
    console.print("[bold green]==> Deploy Completed Successfully![/bold green]")


def render_cloudflare_dry_run(
    config: DeploymentConfig,
    config_path: Path,
    service_dir: Path,
) -> None:
    cf = config.cloudflare
    assert cf is not None
    console.print()
    console.print(
        Panel(
            "[bold]ZAP Deploy (Cloudflare)[/bold]",
            border_style="magenta",
            padding=(0, 2),
        )
    )
    console.print()
    console.print(f"[bold]Application:[/bold] {config.zap.name}")
    console.print(f"[dim]Config:[/dim]      {config_path}")
    console.print(f"[dim]Service dir:[/dim] {service_dir}")

    table = Table.grid(padding=(0, 2), pad_edge=False)
    table.add_column(style="cyan", no_wrap=True)
    table.add_column()
    cfg_path = service_dir / cf.config
    if cf.pages is not None:
        table.add_row("Pages project:", cf.pages.project)
        table.add_row("Account:", cf.account_id or "-")
        table.add_row("Branch:", cf.pages.branch)
        table.add_row("Output dir:", str(service_dir / cf.pages.output_dir))
        table.add_row("Site build:", cf.site_build or "-")
    else:
        table.add_row("Worker:", cf.worker or "-")
        table.add_row("Account:", cf.account_id or "-")
        table.add_row("Environment:", cf.environment or "-")
        table.add_row("Wrangler config (base):", str(cfg_path))
        if cf.generated_config:
            table.add_row("Generated config:", str(service_dir / cf.generated_config))
        table.add_row("Site build:", cf.site_build or "-")
        table.add_row("Migrations:", "yes" if cf.migrate else "no")
        table.add_row("Patch config:", "yes" if cf.patch_config else "no")
    console.print()
    console.print("[bold]Cloudflare[/bold]")
    console.print(table)

    if cf.d1:
        rows = [(f"{e.binding}:", e.database or "-") for e in cf.d1]
        t = Table.grid(padding=(0, 2), pad_edge=False)
        t.add_column(style="cyan", no_wrap=True)
        t.add_column()
        for key, value in rows:
            t.add_row(key, value)
        console.print()
        console.print("[bold]D1[/bold]")
        console.print(t)
    if cf.kv:
        t = Table.grid(padding=(0, 2), pad_edge=False)
        t.add_column(style="cyan", no_wrap=True)
        t.add_column()
        for e in cf.kv:
            t.add_row(f"{e.binding}:", e.namespace or "-")
        console.print()
        console.print("[bold]KV[/bold]")
        console.print(t)
    if cf.queues:
        t = Table.grid(padding=(0, 2), pad_edge=False)
        t.add_column(style="cyan", no_wrap=True)
        t.add_column()
        for old, new in cf.queues.items():
            t.add_row(f"{old}:", new or "-")
        console.print()
        console.print("[bold]Queues[/bold]")
        console.print(t)
    if cf.custom_domains:
        t = Table.grid(padding=(0, 2), pad_edge=False)
        t.add_column(style="cyan", no_wrap=True)
        t.add_column()
        for domain in cf.custom_domains:
            t.add_row("domain:", domain)
        console.print()
        if cf.pages is not None:
            console.print("[bold]Custom domains (Pages domain + DNS CNAME)[/bold]")
        else:
            console.print("[bold]Custom domains (--domain)[/bold]")
        console.print(t)
    if cf.vars:
        t = Table.grid(padding=(0, 2), pad_edge=False)
        t.add_column(style="cyan", no_wrap=True)
        t.add_column()
        for key, value in cf.vars.items():
            t.add_row(f"{key}:", value)
        console.print()
        console.print("[bold]Vars (--var)[/bold]")
        console.print(t)
    if cf.site_env:
        t = Table.grid(padding=(0, 2), pad_edge=False)
        t.add_column(style="cyan", no_wrap=True)
        t.add_column()
        for key, value in cf.site_env.items():
            t.add_row(f"{key}:", Text(value) if value else Text('""'))
        console.print()
        console.print("[bold]Site env (exported into site_build)[/bold]")
        console.print(t)
    for name, content in cf.site_files.items():
        console.print()
        console.print(f"[bold]Site file {name} (written for site_build, removed after)[/bold]")
        if isinstance(content, str):
            console.print(Text(content), soft_wrap=True)
        else:
            console.print(JSON.from_data(content, ensure_ascii=False), soft_wrap=True)
    if cf.secrets:
        t = Table.grid(padding=(0, 2), pad_edge=False)
        t.add_column(style="cyan", no_wrap=True)
        t.add_column()
        for name in cf.secrets:
            t.add_row(f"{name}:", "(secret)")
        console.print()
        console.print("[bold]Secrets (wrangler secret put)[/bold]")
        console.print(t)

    console.print()
    console.print("[bold]Health check[/bold]")
    t = Table.grid(padding=(0, 2), pad_edge=False)
    t.add_column(style="cyan", no_wrap=True)
    t.add_column()
    t.add_row("Type:", config.healthcheck.type)
    t.add_row("Target:", config.healthcheck.target or "-")
    console.print(t)

    checks: list[tuple[str, Path, bool]] = [("wrangler config", cfg_path, True)]
    if cf.pages is not None:
        checks = [("functions dir", service_dir / "functions", False)]
        if not cf.site_build:
            checks.append(("output dir", service_dir / cf.pages.output_dir, True))
    console.print()
    console.print("[bold]File checks (resolved from service dir)[/bold]")
    check_table = Table.grid(padding=(0, 2), pad_edge=False)
    check_table.add_column(style="cyan", no_wrap=True)
    check_table.add_column()
    for label, path, required in checks:
        if path.exists():
            status = "[green]found[/green]"
        else:
            status = "[red]MISSING[/red]" if required else "[dim]none[/dim]"
        check_table.add_row(f"{label}:", status)
    console.print(check_table)

    console.print()
    console.print("[bold green]Dry run — no changes made.[/bold green]")
