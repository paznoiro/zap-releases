"""Project detection and the pre-build step for ``zb``.

A runtime-only Dockerfile — one ``FROM``, copying an artifact that something
else produced — cannot build the code it ships. ``docker build`` on its own
would then stamp today's git sha onto whatever artifact happens to be sitting
in ``build/``, so the image tag says one thing and the bytes say another.

This module works out how to produce that artifact from local source, which is
what CI does before it calls ``docker build``. A multi-stage Dockerfile
compiles inside the image, so nothing is pre-built for it.
"""

from __future__ import annotations

import re
import shutil
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path

_FROM_RE = re.compile(r"^\s*FROM\s", re.IGNORECASE | re.MULTILINE)

_JIB_PLUGIN_RE = re.compile(r"com\.google\.cloud\.tools\.jib", re.IGNORECASE)

_MAX_PARENT_WALK = 6

_PLAIN_JAR_SUFFIXES = ("-plain.jar", "-sources.jar", "-javadoc.jar")

_MAVEN_JAR_PREFIXES = ("original-",)


class BuildError(Exception):
    """The pre-build step could not be planned or completed."""


@dataclass(frozen=True)
class StageRule:
    """Copy ``source`` (a glob, relative to the service dir) to ``dest``."""

    source: str
    dest: str


@dataclass(frozen=True)
class BuildPlan:
    tool: str
    command: list[str]
    workdir: Path
    stage: tuple[StageRule, ...] = ()
    env: dict[str, str] = field(default_factory=dict)
    image_builder: str = "docker"


def dockerfile_from_count(dockerfile: Path) -> int:
    """Number of ``FROM`` instructions in *dockerfile* (0 if unreadable)."""
    try:
        return len(_FROM_RE.findall(dockerfile.read_text()))
    except OSError:
        return 0


def is_runtime_only(dockerfile: Path) -> bool:
    """True when the Dockerfile ships an artifact it does not build itself."""
    return dockerfile_from_count(dockerfile) == 1


def find_gradle_root(service_dir: Path) -> Path | None:
    """Nearest ancestor (or *service_dir*) holding a Gradle wrapper."""
    current = service_dir.resolve()
    for _ in range(_MAX_PARENT_WALK):
        if (current / "gradlew").is_file():
            return current
        if current.parent == current:
            break
        current = current.parent
    return None


def _gradle_module(gradle_root: Path, service_dir: Path) -> str:
    rel = service_dir.resolve().relative_to(gradle_root)
    if str(rel) == ".":
        return ""
    return ":" + ":".join(rel.parts)


def _read_build_files(directory: Path) -> str:
    text = ""
    for name in ("build.gradle.kts", "build.gradle"):
        candidate = directory / name
        if candidate.is_file():
            text += candidate.read_text()
    return text


def _gradle_plan(service_dir: Path) -> BuildPlan | None:
    gradle_root = find_gradle_root(service_dir)
    if gradle_root is None:
        return None
    module = _gradle_module(gradle_root, service_dir)
    declarations = _read_build_files(service_dir) or _read_build_files(gradle_root)

    task: str
    stage: tuple[StageRule, ...]
    if "org.springframework.boot" in declarations:
        task = "bootJar"
        stage = (StageRule("build/libs/*.jar", "build/libs/app.jar"),)
    elif "quarkus" in declarations:
        task = "quarkusBuild"
        stage = ()
    else:
        task = "assemble"
        stage = ()

    return BuildPlan(
        tool="gradle",
        command=["./gradlew", f"{module}:{task}" if module else task],
        workdir=gradle_root,
        stage=stage,
    )


def detect_jib(service_dir: Path) -> BuildPlan | None:
    """A Gradle project whose ``build.gradle`` applies the Jib plugin.

    Jib builds and pushes the image itself — no Dockerfile, no Docker daemon
    for push. ``jibDockerBuild`` loads into the local daemon (used when
    ``--no-push`` keeps the image local); ``jib`` pushes straight to the
    registry. The image reference comes from ``JIB_IMAGE``.
    """
    gradle_root = find_gradle_root(service_dir)
    if gradle_root is None:
        return None
    declarations = _read_build_files(service_dir) or _read_build_files(gradle_root)
    if not _JIB_PLUGIN_RE.search(declarations):
        return None
    module = _gradle_module(gradle_root, service_dir)
    return BuildPlan(
        tool="jib",
        command=["./gradlew", f"{module}:jib" if module else "jib"],
        workdir=gradle_root,
        image_builder="jib",
    )


def _maven_plan(service_dir: Path) -> BuildPlan | None:
    if not (service_dir / "pom.xml").is_file():
        return None
    mvn = "./mvnw" if (service_dir / "mvnw").is_file() else "mvn"
    return BuildPlan(
        tool="maven",
        command=[mvn, "-B", "-DskipTests", "package"],
        workdir=service_dir,
        stage=(StageRule("target/*.jar", "target/app.jar"),),
    )


def _go_plan(service_dir: Path, platform: str) -> BuildPlan | None:
    if not (service_dir / "go.mod").is_file():
        return None
    goos, _, goarch = platform.partition("/")
    env = {"CGO_ENABLED": "0"}
    if goos:
        env["GOOS"] = goos
    if goarch:
        env["GOARCH"] = goarch
    return BuildPlan(
        tool="go",
        command=["go", "build", "-o", "build/app", "."],
        workdir=service_dir,
        env=env,
    )


def _node_plan(service_dir: Path) -> BuildPlan | None:
    package_json = service_dir / "package.json"
    if not package_json.is_file():
        return None
    try:
        text = package_json.read_text()
    except OSError:
        return None
    if not re.search(r'"scripts"\s*:\s*\{[^}]*"build"\s*:', text, re.DOTALL):
        return None
    if (service_dir / "pnpm-lock.yaml").is_file():
        command = ["pnpm", "run", "build"]
    elif (service_dir / "yarn.lock").is_file():
        command = ["yarn", "build"]
    else:
        command = ["npm", "run", "build"]
    return BuildPlan(tool="node", command=command, workdir=service_dir)


def detect(service_dir: Path, platform: str = "linux/amd64") -> BuildPlan | None:
    """Infer how to build *service_dir* from local source.

    Returns ``None`` for project types that have nothing to compile ahead of
    ``docker build`` (Python, Rust and anything unrecognised), where the
    Dockerfile is expected to do the work itself.
    """
    for candidate in (
        _gradle_plan(service_dir),
        _maven_plan(service_dir),
        _go_plan(service_dir, platform),
        _node_plan(service_dir),
    ):
        if candidate is not None:
            return candidate
    return None


def plan_from_config(
    command: str | list[str],
    workdir: str,
    stage: dict[str, str],
    service_dir: Path,
) -> BuildPlan:
    """Build a plan from an explicit ``build:`` config section."""
    if isinstance(command, str):
        argv = command.split()
    else:
        argv = list(command)
    if not argv:
        raise BuildError("build.command is empty")
    root = service_dir if not workdir else (service_dir / workdir).resolve()
    return BuildPlan(
        tool="config",
        command=argv,
        workdir=root,
        stage=tuple(StageRule(src, dst) for src, dst in stage.items()),
    )


def _is_stageable(path: Path) -> bool:
    name = path.name
    if any(name.endswith(suffix) for suffix in _PLAIN_JAR_SUFFIXES):
        return False
    return not any(name.startswith(prefix) for prefix in _MAVEN_JAR_PREFIXES)


def _select_source(
    service_dir: Path,
    rule: StageRule,
    since: float | None,
) -> Path:
    matches = [p for p in sorted(service_dir.glob(rule.source)) if p.is_file()]
    dest = (service_dir / rule.dest).resolve()
    candidates = [
        p for p in matches if _is_stageable(p) and p.resolve() != dest
    ]
    if not candidates:
        raise BuildError(
            f"no artifact matched {rule.source} under {service_dir}"
        )
    if len(candidates) == 1:
        return candidates[0]

    # Several versions in one output directory: prefer whatever this build
    # just wrote. A build that was UP-TO-DATE writes nothing, so fall back to
    # the newest — and refuse to guess when that is a tie.
    pool = candidates
    if since is not None:
        fresh = [p for p in candidates if p.stat().st_mtime >= since]
        if fresh:
            pool = fresh
    newest = max(p.stat().st_mtime for p in pool)
    latest = [p for p in pool if p.stat().st_mtime == newest]
    if len(latest) == 1:
        return latest[0]
    listed = ", ".join(p.name for p in latest)
    raise BuildError(
        f"{rule.source} matched several artifacts of the same age ({listed}); "
        f"clean the output directory or set build.stage explicitly"
    )


def stage_artifacts(
    plan: BuildPlan,
    service_dir: Path,
    since: float | None = None,
) -> list[tuple[Path, Path]]:
    """Copy each staging rule's artifact into the path the Dockerfile copies.

    ``copy`` rather than ``copy2``: the destination's mtime is meant to answer
    "when did ``zb`` last stage this", which is the question the staleness
    check asks on a ``--no-compile`` run.
    """
    copied: list[tuple[Path, Path]] = []
    for rule in plan.stage:
        source = _select_source(service_dir, rule, since)
        dest = service_dir / rule.dest
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy(source, dest)
        copied.append((source, dest))
    return copied


def head_commit_time(directory: Path) -> float | None:
    """Commit timestamp of ``HEAD`` at *directory*, or ``None`` outside git."""
    res = subprocess.run(
        ["git", "-C", str(directory), "log", "-1", "--format=%ct"],
        capture_output=True,
        text=True,
    )
    if res.returncode != 0 or not res.stdout.strip():
        return None
    try:
        return float(res.stdout.strip())
    except ValueError:
        return None


def stale_artifacts(plan: BuildPlan, service_dir: Path) -> list[tuple[Path, str]]:
    """Staging destinations that are missing, or older than ``HEAD``.

    This is the failure ``zb`` used to ship silently: an artifact left over
    from an earlier checkout, wrapped in an image tagged with today's sha.
    """
    head = head_commit_time(service_dir)
    findings: list[tuple[Path, str]] = []
    for rule in plan.stage:
        dest = service_dir / rule.dest
        if not dest.is_file():
            findings.append((dest, "missing"))
            continue
        if head is not None and dest.stat().st_mtime < head:
            age = time.strftime(
                "%Y-%m-%d %H:%M", time.localtime(dest.stat().st_mtime)
            )
            findings.append((dest, f"older than HEAD (built {age})"))
    return findings
