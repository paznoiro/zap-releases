"""``zap release`` / ``zr`` command.

Cuts a GitHub Release that triggers the build+deploy pipeline. It ONLY
creates a GitHub Release — no build, no version pin, no commit, no push.
The release builds from origin/main.

Ported from zaprelease.sh.
"""

from __future__ import annotations

import re
import subprocess
from pathlib import Path
from typing import Annotated, Literal

import typer
from rich.console import Console

app = typer.Typer(
    name="release",
    help="Cut a GitHub Release that triggers the build+deploy pipeline.",
    no_args_is_help=True,
)

console = Console()
err_console = Console(stderr=True)


# ---------------------------------------------------------------------------
# Pure logic (unit-testable, no git/gh required)
# ---------------------------------------------------------------------------
def parse_repo_from_origin(url: str) -> str:
    """Extract ``owner/name`` from an ssh/https/git origin remote URL."""
    url = url.removesuffix(".git")
    m = re.search(r"([^/:]+/[^/:]+)$", url)
    if not m:
        raise ValueError(f"could not parse owner/name from origin url: {url!r}")
    return m.group(1)


def next_version(latest: str | None, bump: str) -> str:
    """Compute the next ``vX.Y.Z`` version from the latest tag and a bump."""
    if not latest:
        return "v0.1.0"
    m = re.fullmatch(r"v?(\d+)\.(\d+)\.(\d+)", latest)
    if not m:
        raise ValueError(f"cannot parse version tag: {latest!r}")
    maj, minor, pat = (int(m.group(1)), int(m.group(2)), int(m.group(3)))
    if bump == "major":
        return f"v{maj + 1}.0.0"
    if bump == "minor":
        return f"v{maj}.{minor + 1}.0"
    if bump == "patch":
        return f"v{maj}.{minor}.{pat + 1}"
    raise ValueError(f"invalid bump {bump!r} (expected patch/minor/major)")


def repo_relative_path(root: Path, config_path: str | Path) -> str:
    """Normalise a config path to be relative to the git repo root."""
    abs_path = Path(config_path).resolve()
    root_abs = root.resolve()
    try:
        rel = abs_path.relative_to(root_abs)
    except ValueError as exc:
        raise ValueError(
            f"config file must live inside the repo ({root_abs}): {abs_path}"
        ) from exc
    return str(rel)


def split_config_values(values: list[str] | None) -> list[str]:
    result: list[str] = []
    for value in values or []:
        for part in value.split(","):
            part = part.strip()
            if part:
                result.append(part)
    return result


def resolve_config_rels(root: Path, files: list[str]) -> list[str]:
    rels: list[str] = []
    for config_file in files:
        cfg = Path(config_file)
        if not cfg.is_file():
            raise ValueError(f"config file not found: {cfg}")
        rels.append(repo_relative_path(root, cfg))
    return rels


def release_notes(config_rels: list[str]) -> str:
    return "\n".join(f"Deploy Config: {rel}" for rel in config_rels)


# ---------------------------------------------------------------------------
# git / gh wrappers
# ---------------------------------------------------------------------------
def _run(
    cmd: list[str],
    *,
    capture: bool = True,
    check: bool = False,
    cwd: Path | None = None,
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        cmd,
        capture_output=capture,
        text=True,
        check=check,
        cwd=cwd,
    )


def _check_tools() -> None:
    missing = [tool for tool in ("git", "gh") if _run([tool, "--version"]).returncode]
    if missing:
        for tool in missing:
            err_console.print(
                f"[bold red]ERROR:[/bold red] {tool} is required but not installed."
            )
        raise typer.Exit(code=1)


def _repo_root() -> Path:
    res = _run(["git", "rev-parse", "--show-toplevel"])
    if res.returncode != 0 or not res.stdout.strip():
        err_console.print("[bold red]ERROR:[/bold red] not inside a git repository.")
        raise typer.Exit(code=1)
    return Path(res.stdout.strip())


def _origin_url(repo: str | None, root: Path) -> str:
    if repo:
        return repo
    res = _run(["git", "-C", str(root), "remote", "get-url", "origin"])
    if res.returncode != 0 or not res.stdout.strip():
        err_console.print(
            "[bold red]ERROR:[/bold red] no 'origin' remote; pass --repo owner/name."
        )
        raise typer.Exit(code=1)
    try:
        return parse_repo_from_origin(res.stdout.strip())
    except ValueError as exc:
        err_console.print(f"[bold red]ERROR:[/bold red] {exc}")
        raise typer.Exit(code=1) from exc


def _latest_tag(root: Path) -> str | None:
    res = _run(
        ["git", "-C", str(root), "tag", "-l", "v*", "--sort=-v:refname"]
    )
    if res.returncode != 0:
        return None
    tags = [line for line in res.stdout.splitlines() if line.strip()]
    return tags[0] if tags else None


def _has_uncommitted(root: Path) -> bool:
    res = _run(["git", "-C", str(root), "status", "--porcelain"])
    return bool(res.stdout.strip())


def _local_head(root: Path) -> str:
    res = _run(["git", "-C", str(root), "rev-parse", "HEAD"])
    return res.stdout.strip()


def _remote_main_head(root: Path) -> str | None:
    res = _run(["git", "-C", str(root), "rev-parse", "origin/main"])
    if res.returncode != 0:
        return None
    return res.stdout.strip() or None


def _fetch_tags(root: Path) -> bool:
    res = _run(["git", "-C", str(root), "fetch", "--tags", "--quiet", "origin"])
    return res.returncode == 0


def _create_release(
    version: str,
    repo: str,
    *,
    config_rels: list[str] | None,
) -> int:
    cmd = [
        "gh",
        "release",
        "create",
        version,
        "--repo",
        repo,
        "--target",
        "main",
        "--title",
        version,
    ]
    if config_rels:
        cmd += ["--notes", release_notes(config_rels)]
    else:
        cmd += ["--generate-notes"]
    return _run(cmd, capture=False, check=True).returncode


# ---------------------------------------------------------------------------
# Command
# ---------------------------------------------------------------------------
@app.command()
def release(
    patch: Annotated[
        bool, typer.Option("--patch", help="Bump patch version (default).")
    ] = False,
    minor: Annotated[
        bool, typer.Option("--minor", help="Bump minor version.")
    ] = False,
    major: Annotated[
        bool, typer.Option("--major", help="Bump major version.")
    ] = False,
    version: Annotated[
        str | None,
        typer.Option("--version", help="Use an explicit version (e.g. v2.5.0)."),
    ] = None,
    config_file: Annotated[
        list[str] | None,
        typer.Option("--config", help="Deploy from <file> after build (repeatable or comma-separated; omit = build only)."),
    ] = None,
    repo: Annotated[
        str | None,
        typer.Option("--repo", help="Target GitHub repo (default: parsed from origin)."),
    ] = None,
    yes: Annotated[
        bool, typer.Option("--yes", "-y", help="Skip confirmation prompt."),
    ] = False,
) -> None:
    """Cut a GitHub Release that triggers the build+deploy pipeline."""
    _check_tools()
    root = _repo_root()

    chosen = sum([patch, minor, major])
    if chosen > 1:
        err_console.print(
            "[bold red]ERROR:[/bold red] --patch/--minor/--major are mutually exclusive."
        )
        raise typer.Exit(code=1)
    bump: Literal["patch", "minor", "major"] = "patch"
    if major:
        bump = "major"
    elif minor:
        bump = "minor"

    target_repo = _origin_url(repo, root)
    if "/" not in target_repo:
        err_console.print(
            f"[bold red]ERROR:[/bold red] invalid --repo '{target_repo}' "
            "(expected owner/name)."
        )
        raise typer.Exit(code=1)

    console.print(f"[bold]==> Target repo:[/bold] {target_repo}")

    # Warnings (release builds from origin/main).
    if _has_uncommitted(root):
        console.print(
            "[yellow]WARNING: uncommitted changes — the release builds from "
            "what is pushed to main, not your working tree.[/yellow]"
        )
    if not _fetch_tags(root):
        console.print(
            "[yellow]WARNING: could not fetch from origin (network/SSH?) "
            "— using local tags/refs.[/yellow]"
        )
    local = _local_head(root)
    remote = _remote_main_head(root)
    if remote and local != remote:
        console.print(
            f"[yellow]WARNING: local HEAD ({local}) differs from origin/main "
            f"({remote}) — did you push?[/yellow]"
        )

    # Version.
    if version:
        new_version = version
    else:
        latest = _latest_tag(root)
        new_version = next_version(latest, bump)
        console.print(
            f"[bold]==> Latest tag:[/bold] {latest or 'none'} "
            f"-> new version: {new_version} ({bump} bump)"
        )

    # Config (repo-relative).
    config_files = split_config_values(config_file)
    config_rels: list[str] = []
    if config_files:
        try:
            config_rels = resolve_config_rels(root, config_files)
        except ValueError as exc:
            err_console.print(f"[bold red]ERROR:[/bold red] {exc}")
            raise typer.Exit(code=1) from exc
        for rel in config_rels:
            console.print(f"[bold]==> Deploy config (repo-relative):[/bold] {rel}")

    # Confirm.
    if not yes:
        if config_rels:
            prompt = f"Create release {new_version} and deploy from {', '.join(config_rels)}?"
        else:
            prompt = f"Create release {new_version} (build only, no deploy)?"
        if not typer.confirm(prompt, default=False):
            console.print("Aborted.")
            raise typer.Exit(code=1)

    # Create the release (triggers the pipeline).
    _create_release(new_version, target_repo, config_rels=config_rels or None)
    if config_rels:
        console.print(
            f"[bold green]==> Release {new_version} published — "
            "pipeline is building and deploying.[/bold green]"
        )
    else:
        console.print(
            f"[bold green]==> Release {new_version} published — "
            "pipeline is building (build only).[/bold green]"
        )
    console.print(f"[bold]==> Pipeline:[/bold] https://github.com/{target_repo}/actions")
