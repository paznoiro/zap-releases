"""Configuration models, YAML loading, and variable interpolation.

Pipeline::

    YAML file
       |
       v  (PyYAML, raw dict)
    interpolation resolver  (env vars + YAML value references)
       |
       v  (resolved dict)
    Pydantic validation  -> DeploymentConfig

Access config via attributes::

    config.deploy.ssh.host
    config.docker.image
    config.caddy.domain
"""

from __future__ import annotations

import os
import re
from pathlib import Path, PurePosixPath
from typing import Any, Literal, Mapping

import yaml
from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    ValidationError,
    field_validator,
    model_validator,
)


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------
class ConfigError(Exception):
    """Any error while loading, interpolating, or validating a config."""


class InterpolationError(ConfigError):
    """A ``${...}`` reference could not be resolved."""


# ---------------------------------------------------------------------------
# Pydantic models  (Phase 4)
# ---------------------------------------------------------------------------
class _Strict(BaseModel):
    """Base model: reject unknown keys so config typos surface early."""

    model_config = ConfigDict(extra="forbid")


class ZapConfig(_Strict):
    name: str
    service_dir: str = ".."


class SSHConfig(_Strict):
    host: str
    port: int = 22
    user: str = "ubuntu"
    key: str = ""


class DeployConfig(_Strict):
    ssh: SSHConfig
    remote_dir: str
    init_postgres_dsn: str = ""
    init_postgres_ipv4: bool = True
    upload_files: list[str] = Field(default_factory=list)
    ensure_dirs: list[str] = Field(default_factory=list)


class DockerConfig(_Strict):
    image: str = ""
    network: str = ""


class ComposeConfig(_Strict):
    file: str = "docker-compose.yml"


class BuildConfig(_Strict):
    """Pre-build step for ``zb``: how to produce the artifact the image copies.

    Every field is optional; omitted, the project type is detected from the
    service directory (Gradle, Maven, Go, Node).
    """

    command: str | list[str] = ""
    workdir: str = ""
    stage: dict[str, str] = Field(default_factory=dict)
    skip: bool = False


class CaddyConfig(_Strict):
    domain: str = ""
    site_template: str = ""
    agents_domain: str = ""
    sites_dir: str = "/opt/caddy/sites"
    container: str = "caddy"
    cors_allowed_origins_regex: str = ""


class HealthCheckConfig(_Strict):
    type: Literal["curl", "docker", "none"] = "none"
    target: str = ""


class DopplerSection(_Strict):
    project: str
    config: str = ""


class DopplerConfig(_Strict):
    project: str = ""
    config: str = ""
    projects: list[DopplerSection] = Field(default_factory=list)
    env: dict[str, str] = Field(default_factory=dict)

    @model_validator(mode="before")
    @classmethod
    def _coerce(cls, data: object) -> object:
        if isinstance(data, list):
            return {"projects": data}
        return data

    @field_validator("env", mode="before")
    @classmethod
    def _coerce_env(cls, v: object) -> object:
        if not isinstance(v, dict):
            return v
        return {str(k): _stringify(val) for k, val in v.items()}


class CloudflareD1(_Strict):
    binding: str = "DB"
    database: str = ""
    migrations_dir: str = "migrations"


class CloudflareKV(_Strict):
    binding: str = "CACHE"
    namespace: str = ""


class CloudflarePages(_Strict):
    """A Cloudflare Pages project, deployed with ``wrangler pages deploy``.

    ``branch`` is both the branch every deploy uploads to and the production
    branch a newly created project gets, so the upload always lands on
    production rather than a preview alias.
    """

    project: str
    output_dir: str = "dist"
    branch: str = "production"


_WORKER_ONLY_FIELDS = (
    "worker",
    "environment",
    "config",
    "generated_config",
    "patch_config",
    "migrate",
    "d1",
    "kv",
    "queues",
    "vars",
)


class CloudflareConfig(_Strict):
    account_id: str = ""
    pages: CloudflarePages | None = None
    worker: str = ""
    environment: str = ""
    config: str = "wrangler.jsonc"
    generated_config: str = ""
    patch_config: bool = True
    migrate: bool = True
    site_build: str = ""
    site_env: dict[str, str] = Field(default_factory=dict)
    site_files: dict[str, Any] = Field(default_factory=dict)
    custom_domains: list[str] = Field(default_factory=list)
    d1: list[CloudflareD1] = Field(default_factory=list)
    kv: list[CloudflareKV] = Field(default_factory=list)
    queues: dict[str, str] = Field(default_factory=dict)
    vars: dict[str, str] = Field(default_factory=dict)
    secrets: list[str] = Field(default_factory=list)

    @field_validator("vars", "site_env", mode="before")
    @classmethod
    def _coerce_vars(cls, v: object) -> object:
        if not isinstance(v, dict):
            return v
        return {str(k): _stringify(val) for k, val in v.items()}

    @model_validator(mode="after")
    def _site_env_needs_build(self) -> CloudflareConfig:
        if self.site_env and not self.site_build:
            raise ValueError("'site_env' requires 'site_build' (nothing would consume it)")
        if self.site_files and not self.site_build:
            raise ValueError("'site_files' requires 'site_build' (nothing would consume it)")
        return self

    @field_validator("site_files")
    @classmethod
    def _site_files_stay_inside(cls, v: dict[str, Any]) -> dict[str, Any]:
        for name in v:
            path = PurePosixPath(name)
            if path.is_absolute() or ".." in path.parts or not path.parts:
                raise ValueError(
                    f"site_files path '{name}' must be relative to the service dir, without '..'"
                )
        return v

    @model_validator(mode="after")
    def _pages_excludes_worker_fields(self) -> CloudflareConfig:
        if self.pages is None:
            return self
        clashing = [name for name in _WORKER_ONLY_FIELDS if name in self.model_fields_set]
        if clashing:
            raise ValueError(
                "'pages' deploys a Pages project; these Worker-only keys do not apply: "
                + ", ".join(clashing)
            )
        return self


class DeploymentConfig(_Strict):
    """Root configuration model."""

    version: Literal[1] = 1
    zap: ZapConfig
    deploy: DeployConfig | None = None
    docker: DockerConfig = Field(default_factory=DockerConfig)
    compose: ComposeConfig = Field(default_factory=ComposeConfig)
    build: BuildConfig = Field(default_factory=BuildConfig)
    caddy: CaddyConfig = Field(default_factory=CaddyConfig)
    healthcheck: HealthCheckConfig = Field(default_factory=HealthCheckConfig)
    doppler: DopplerConfig = Field(default_factory=DopplerConfig)
    env: dict[str, str] = Field(default_factory=dict)
    cloudflare: CloudflareConfig | None = None

    @field_validator("env", mode="before")
    @classmethod
    def _coerce_env(cls, v: object) -> object:
        if not isinstance(v, dict):
            return v
        return {str(k): _stringify(val) for k, val in v.items()}

    @model_validator(mode="after")
    def _merge_doppler_env(self) -> DeploymentConfig:
        if self.doppler.env:
            self.env = {**self.doppler.env, **self.env}
        return self

    @model_validator(mode="after")
    def _require_target(self) -> DeploymentConfig:
        if self.deploy is None and self.cloudflare is None:
            raise ValueError("either 'deploy' or 'cloudflare' is required")
        return self


# ---------------------------------------------------------------------------
# Variable interpolation  (Phase 5)
# ---------------------------------------------------------------------------
# Matches:
#   $$            -> escaped literal '$'
#   ${NAME}       -> environment variable (no dot) or YAML dotted-path ref
#   ${NAME:-def}  -> environment variable with a default
_VAR_RE = re.compile(r"\$(\$|\{([^}]*)\})")


def _stringify(value: object) -> str:
    """Render a non-string YAML scalar the way YAML/JSON does."""
    if value is True:
        return "true"
    if value is False:
        return "false"
    if value is None:
        return "null"
    return str(value)


def _lookup_path(root: object, path: str) -> tuple[bool, object]:
    """Walk a dotted ``path`` through nested dicts/lists.

    Returns ``(found, value)``. List indices are accepted as numeric segments.
    """
    cur: object = root
    for part in path.split("."):
        if isinstance(cur, dict):
            d: dict[str, object] = cur
            if part in d:
                cur = d[part]
            else:
                return False, None
        elif isinstance(cur, list):
            try:
                idx = int(part)
            except ValueError:
                return False, None
            if 0 <= idx < len(cur):
                cur = cur[idx]
            else:
                return False, None
        else:
            return False, None
    return True, cur


def _resolve_string(
    value: str,
    root: object,
    env: Mapping[str, str],
    stack: tuple[str, ...],
) -> str:
    """Resolve every ``${...}`` in *value*."""

    def replace(match: re.Match[str]) -> str:
        if match.group(1) == "$":
            return "$"
        token = match.group(2)
        if token == "":
            raise InterpolationError("empty variable reference '${}'")
        # No dot -> environment variable, optionally with a default.
        if "." not in token:
            name, sep, default = token.partition(":-")
            if name in env:
                return env[name]
            if sep:
                return default
            raise InterpolationError(
                f"undefined environment variable '${{{token}}}'"
            )
        # Dotted path -> YAML value reference (resolved recursively).
        if token in stack:
            chain = " -> ".join(stack + (token,))
            raise InterpolationError(f"circular reference: {chain}")
        found, raw = _lookup_path(root, token)
        if not found:
            raise InterpolationError(f"undefined YAML reference '${{{token}}}'")
        if isinstance(raw, str):
            return _resolve_string(raw, root, env, stack + (token,))
        return _stringify(raw)

    return _VAR_RE.sub(replace, value)


def _resolve_node(
    node: object,
    root: object,
    env: Mapping[str, str],
    stack: tuple[str, ...],
) -> object:
    if isinstance(node, str):
        return _resolve_string(node, root, env, stack)
    if isinstance(node, dict):
        d: dict[str, object] = node
        return {k: _resolve_node(v, root, env, stack) for k, v in d.items()}
    if isinstance(node, list):
        return [_resolve_node(v, root, env, stack) for v in node]
    return node


def resolve_config(raw: object, env: Mapping[str, str] | None = None) -> object:
    """Recursively resolve ``${...}`` references in *raw*.

    * ``${VAR}`` (no dot) -> environment variable (hard error if unset)
    * ``${VAR:-def}``     -> environment variable with a default
    * ``${a.b.c}``        -> YAML dotted-path reference (hard error if unset)
    * ``$$``               -> literal ``$``
    """
    env_map = env if env is not None else os.environ
    return _resolve_node(raw, raw, env_map, ())


# ---------------------------------------------------------------------------
# Loader
# ---------------------------------------------------------------------------
def resolve_service_dir(config_path: str | Path, service_dir: str = "..") -> Path:
    """The service directory named by ``zap.service_dir``.

    ``service_dir`` is relative to the config file's own directory, so a
    config can live at any depth (``deploy/``, ``deployments/staging/``) as
    long as it says where its service is. The default ``..`` is the standard
    ``<service>/deployments/<file>.yaml`` layout.
    """
    config_dir = Path(config_path).resolve().parent
    resolved = (config_dir / Path(service_dir).expanduser()).resolve()
    if not resolved.is_dir():
        raise ConfigError(
            f"service dir not found: {resolved} "
            f"(zap.service_dir '{service_dir}' is relative to {config_dir})"
        )
    return resolved


def service_dir_for(config_path: str | Path) -> Path:
    """Service directory for a config file, read from its ``zap.service_dir``.

    Every relative path in the config (compose file, caddy template, ssh key,
    upload files, wrangler config, site build) is resolved against this
    directory, mirroring the original shell script. Works regardless of the
    caller's cwd because the config path is normalised to absolute first.
    """
    zap = parse_raw(config_path).get("zap")
    value = zap.get("service_dir", "..") if isinstance(zap, dict) else ".."
    if not isinstance(value, str) or not value.strip():
        raise ConfigError("zap.service_dir must be a path relative to the config file")
    return resolve_service_dir(config_path, value)


def parse_raw(path: str | Path) -> dict[str, object]:
    """Read and YAML-parse a config file, returning the raw mapping."""
    config_path = Path(path)
    if not config_path.is_file():
        raise ConfigError(f"config file not found: {config_path}")
    try:
        raw = yaml.safe_load(config_path.read_text())
    except yaml.YAMLError as exc:
        raise ConfigError(f"invalid YAML in {config_path}: {exc}") from exc
    if not isinstance(raw, dict):
        raise ConfigError(
            f"config must be a YAML mapping at the top level, "
            f"got {type(raw).__name__}"
        )
    return raw


def build_config(
    raw: dict[str, object],
    env: Mapping[str, str] | None = None,
) -> DeploymentConfig:
    """Interpolate and validate a raw config mapping."""
    try:
        resolved = resolve_config(raw, env)
    except InterpolationError as exc:
        raise ConfigError(f"interpolation error: {exc}") from exc
    try:
        return DeploymentConfig.model_validate(resolved)
    except ValidationError as exc:
        raise ConfigError(f"config validation failed:\n{exc}") from exc


def load_config(
    path: str | Path,
    env: Mapping[str, str] | None = None,
) -> DeploymentConfig:
    """Load, interpolate, and validate a deployment config file."""
    return build_config(parse_raw(path), env)
