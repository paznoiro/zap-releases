"""``zap build-deploy`` / ``zbd`` command.

Build the image from local source (like ``zb``), capture the tag, then
deploy it (like ``zd``) in one invocation:

    zbd employee-api/deployments/production.yaml
    zbd employee-api/deployments/production.yaml --tag v1.2.3
    zbd employee-api/deployments/production.yaml --dry-run

The tag is resolved once — ``--tag`` or the git short sha — and reused for
both phases so the deploy ships exactly what was just pushed. Docker-only;
Cloudflare (``cloudflare:``) configs must use ``zd``.
"""

from __future__ import annotations

import contextlib
import os
import shutil
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console

from .build import _local_tag, resolve_plan, run_build
from .config import ConfigError, build_config, parse_raw, service_dir_for
from .deploy import check_dependencies, render_dry_run, run_deploy
from .deploy import DeployError
from .doppler import DopplerError, _doppler_sections, fetch_secrets
from .project import BuildError
from .ssh import SSHError

app = typer.Typer(
    name="build-deploy",
    help="Build, push and deploy the service image from local source.",
    no_args_is_help=True,
)

console = Console()
err_console = Console(stderr=True)


@app.command()
def builddeploy(
    config_file: Annotated[
        Path,
        typer.Argument(
            help="Path to the deployment YAML config "
            "(e.g. employee-api/deployments/production.yaml).",
            metavar="CONFIG",
        ),
    ],
    tag: Annotated[
        str | None,
        typer.Option("--tag", help="Image tag (default: git short sha, or 'latest')."),
    ] = None,
    platform: Annotated[
        str,
        typer.Option("--platform", help="Target platform (default linux/amd64)."),
    ] = "linux/amd64",
    file: Annotated[
        str,
        typer.Option("--file", "-f", help="Dockerfile path (relative to service dir)."),
    ] = "Dockerfile",
    no_cache: Annotated[
        bool,
        typer.Option("--no-cache", help="Disable the Docker build cache."),
    ] = False,
    no_compile: Annotated[
        bool,
        typer.Option(
            "--no-compile",
            help="Skip the source build; ship the artifact already on disk.",
        ),
    ] = False,
    build_arg: Annotated[
        list[str] | None,
        typer.Option(
            "--build-arg",
            help="KEY=VAL build arg (repeatable).",
        ),
    ] = None,
    key: Annotated[
        Path | None,
        typer.Option("--key", help="Override the SSH key path."),
    ] = None,
    compose: Annotated[
        Path | None,
        typer.Option("--compose", help="Override the docker-compose file."),
    ] = None,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="Preview the build + deployment plan only."),
    ] = False,
) -> None:
    """Build, push and deploy the service described by CONFIG."""
    if not shutil.which("docker"):
        err_console.print("[bold red]ERROR:[/bold red] docker is required but not installed.")
        raise typer.Exit(code=1)

    key_override = key.resolve() if key else None
    compose_override = compose.resolve() if compose else None

    config_path = Path(config_file).resolve()
    try:
        service_dir = service_dir_for(config_file)
    except ConfigError as exc:
        err_console.print(f"[bold red]ERROR:[/bold red] {exc}")
        raise typer.Exit(code=1) from exc

    with contextlib.chdir(service_dir):
        if dry_run:
            try:
                raw = parse_raw(config_path)
                dry_secrets: dict[str, str] = {}
                for project, dconfig in _doppler_sections(raw):
                    try:
                        fetched = fetch_secrets(project, dconfig)
                    except DopplerError as exc:
                        console.print(
                            f"[yellow]WARNING: Doppler preview fetch failed "
                            f"({project} / {dconfig}): {exc}[/yellow]"
                        )
                        continue
                    dry_secrets.update(fetched)
                config = build_config(raw, {**os.environ, **dry_secrets})
            except ConfigError as exc:
                err_console.print(f"[bold red]ERROR:[/bold red] {exc}")
                raise typer.Exit(code=1) from exc
            if config.cloudflare is not None:
                err_console.print(
                    "[bold red]ERROR:[/bold red] zbd is for Docker deploys only; "
                    "this config has a cloudflare: section (use zd)."
                )
                raise typer.Exit(code=1)
            preview_tag = tag or _local_tag(service_dir)
            repo = config.env.get("IMAGE_REPO", "")
            console.print(f"[bold]==> Build preview: {repo}:{preview_tag}[/bold]")
            try:
                _, reason = resolve_plan(
                    config.build, service_dir, service_dir / file, platform
                )
                if reason:
                    console.print(f"[dim]    {reason}[/dim]")
            except BuildError as exc:
                err_console.print(f"[bold red]ERROR:[/bold red] {exc}")
                raise typer.Exit(code=1) from exc
            render_dry_run(
                config,
                config_path=config_path,
                service_dir=service_dir,
                tag=preview_tag,
                ssh_key=key_override,
                compose=compose_override,
            )
            return

        try:
            raw = parse_raw(config_path)
            secrets: dict[str, str] = {}
            for project, dconfig in _doppler_sections(raw):
                console.print(
                    f"[bold]==> Fetching secrets from Doppler "
                    f"({project} / {dconfig})[/bold]"
                )
                fetched = fetch_secrets(project, dconfig)
                for name in fetched:
                    console.print(f"  {name}")
                secrets.update(fetched)
                console.print(
                    f"[green]Secrets loaded into environment for {project} "
                    f"({dconfig})[/green]"
                )
            env_vars = {**os.environ, **secrets}
            config = build_config(raw, env_vars)
        except (ConfigError, DopplerError) as exc:
            err_console.print(f"[bold red]ERROR:[/bold red] {exc}")
            raise typer.Exit(code=1) from exc

        if config.cloudflare is not None:
            err_console.print(
                "[bold red]ERROR:[/bold red] zbd is for Docker deploys only; "
                "this config has a cloudflare: section (use zd)."
            )
            raise typer.Exit(code=1)
        if config.deploy is None:
            err_console.print(
                "[bold red]ERROR:[/bold red] deploy section is required for Docker deploys"
            )
            raise typer.Exit(code=1)

        repo = config.env.get("IMAGE_REPO", "")
        if not repo:
            err_console.print(
                "[bold red]ERROR:[/bold red] IMAGE_REPO is not set in the config's env: section."
            )
            raise typer.Exit(code=1)

        image_tag = tag or _local_tag(service_dir)
        console.print(f"[bold]==> Image Tag: {image_tag}[/bold]")

        run_build(
            config,
            service_dir,
            config_file,
            image_tag,
            platform=platform,
            file=file,
            no_cache=no_cache,
            no_compile=no_compile,
            build_arg=build_arg,
            no_push=False,
        )

        try:
            check_dependencies(config)
            run_deploy(
                config,
                service_dir,
                tag=image_tag,
                ssh_key=key_override,
                compose=compose_override,
                env_vars=env_vars,
            )
        except (SSHError, DeployError, ConfigError) as exc:
            err_console.print("")
            err_console.print("[bold red]!!! DEPLOY FAILED !!![/bold red]")
            err_console.print(f"[red]{exc}[/red]")
            raise typer.Exit(code=1) from exc
