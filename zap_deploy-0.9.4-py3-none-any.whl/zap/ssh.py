"""SSH/SCP abstraction (Phase 7).

A small wrapper around the ``ssh`` and ``scp`` binaries so deployment code
never sprinkles raw ``subprocess.run(["ssh", ...])`` calls. Mirrors the
behaviour of ``zapdeploy.sh``: ``StrictHostKeyChecking=accept-new``, the
configured key/port/user, and ``sudo tee`` for root-owned destinations.
"""

from __future__ import annotations

import os
import shlex
import subprocess

from .config import ConfigError


class SSHError(ConfigError):
    """A remote ssh/scp command failed."""


class SSHRunner:
    def __init__(self, host: str, port: int, user: str, key: str) -> None:
        self.host = host
        self.port = port
        self.user = user
        self.key = os.path.expanduser(key)

    @property
    def target(self) -> str:
        return f"{self.user}@{self.host}"

    def _ssh_args(self) -> list[str]:
        return [
            "ssh",
            "-p",
            str(self.port),
            "-i",
            self.key,
            "-o",
            "StrictHostKeyChecking=accept-new",
            f"{self.user}@{self.host}",
        ]

    def _scp_host(self) -> str:
        # IPv6 hosts need bracketed notation for scp.
        return f"[{self.host}]" if ":" in self.host else self.host

    def _scp_args(self, source: str, destination: str) -> list[str]:
        return [
            "scp",
            "-P",
            str(self.port),
            "-i",
            self.key,
            "-o",
            "StrictHostKeyChecking=accept-new",
            "-r",
            source,
            f"{self.user}@{self._scp_host()}:{destination}",
        ]

    def run(
        self,
        command: str,
        *,
        check: bool = True,
        input_text: str | None = None,
    ) -> str:
        """Run *command* on the remote host; return its stdout."""
        res = self._exec(self._ssh_args() + [command], input_text)
        if check and res.returncode != 0:
            raise SSHError(
                f"remote command failed (rc={res.returncode}): {command}"
                + (f"\n{res.stderr}" if res.stderr else "")
            )
        return res.stdout

    def run_capture(
        self,
        command: str,
        *,
        input_text: str | None = None,
    ) -> subprocess.CompletedProcess[str]:
        """Run *command* without raising; return the full result."""
        return self._exec(self._ssh_args() + [command], input_text)

    def upload(self, source: str, destination: str) -> None:
        """``scp -r`` a local file/dir to a remote directory (trailing ``/``)."""
        res = self._exec(self._scp_args(str(source), str(destination)), None)
        if res.returncode != 0:
            raise SSHError(
                f"scp failed: {res.stderr}" if res.stderr else "scp failed"
            )

    def upload_text(
        self,
        text: str,
        destination: str,
        *,
        sudo: bool = False,
    ) -> None:
        """Pipe *text* to a remote file via ``cat >`` (or ``sudo tee``)."""
        dest = shlex.quote(destination)
        if sudo:
            parent = shlex.quote(os.path.dirname(destination) or ".")
            cmd = f"sudo mkdir -p {parent} && sudo tee {dest} >/dev/null"
        else:
            cmd = f"cat > {dest}"
        self.run(cmd, input_text=text)

    def upload_file(
        self,
        source: str,
        destination: str,
        *,
        sudo: bool = False,
    ) -> None:
        """Upload a single regular file to an arbitrary remote destination."""
        with open(source, "r") as fh:
            self.upload_text(fh.read(), destination, sudo=sudo)

    def _exec(
        self,
        args: list[str],
        input_text: str | None,
    ) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            args,
            input=input_text,
            text=True,
            capture_output=True,
        )
