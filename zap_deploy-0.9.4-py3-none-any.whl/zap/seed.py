"""``zap seed`` / ``zs`` command.

Seed tenants via the native Python port of
``deploy-scripts/liquibase-migrate.sh`` (see ``zap.migrate``). Database
credentials, mode, schema, and migration paths come from the same YAML
``zc`` uses (a ``db:`` zapclean file with a ``migrate:`` section, or a
service deployment YAML)::

    zs employee-api/deployments/local.yaml zaporiondemo --dry-run
    zs employee-api/deployments/local.yaml zaporiondemo
    zs employee-api/deployments/staging.yaml zaporiondemo
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console

from .clean import CleanError, ensure_safe_identifier, normalize_db_url, normalize_mode, resolve_effective_config
from .migrate import MigrateSpec, describe_dry_run, run_migrate, split_db_url, split_tenant_refs

app = typer.Typer(
    name="seed",
    help="Seed tenants via Liquibase (native port, no shell scripts).",
    no_args_is_help=True,
)

console = Console()
err_console = Console(stderr=True)


def ensure_jdbc_url(url: str) -> str:
    """Return the JDBC form of a db URL for Liquibase."""
    cleaned = url.strip()
    _ = normalize_db_url(cleaned)
    return cleaned if cleaned.startswith("jdbc:") else "jdbc:" + cleaned


def build_spec(
    config_file: Path,
    tenant: str,
    *,
    mode: str | None = None,
    schema_name: str | None = None,
    tenant_id: str | None = None,
    app_name: str | None = None,
    tenants_file: Path | None = None,
    changelog_type: str = "common",
    schema_only: bool = False,
    maintenance_db: str | None = None,
    debug: bool = False,
) -> MigrateSpec:
    """Build a migration spec from a config file plus CLI overrides."""
    cfg = resolve_effective_config(config_file)
    refs = split_tenant_refs(tenant)
    if not refs:
        raise CleanError("provide at least one tenant.")
    for ref in refs:
        ensure_safe_identifier(ref, "tenant")
    resolved_mode = normalize_mode(mode) if mode is not None else cfg.target.mode
    if resolved_mode == "single-schema":
        schema = schema_name or cfg.target.schema_name
        if not schema:
            raise CleanError("single-schema seeding needs --schema-name or target.schema.")
    else:
        schema = ""
    raw_changelog = cfg.migrate.changelog_dir
    if not raw_changelog:
        raise CleanError("config has no migrate.changelog_dir for seeding.")
    changelog = Path(raw_changelog)
    if not changelog.is_absolute():
        changelog = config_file.parent / changelog
    changelog = Path(os.path.normpath(changelog))
    if tenants_file is not None:
        tenants_path: Path | None = tenants_file
    else:
        raw_tenants = cfg.migrate.tenants_file
        if not raw_tenants:
            sibling = config_file.parent / "tenants.properties"
            if sibling.is_file():
                raw_tenants = str(sibling)
        tenants_path = Path(raw_tenants) if raw_tenants else None
        if tenants_path is not None and not tenants_path.is_absolute():
            tenants_path = config_file.parent / tenants_path
    if changelog_type not in ("common", "tenant"):
        raise CleanError("--changelog-type must be 'common' or 'tenant'.")
    admin_db = (maintenance_db or "").strip()
    if not admin_db:
        db_name_var = (cfg.db.maintenance_db or os.environ.get("DB_NAME", "")).strip()
        _, target_db, _ = split_db_url(cfg.db.url)
        admin_db = db_name_var if db_name_var and db_name_var != target_db else "postgres"
    ensure_safe_identifier(admin_db, "maintenance database")
    return MigrateSpec(
        db_url=ensure_jdbc_url(cfg.db.url),
        db_user=cfg.db.user,
        db_pass=cfg.db.password,
        changelog_dir=changelog,
        mode=resolved_mode,
        schema_name=schema,
        changelog_type=changelog_type,
        tenants=refs,
        tenant_id_override=tenant_id or cfg.target.tenant_id,
        with_seed=not schema_only,
        app_name=app_name or cfg.migrate.app_name or cfg.target.app_name,
        tenants_file=tenants_path,
        debug=debug or os.environ.get("MIGRATE_DEBUG", "").strip().lower() in ("1", "true", "yes", "on"),
        liquibase_version=os.environ.get("LIQUIBASE_VERSION", "5.0.2"),
        pg_driver_version=os.environ.get("PG_DRIVER_VERSION", "42.7.5"),
        lock_wait_minutes=os.environ.get("LOCK_WAIT_MINUTES", "1"),
        connect_timeout=os.environ.get("DB_CONNECT_TIMEOUT", "15"),
        admin_db_name=admin_db,
    )


@app.command()
def seed(
    config_file: Annotated[
        Path,
        typer.Argument(
            help="Zapclean YAML (db: + migrate:) or deployment YAML.",
            metavar="CONFIG",
        ),
    ],
    tenant: Annotated[
        str,
        typer.Argument(help="Tenant alias(es), comma-separated.", metavar="TENANT"),
    ],
    mode: Annotated[
        str | None,
        typer.Option("--mode", help="Override the seed mode."),
    ] = None,
    schema_name: Annotated[
        str | None,
        typer.Option("--schema-name", help="Override the shared schema."),
    ] = None,
    tenant_id: Annotated[
        str | None,
        typer.Option("--tenant-id", help="Logical tenant_id override (single tenant only)."),
    ] = None,
    app_name: Annotated[
        str | None,
        typer.Option("--app-name", help="Override the application name."),
    ] = None,
    tenants_file: Annotated[
        Path | None,
        typer.Option("--tenants-file", help="Override the tenants file."),
    ] = None,
    changelog_type: Annotated[
        str,
        typer.Option("--changelog-type", help="common or tenant changelog."),
    ] = "common",
    schema_only: Annotated[
        bool,
        typer.Option("--schema-only", help="Migrate schema without seed data."),
    ] = False,
    maintenance_db: Annotated[
        str | None,
        typer.Option(
            "--maintenance-db",
            help="Admin database used to CREATE DATABASE when the target is missing "
            "(default: DB_NAME from the YAML env:, Doppler or the shell, else 'postgres').",
        ),
    ] = None,
    debug: Annotated[
        bool,
        typer.Option("--debug", help="Verbose Liquibase output."),
    ] = False,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="Preview the migration plan only."),
    ] = False,
) -> None:
    """Seed tenants via Liquibase."""
    try:
        spec = build_spec(
            Path(config_file).resolve(),
            tenant,
            mode=mode,
            schema_name=schema_name,
            tenant_id=tenant_id,
            app_name=app_name,
            tenants_file=tenants_file,
            changelog_type=changelog_type,
            schema_only=schema_only,
            maintenance_db=maintenance_db,
            debug=debug,
        )
    except CleanError as exc:
        err_console.print(f"[bold red]ERROR:[/bold red] {exc}")
        raise typer.Exit(code=1) from exc

    if dry_run:
        try:
            for line in describe_dry_run(spec):
                console.print(line)
        except CleanError as exc:
            err_console.print(f"[bold red]ERROR:[/bold red] {exc}")
            raise typer.Exit(code=1) from exc
        console.print("[bold green]Dry run — no changes made.[/bold green]")
        return

    try:
        code = run_migrate(spec, console)
    except CleanError as exc:
        err_console.print(f"[bold red]ERROR:[/bold red] {exc}")
        raise typer.Exit(code=1) from exc
    except Exception as exc:
        err_console.print(f"[bold red]ERROR:[/bold red] migration failed: {exc}")
        raise typer.Exit(code=1) from exc
    if code != 0:
        raise typer.Exit(code=code)


if __name__ == "__main__":
    app()
