"""``zap deploy`` / ``zd`` command.

Phases 6-9: load + validate config, render a dry-run preview, and execute the
full deployment by porting ``zapdeploy.sh`` step by step.

Path anchoring
--------------
Every relative path in the config (compose file, caddy template, ssh key,
upload files) is resolved against the *service directory* — ``zap.service_dir``
relative to the config file, by default its parent's parent (e.g.
``employee-api/`` for ``employee-api/deployments/x.yaml``), mirroring
``zapdeploy.sh`` which ``cd``s into ``$SERVICE_DIR``. The command changes into that directory so
relative paths resolve naturally; CLI overrides (--key/--compose) are
absolutised against the *caller's* cwd before the move.
"""

from __future__ import annotations

import contextlib
import os
import shlex
import shutil
import time
from collections.abc import Mapping
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from .cloudflare import (
    CloudflareError,
    check_dependencies as check_cloudflare_dependencies,
    render_cloudflare_dry_run as render_cf_dry_run,
    run_cloudflare_deploy as run_cf_deploy,
)
from .config import (
    ConfigError,
    DeploymentConfig,
    build_config,
    load_config,
    parse_raw,
    service_dir_for,
)
from .doppler import DopplerError, _doppler_sections, fetch_secrets
from .ssh import SSHError, SSHRunner

app = typer.Typer(
    name="deploy",
    help="Deploy a service to a remote host.",
    no_args_is_help=True,
)

console = Console()
err_console = Console(stderr=True)


# ---------------------------------------------------------------------------
# Rendering helpers
# ---------------------------------------------------------------------------
def _kv_table(rows: list[tuple[str, str]]) -> Table:
    """A borderless two-column key/value table with aligned values."""
    table = Table.grid(padding=(0, 2), pad_edge=False)
    table.add_column(style="cyan", no_wrap=True)
    table.add_column()
    for key, value in rows:
        table.add_row(key, value)
    return table


def _resolve_local(service_dir: Path, path: str) -> Path:
    """Resolve a config path relative to the service directory.

    ``~`` is expanded first; remaining relative paths anchor at service_dir.
    """
    expanded = Path(os.path.expanduser(path))
    if not expanded.is_absolute():
        expanded = service_dir / expanded
    return expanded


def _path_or_dash(path: str | Path | None) -> str:
    if not path:
        return "-"
    return str(path)


def _exists_status(path: Path) -> str:
    if path.exists():
        return "[green]found[/green]"
    return "[red]MISSING[/red]"


def render_dry_run(
    config: DeploymentConfig,
    config_path: Path,
    service_dir: Path,
    *,
    tag: str | None = None,
    ssh_key: Path | None = None,
    compose: Path | None = None,
) -> None:
    """Print a human-readable preview of the deployment plan."""
    deploy = config.deploy
    assert deploy is not None
    console.print()
    console.print(
        Panel(
            "[bold]ZAP Deploy[/bold]",
            border_style="magenta",
            padding=(0, 2),
        )
    )

    console.print()
    console.print(f"[bold]Application:[/bold] {config.zap.name}")
    console.print(f"[dim]Config:[/dim]      {config_path}")
    console.print(f"[dim]Service dir:[/dim] {service_dir}")

    # Target
    ssh = deploy.ssh
    effective_key = ssh_key or (
        _resolve_local(service_dir, ssh.key) if ssh.key else None
    )
    console.print()
    console.print("[bold]Target[/bold]")
    console.print(
        _kv_table(
            [
                ("Host:", ssh.host or "-"),
                ("Port:", str(ssh.port)),
                ("User:", ssh.user),
                ("Remote dir:", deploy.remote_dir),
                ("SSH key:", _path_or_dash(effective_key)),
            ]
        )
    )

    # Docker
    console.print()
    console.print("[bold]Docker[/bold]")
    console.print(
        _kv_table(
            [
                ("Image:", config.docker.image or "-"),
                ("Network:", config.docker.network or "-"),
            ]
        )
    )

    # Compose
    effective_compose = compose or _resolve_local(service_dir, config.compose.file)
    console.print()
    console.print("[bold]Compose[/bold]")
    console.print(_kv_table([("File:", str(effective_compose))]))

    # Caddy
    template: Path | None = None
    if config.caddy.domain or config.caddy.site_template:
        if config.caddy.site_template:
            template = _resolve_local(service_dir, config.caddy.site_template)
        console.print()
        console.print("[bold]Caddy[/bold]")
        console.print(
            _kv_table(
                [
                    ("Domain:", config.caddy.domain or "-"),
                    ("Agents domain:", config.caddy.agents_domain or "-"),
                    ("Site template:", _path_or_dash(template)),
                    ("Sites dir:", config.caddy.sites_dir),
                    ("Container:", config.caddy.container),
                ]
            )
        )

    # Health check
    console.print()
    console.print("[bold]Health check[/bold]")
    console.print(
        _kv_table(
            [
                ("Type:", config.healthcheck.type),
                ("Target:", config.healthcheck.target or "-"),
            ]
        )
    )

    # Doppler
    dop_entries: list[tuple[str, str]] = []
    if config.doppler.project:
        dop_entries.append((config.doppler.project, config.doppler.config))
    dop_entries += [(s.project, s.config) for s in config.doppler.projects]
    if dop_entries:
        console.print()
        console.print("[bold]Doppler[/bold]")
        rows: list[tuple[str, str]] = []
        for project, dconfig in dop_entries:
            rows.append(("Project:", project))
            rows.append(("Config:", dconfig or "-"))
        console.print(_kv_table(rows))

    # Env (compose environment)
    if config.env:
        console.print()
        console.print("[bold]Environment (compose .env)[/bold]")
        env_table = _kv_table([(f"{k}:", v) for k, v in config.env.items()])
        console.print(env_table)

    # Overrides
    if tag or ssh_key or compose:
        console.print()
        console.print("[bold]CLI overrides[/bold]")
        console.print(
            _kv_table(
                [
                    ("--tag:", tag or "-"),
                    ("--key:", _path_or_dash(ssh_key)),
                    ("--compose:", _path_or_dash(compose)),
                ]
            )
        )

    # Validation: confirm relative paths actually resolve from the service dir.
    checks: list[tuple[str, Path]] = [("compose file", effective_compose)]
    if template is not None:
        checks.append(("caddy template", template))
    if effective_key is not None:
        checks.append(("ssh key", effective_key))

    console.print()
    console.print("[bold]File checks (resolved from service dir)[/bold]")
    check_rows = [(f"{label}:", _exists_status(p)) for label, p in checks]
    console.print(_kv_table(check_rows))

    console.print()
    console.print("[bold green]Dry run — no changes made.[/bold green]")


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------
class DeployError(ConfigError):
    """A deployment precondition or step failed."""


# ---------------------------------------------------------------------------
# Dependency check
# ---------------------------------------------------------------------------
def check_dependencies(config: DeploymentConfig) -> None:
    deps = ["ssh", "scp", "docker"]
    if config.doppler.project or config.doppler.projects:
        deps.append("doppler")
    console.print("[bold]==> Checking dependencies...[/bold]")
    missing: list[str] = []
    for cmd in deps:
        if shutil.which(cmd):
            console.print(f"  [green][OK][/green] {cmd}")
        else:
            console.print(f"  [red][MISSING][/red] {cmd} is required but not installed.")
            missing.append(cmd)
    if missing:
        raise DeployError("Please install missing dependencies before deploying.")


# ---------------------------------------------------------------------------
# Deployer — faithful port of zapdeploy.sh
# ---------------------------------------------------------------------------
class Deployer:
    def __init__(
        self,
        config: DeploymentConfig,
        service_dir: Path,
        ssh: SSHRunner,
        *,
        compose_path: Path,
        image_tag: str,
        env_content: str,
        out: Console,
        env_vars: Mapping[str, str] | None = None,
    ) -> None:
        self.config = config
        if config.deploy is None:
            raise DeployError("deploy section is required for Docker deploys")
        self.deploy_cfg = config.deploy
        self.service_dir = service_dir
        self.ssh = ssh
        self.compose_path = compose_path
        self.image_tag = image_tag
        self.env_content = env_content
        self.out = out
        self.env_vars = dict(os.environ if env_vars is None else env_vars)

    def run(self) -> None:
        self.ensure_remote_dir()
        self.ensure_network()
        self.init_postgres()
        self.upload_files()
        self.ensure_dirs()
        self.configure_caddy()
        self.archive_current()
        self.upload_compose()
        self.pull_and_up()
        self.healthcheck()
        self.cleanup_images()

    # 1. Remote directory
    def ensure_remote_dir(self) -> None:
        remote = shlex.quote(self.deploy_cfg.remote_dir)
        self.out.print("[bold]==> Ensuring remote directory exists[/bold]")
        self.ssh.run(
            f"sudo mkdir -p {remote} && sudo chown -R $(whoami) {remote}"
        )

    # 2. Docker network
    def ensure_network(self) -> None:
        net = self.config.docker.network
        if not net:
            return
        nq = shlex.quote(net)
        self.out.print(
            f"[bold]==> Ensuring external docker network '{net}' exists[/bold]"
        )
        self.ssh.run(
            f"docker network inspect {nq} >/dev/null 2>&1 "
            f"|| docker network create {nq}"
        )

    # 3. Postgres initialization
    def init_postgres(self) -> None:
        dsn = self.deploy_cfg.init_postgres_dsn
        if not dsn:
            return
        # Spring's DB_URL is a JDBC URL (jdbc:postgresql://...). psql/libpq
        # wants a plain postgres:// URL, so strip the jdbc: prefix when present.
        # This makes `init_postgres_dsn: ${DB_JDBC_URL}/db?sslmode=require` and
        # `init_postgres_dsn: ${DB_DIRECT_URL}/db?sslmode=require` both work.
        if dsn.startswith("jdbc:"):
            dsn = dsn.removeprefix("jdbc:")
        if "?" in dsn:
            base, _, qs = dsn.partition("?")
            params = "?" + qs
        else:
            base, params = dsn, ""
        db_name = base.rsplit("/", 1)[-1]
        maint_db = self.env_vars.get("DB_NAME") or "postgres"
        maint_dsn = base.rsplit("/", 1)[0] + "/" + maint_db + params
        self.out.print(f"[bold]==> Ensuring database '{db_name}' exists[/bold]")
        mq = shlex.quote(maint_dsn)
        ipv4 = " -e PGPREFER_IPV4=1" if self.deploy_cfg.init_postgres_ipv4 else ""
        cmd = (
            f"docker run --rm{ipv4} alpine/psql {mq} -tAc "
            f'"SELECT 1 FROM pg_database WHERE datname=\'{db_name}\'" '
            "| grep -q 1 && echo '    already exists' "
            f"|| {{ docker run --rm{ipv4} alpine/psql {mq} -v ON_ERROR_STOP=1 "
            f'-c \'CREATE DATABASE "{db_name}"\' && echo \'    created\'; }}'
        )
        self.ssh.run(cmd)

    # 4. Upload extra files
    def upload_files(self) -> None:
        files = self.deploy_cfg.upload_files
        if not files:
            return
        remote = self.deploy_cfg.remote_dir
        self.out.print(
            f"[bold]==> Uploading files/directories: {', '.join(files)}[/bold]"
        )
        for entry in files:
            entry = entry.strip()
            if not entry:
                continue
            if ":" in entry:
                src, dest = (p.strip() for p in entry.split(":", 1))
                src_path = self.service_dir / src
                if not src_path.is_file():
                    raise DeployError(
                        f"UPLOAD_FILES dest-path form requires a regular file: '{src}'"
                    )
                self.out.print(f"    {src} -> {dest} (via sudo)")
                self.ssh.upload_file(str(src_path), dest, sudo=True)
            else:
                src_path = self.service_dir / entry
                self.ssh.upload(str(src_path), f"{remote}/")

    # 5. Ensure mount target directories
    def ensure_dirs(self) -> None:
        dirs = self.deploy_cfg.ensure_dirs
        if not dirs:
            return
        self.out.print("[bold]==> Ensuring mount target directories exist[/bold]")
        for entry in dirs:
            entry = entry.strip()
            if not entry:
                continue
            parts = entry.split(":")
            if len(parts) < 3:
                raise DeployError(
                    f"ENSURE_DIRS entry '{entry}' must specify path:owner:group"
                )
            dir_ = parts[0].strip()
            owner = parts[1].strip()
            group = parts[2].strip()
            mode = parts[3].strip() if len(parts) > 3 else "755"
            if not dir_ or not owner or not group:
                raise DeployError(
                    f"ENSURE_DIRS entry '{entry}' must specify path:owner:group"
                )
            self.out.print(f"    {dir_} (owner {owner}:{group}, mode {mode})")
            self.ssh.run(
                f"sudo mkdir -p {shlex.quote(dir_)} "
                f"&& sudo chown -R {shlex.quote(f'{owner}:{group}')} {shlex.quote(dir_)} "
                f"&& sudo chmod {shlex.quote(mode)} {shlex.quote(dir_)}"
            )

    # 6. Caddy configuration
    def configure_caddy(self) -> None:
        caddy = self.config.caddy
        if not caddy.site_template:
            return
        template_path = self.service_dir / caddy.site_template
        if not template_path.is_file():
            self.out.print(
                f"[yellow]    WARNING: caddy template not found: "
                f"{template_path}[/yellow]"
            )
            return
        app_name = os.path.basename(self.deploy_cfg.remote_dir)
        site_name = f"{app_name}.caddy"
        snippet = template_path.read_text()
        snippet = snippet.replace("{{DOMAIN}}", caddy.domain)
        snippet = snippet.replace("{{CADDY_DOMAIN}}", caddy.domain)
        snippet = snippet.replace("{{CADDY_AGENTS_DOMAIN}}", caddy.agents_domain)
        if caddy.cors_allowed_origins_regex:
            snippet = snippet.replace(
                "{{CORS_ALLOWED_ORIGINS_REGEX}}", caddy.cors_allowed_origins_regex
            )
        snippet = f"# zapdeploy:app={app_name}\n{snippet}"

        upstream_line = ""
        for line in snippet.splitlines():
            if line.strip().startswith("reverse_proxy "):
                upstream_line = "".join(line.split())
                break

        sites_dir = caddy.sites_dir
        site_path = f"{sites_dir}/{site_name}"
        self.out.print(
            f"[bold]==> Writing Caddy site snippet "
            f"({site_name} -> {caddy.domain or '<no domain>'}) "
            "and reloading Caddy[/bold]"
        )
        self.ssh.upload_text(snippet, site_path, sudo=True)

        stale = self._stale_snippet_cmd(sites_dir, site_name, app_name, upstream_line)
        self.ssh.run(stale)

        container = caddy.container
        status = self.ssh.run(
            "docker inspect --format "
            + shlex.quote("{{.State.Status}}")
            + f" {shlex.quote(container)} 2>/dev/null",
            check=False,
        ).strip()
        if "running" in status:
            self.ssh.run(
                f"docker exec {shlex.quote(container)} caddy reload "
                "--config /etc/caddy/Caddyfile 2>&1 "
                f"|| docker restart {shlex.quote(container)}"
            )
        else:
            self.out.print(
                f"[yellow]    WARNING: Caddy container '{container}' "
                "not running.[/yellow]"
            )

    @staticmethod
    def _stale_snippet_cmd(
        sites_dir: str,
        site_name: str,
        app_name: str,
        upstream_line: str,
    ) -> str:
        sd = shlex.quote(sites_dir)
        sn = shlex.quote(site_name)
        marker = shlex.quote(f"^# zapdeploy:app={app_name}$")
        ul = shlex.quote(upstream_line)
        return (
            f'for f in {sd}/*.caddy; do\n'
            '  [ -e "$f" ] || continue\n'
            f'  [ "$(basename "$f")" = {sn} ] && continue\n'
            f'  if grep -q {marker} "$f" 2>/dev/null; then\n'
            '    echo "    removing stale snippet: $f"; sudo rm -f "$f"; continue\n'
            "  fi\n"
            "  if [ -n " + ul + " ] && grep -E "
            "'^[[:space:]]*reverse_proxy[[:space:]]' \"$f\" 2>/dev/null "
            "| tr -d '[:space:]' | grep -qxF -- " + ul + "; then\n"
            '    echo "    removing stale snippet (same upstream): $f"; '
            'sudo rm -f "$f"\n'
            "  fi\n"
            "done"
        )

    # 7. Archive current deployment
    def archive_current(self) -> None:
        remote = shlex.quote(self.deploy_cfg.remote_dir)
        self.out.print("[bold]==> Archiving current setup[/bold]")
        self.ssh.run(
            f"cd {remote} && TS=$(date +%Y%m%d-%H%M%S) && "
            "if ls .env docker-compose*.yml >/dev/null 2>&1; then "
            "mkdir -p archive/$TS && "
            "cp -p .env docker-compose*.yml archive/$TS/ 2>/dev/null || true; "
            "fi && "
            "{ ls -dt archive/*/ 2>/dev/null | tail -n +11 | xargs -r rm -rf || true; }"
        )

    # 8. Upload compose
    def upload_compose(self) -> None:
        remote = self.deploy_cfg.remote_dir
        dest = f"{remote}/docker-compose.yml"
        self.out.print("[bold]==> Copying compose file[/bold]")
        self.ssh.upload_text(self.compose_path.read_text(), dest, sudo=False)

    # 9-10. Pull and start containers (in-memory .env via tmpfs)
    #
    # The tmpfs file serves two distinct purposes and both are needed:
    # --env-file feeds *interpolation* of the compose file (${IMAGE_TAG}), while
    # ZAP_ENV_FILE is what a compose `env_file:` entry points at to *inject* the
    # variables into the container. Without the export, a compose file that has
    # dropped its `environment:` block starts with no configuration at all.
    def pull_and_up(self) -> None:
        remote = shlex.quote(self.deploy_cfg.remote_dir)
        self.out.print("[bold]==> Starting containers (in-memory .env via tmpfs)[/bold]")
        script = (
            "set -e\n"
            "TMPFILE=$(mktemp -p /dev/shm 2>/dev/null || mktemp)\n"
            'chmod 600 "$TMPFILE"\n'
            'trap "rm -f \\"$TMPFILE\\"" EXIT\n'
            'cat > "$TMPFILE"\n'
            f"cd {remote}\n"
            'export ZAP_ENV_FILE="$TMPFILE"\n'
            'docker compose --env-file "$TMPFILE" pull\n'
            'docker compose --env-file "$TMPFILE" up -d\n'
        )
        self.ssh.run(script, input_text=self.env_content)

    # 11. Health check
    def healthcheck(self) -> None:
        hc = self.config.healthcheck
        if hc.type == "docker":
            self._healthcheck_docker(hc.target)
        elif hc.type == "curl":
            self._healthcheck_curl(hc.target)

    def _healthcheck_docker(self, target: str) -> None:
        self.out.print(f"[bold]==> Waiting for {target} to become healthy...[/bold]")
        status = "unknown"
        for _ in range(40):
            status = self.ssh.run(
                "docker inspect -f " + shlex.quote("{{.State.Health.Status}}")
                + f" {shlex.quote(target)} 2>/dev/null",
                check=False,
            ).strip()
            if status == "healthy":
                return
            time.sleep(10)
        self.out.print(f"[red]ERROR: {target} not healthy. Logs:[/red]")
        self.ssh.run(f"docker logs {shlex.quote(target)} 2>&1 | tail -20")
        raise DeployError(f"{target} did not become healthy")

    def _healthcheck_curl(self, target: str) -> None:
        self.out.print(f"[bold]==> Waiting for app to answer at {target}[/bold]")
        for _ in range(24):
            res = self.ssh.run_capture(
                f"curl -s -o /dev/null --timeout 5 {shlex.quote(target)}",
            )
            if res.returncode == 0:
                return
            time.sleep(5)
        raise DeployError(f"target did not answer: {target}")

    # 12. Image cleanup
    def cleanup_images(self) -> None:
        repo = self.config.env.get("IMAGE_REPO", "")
        if not repo:
            return
        self.out.print(f"[bold]==> Removing old app images for {repo}[/bold]")
        rq = shlex.quote(repo)
        fmt = "{{.Repository}}:{{.Tag}}"
        if self.image_tag:
            self.ssh.run(
                f"docker images {rq} --format '{fmt}' "
                f"| grep -v ':{self.image_tag}$' "
                "| xargs -r docker rmi 2>/dev/null || true",
                check=False,
            )
        else:
            self.ssh.run(
                f"docker image prune -a --filter 'label=repo={repo}' -f",
                check=False,
            )


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------
def build_env_content(config: DeploymentConfig, image_tag: str) -> str:
    env = dict(config.env)
    env["IMAGE_TAG"] = image_tag
    return "".join(f"{k}={v}\n" for k, v in env.items())


def run_deploy(
    config: DeploymentConfig,
    service_dir: Path,
    *,
    tag: str | None,
    ssh_key: Path | None,
    compose: Path | None,
    env_vars: Mapping[str, str] | None = None,
) -> None:
    if config.deploy is None:
        raise DeployError("deploy section is required for Docker deploys")
    deploy = config.deploy
    ssh_cfg = deploy.ssh
    key_path = ssh_key or (
        _resolve_local(service_dir, ssh_cfg.key) if ssh_cfg.key else None
    )
    if not key_path or not key_path.is_file():
        raise DeployError(f"ssh key file not found: {key_path}")
    compose_path = compose or _resolve_local(service_dir, config.compose.file)
    if not compose_path.is_file():
        raise DeployError(f"compose file not found: {compose_path}")

    image_tag = tag or config.env.get("IMAGE_TAG", "latest")
    env_content = build_env_content(config, image_tag)
    console.print(f"[bold]==> Image Tag: {image_tag}[/bold]")

    ssh = SSHRunner(
        host=ssh_cfg.host, port=ssh_cfg.port, user=ssh_cfg.user, key=str(key_path)
    )
    console.print(
        f"[bold]==> Target: {ssh.user}@{ssh.host}:{deploy.remote_dir}[/bold]"
    )

    deployer = Deployer(
        config,
        service_dir,
        ssh,
        compose_path=compose_path,
        image_tag=image_tag,
        env_content=env_content,
        out=console,
        env_vars=env_vars,
    )
    deployer.run()
    repo = config.env.get("IMAGE_REPO", "")
    console.print(
        f"[bold]==> App answering on {config.caddy.domain}. "
        f"Deployed {repo}:{image_tag}[/bold]"
    )
    console.print("[bold green]==> Deploy Completed Successfully![/bold green]")


# ---------------------------------------------------------------------------
# Command
# ---------------------------------------------------------------------------
@app.command()
def deploy(
    config_file: Annotated[
        Path,
        typer.Argument(
            help="Path to the deployment YAML config "
            "(e.g. employee-api/deployments/production.yaml).",
            metavar="CONFIG",
        ),
    ],
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="Preview the deployment plan only."),
    ] = False,
    tag: Annotated[
        str | None,
        typer.Option("--tag", help="Override the image tag (e.g. v1.2.3)."),
    ] = None,
    key: Annotated[
        Path | None,
        typer.Option("--key", help="Override the SSH key path."),
    ] = None,
    compose: Annotated[
        Path | None,
        typer.Option("--compose", help="Override the docker-compose file."),
    ] = None,
) -> None:
    """Deploy the service described by CONFIG."""
    # CLI-supplied paths are relative to the CALLER'S cwd, so absolutise them
    # before we change into the service directory (mirrors zapdeploy.sh).
    key_override = key.resolve() if key else None
    compose_override = compose.resolve() if compose else None

    config_path = Path(config_file).resolve()
    try:
        service_dir = service_dir_for(config_file)
    except ConfigError as exc:
        err_console.print(f"[bold red]ERROR:[/bold red] {exc}")
        raise typer.Exit(code=1) from exc

    # Operate from the service directory so every relative path in the config
    # (compose, caddy template, ssh key, uploads) resolves naturally.
    with contextlib.chdir(service_dir):
        if dry_run:
            try:
                # Two-pass load so Doppler-backed ${VAR} references
                # (e.g. cloudflare.account_id) resolve in the preview.
                # Best-effort: a preview must still work when Doppler is
                # unreachable (e.g. fixture configs); configs that truly
                # need the secrets then fail on interpolation with a clear
                # "undefined environment variable" error.
                raw = parse_raw(config_path)
                dry_secrets: dict[str, str] = {}
                for project, dconfig in _doppler_sections(raw):
                    try:
                        fetched = fetch_secrets(project, dconfig)
                    except DopplerError as exc:
                        console.print(
                            f"[yellow]WARNING: Doppler preview fetch failed "
                            f"({project} / {dconfig}): {exc}[/yellow]"
                        )
                        continue
                    dry_secrets.update(fetched)
                config = build_config(raw, {**os.environ, **dry_secrets})
            except ConfigError as exc:
                err_console.print(f"[bold red]ERROR:[/bold red] {exc}")
                raise typer.Exit(code=1) from exc
            if config.cloudflare is not None:
                if tag or key or compose:
                    console.print(
                        "[yellow]--tag/--key/--compose are ignored for Cloudflare deploys[/yellow]"
                    )
                render_cf_dry_run(
                    config,
                    config_path=config_path,
                    service_dir=service_dir,
                )
                return
            render_dry_run(
                config,
                config_path=config_path,
                service_dir=service_dir,
                tag=tag,
                ssh_key=key_override,
                compose=compose_override,
            )
            return

        # Real deployment: two-pass load so Doppler secrets feed interpolation.
        try:
            raw = parse_raw(config_path)
            secrets: dict[str, str] = {}
            for project, dconfig in _doppler_sections(raw):
                console.print(
                    f"[bold]==> Fetching secrets from Doppler "
                    f"({project} / {dconfig})[/bold]"
                )
                fetched = fetch_secrets(project, dconfig)
                for name in fetched:
                    console.print(f"  {name}")
                secrets.update(fetched)
                console.print(
                    f"[green]Secrets loaded into environment for {project} "
                    f"({dconfig})[/green]"
                )
            env_vars = {**os.environ, **secrets}
            config = build_config(raw, env_vars)
        except (ConfigError, DopplerError) as exc:
            err_console.print(f"[bold red]ERROR:[/bold red] {exc}")
            raise typer.Exit(code=1) from exc

        if config.cloudflare is not None:
            try:
                check_cloudflare_dependencies(config)
                run_cf_deploy(config, service_dir, env_vars=env_vars)
            except (CloudflareError, ConfigError) as exc:
                err_console.print("")
                err_console.print("[bold red]!!! DEPLOY FAILED !!![/bold red]")
                err_console.print(f"[red]{exc}[/red]")
                raise typer.Exit(code=1) from exc
            return

        try:
            check_dependencies(config)
            run_deploy(
                config,
                service_dir,
                tag=tag,
                ssh_key=key_override,
                compose=compose_override,
                env_vars=env_vars,
            )
        except (SSHError, DeployError, ConfigError) as exc:
            err_console.print("")
            err_console.print("[bold red]!!! DEPLOY FAILED !!![/bold red]")
            err_console.print(f"[red]{exc}[/red]")
            raise typer.Exit(code=1) from exc
