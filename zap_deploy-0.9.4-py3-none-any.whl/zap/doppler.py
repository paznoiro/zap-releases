"""Doppler secrets (Phase 9).

Fetches secrets from the Doppler CLI as JSON (no ``eval``, NUL-safe by
construction in Python) and returns them as a ``dict``. The secrets are used
for ``${VAR}`` interpolation *before* Pydantic validation — they are not added
to the compose ``.env`` unless listed under the config's ``env:`` section,
mirroring ``zapdeploy.sh`` where only ``ENV.*`` lines reach the ``.env`` file.
"""

from __future__ import annotations

import json
import os
import re
import subprocess
from typing import Any

from .config import ConfigError

_VALID_NAME = re.compile(r"[a-zA-Z_][a-zA-Z0-9_]*")


class DopplerError(ConfigError):
    """Fetching Doppler secrets failed."""


def fetch_secrets(project: str, config: str = "") -> dict[str, str]:
    """Download secrets for *project*/*config* via the Doppler CLI."""
    if not os.environ.get("DOPPLER_TOKEN"):
        raise DopplerError("DOPPLER_TOKEN is not exported")
    cmd = [
        "doppler",
        "secrets",
        "download",
        "-p",
        project,
        "--format",
        "json",
        "--no-file",
    ]
    if config:
        cmd += ["-c", config]
    res = subprocess.run(cmd, capture_output=True, text=True)
    if res.returncode != 0:
        raise DopplerError(
            f"doppler secrets download failed: {res.stderr.strip()}"
        )
    try:
        data = json.loads(res.stdout)
    except json.JSONDecodeError as exc:
        raise DopplerError(f"invalid Doppler JSON: {exc}") from exc
    return _normalise(data)


def _doppler_sections(raw: dict[str, object]) -> list[tuple[str, str]]:
    """Extract ``(project, config)`` pairs from the raw ``doppler:`` section.

    Accepts either a single mapping (``project``/``config``, or ``projects``)
    or a list of mappings. Returns ``[]`` when there is no usable section.
    Used by the two-pass load so Doppler secrets feed ``${VAR}``
    interpolation before Pydantic validation.
    """
    entries: list[tuple[str, str]] = []
    dop = raw.get("doppler")
    if isinstance(dop, dict):
        project = dop.get("project")
        if isinstance(project, str) and project:
            config = dop.get("config")
            entries.append((project, config if isinstance(config, str) else ""))
        listed = dop.get("projects")
        if isinstance(listed, list):
            entries.extend(_parse_doppler_entries(listed))
    elif isinstance(dop, list):
        entries.extend(_parse_doppler_entries(dop))
    return entries


def _parse_doppler_entries(items: list[object]) -> list[tuple[str, str]]:
    entries: list[tuple[str, str]] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        project = item.get("project")
        if not isinstance(project, str) or not project:
            continue
        config = item.get("config")
        entries.append((project, config if isinstance(config, str) else ""))
    return entries


def _doppler_section(raw: dict[str, object]) -> tuple[str, str] | None:
    """Return the first ``(project, config)`` pair, or ``None``."""
    sections = _doppler_sections(raw)
    return sections[0] if sections else None


def _normalise(data: Any) -> dict[str, str]:
    """Flatten Doppler's JSON into ``{name: value}`` with valid env names."""
    secrets: dict[str, str] = {}
    if not isinstance(data, dict):
        return secrets
    for key, value in data.items():
        if not _VALID_NAME.fullmatch(key):
            continue
        if isinstance(value, dict):
            # Doppler may emit {"raw": ..., "computedValue": ...}.
            value = value.get("computedValue") or value.get("raw") or ""
        if isinstance(value, str):
            secrets[key] = value
    return secrets
