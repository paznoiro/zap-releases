"""Native Python port of ``deploy-scripts/liquibase-migrate.sh`` orchestration.

Covers the same changelog layout, tenant resolution, template-seed
staging, phase ordering, and registry writes as the shell script. The
Liquibase Java CLI still executes the changelogs themselves, so a Java
runtime is required, but no shell script is involved.
"""

from __future__ import annotations

import os
import re
import shutil
import stat
import subprocess
import tarfile
import tempfile
import urllib.request
import uuid
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from urllib.parse import parse_qsl, urlsplit, urlunsplit

from rich.console import Console

from .clean import CleanError

UUID_RE = re.compile(
    r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"
)
VERSION_CHUNK_RE = re.compile(r"(\d+|\D+)")
CHANGESET_OPEN_RE = re.compile(r"<changeSet[ >]")
VALID_CHECKSUM_RE = re.compile(r"<validCheckSum>")
CHANGESET_CLOSE_RE = re.compile(r"</changeSet>")
LOGICAL_PATH_RE = re.compile(r'logicalFilePath="[^"]*"')

DEFAULT_LIQUIBASE_VERSION = "5.0.2"
DEFAULT_PG_DRIVER_VERSION = "42.7.5"

MASTER_CHANGELOG = "db.changelog-master.xml"
TENANT_MASTER_CHANGELOG = "db.changelog-tenant-master.xml"
GLOBAL_MASTER_CHANGELOG = "db.changelog-global-master.xml"


@dataclass(frozen=True)
class ManifestEntry:
    """One tenant manifest: directory alias plus target schema."""

    alias: str
    schema: str


@dataclass
class MigrateSpec:
    """All inputs for one migration run (mirrors the script's env/flags)."""

    db_url: str
    db_user: str
    db_pass: str
    changelog_dir: Path
    mode: str = "multi-schema"
    schema_name: str = ""
    changelog_type: str = "common"
    tenants: list[str] = field(default_factory=list)
    tenant_id_override: str = ""
    with_seed: bool = False
    app_name: str = ""
    tenants_file: Path | None = None
    debug: bool = False
    liquibase_version: str = DEFAULT_LIQUIBASE_VERSION
    pg_driver_version: str = DEFAULT_PG_DRIVER_VERSION
    lock_wait_minutes: str = "1"
    connect_timeout: str = "15"
    admin_db_name: str = "postgres"
    cache_dir: Path | None = None
    liquibase_bin: Path | None = None
    driver_jar: Path | None = None


@dataclass(frozen=True)
class TenantTarget:
    """One resolved tenant: ref, schema, id, and client ids."""

    ref: str
    schema: str
    tenant_id: str
    clients: list[str]


def default_cache_dir() -> Path:
    """User cache location for the Liquibase CLI and JDBC driver."""
    base = os.environ.get("XDG_CACHE_HOME") or str(Path.home() / ".cache")
    return Path(base) / "zap-cli"


def version_sort_key(name: str) -> tuple[Any, ...]:
    """Sort key matching ``sort -V`` for changelog file names."""

    def zero_padded(part: str) -> str:
        return part.zfill(32) if part.isdigit() else part

    return tuple(zero_padded(p) for p in VERSION_CHUNK_RE.split(name) if p != "")


def list_changelog_files(directory: Path) -> list[Path]:
    """Version-sorted ``*.xml`` files directly inside a directory."""
    if not directory.is_dir():
        return []
    return sorted(
        (p for p in directory.iterdir() if p.is_file() and p.suffix == ".xml"),
        key=lambda p: version_sort_key(p.name),
    )


def split_db_url(url: str) -> tuple[str, str, str]:
    """Split a JDBC URL into host, database name, and query params."""
    no_params = url.split("?", 1)[0]
    params = url[len(no_params) + 1 :] if "?" in url else ""
    name = no_params.rsplit("/", 1)[-1]
    after_scheme = no_params.split("://", 1)[-1]
    host = after_scheme.split("/", 1)[0]
    return host, name, params


def apply_connect_timeout(url: str, seconds: str) -> tuple[str, bool]:
    """Append JDBC connect/login timeouts unless already present."""
    if "connectTimeout=" in url:
        return url, False
    sep = "&" if "?" in url else "?"
    return (
        f"{url}{sep}connectTimeout={seconds}&loginTimeout={seconds}",
        True,
    )


def libpq_conninfo(jdbc_url: str, base_db: str, timeout: int) -> str:
    """Translate a JDBC URL to a libpq conninfo for psycopg probes."""
    cleaned = jdbc_url.strip()
    if cleaned.startswith("jdbc:"):
        cleaned = cleaned[len("jdbc:") :]
    parts = urlsplit(cleaned)
    kept = [
        (k, v)
        for k, v in parse_qsl(parts.query, keep_blank_values=True)
        if k.lower()
        not in (
            "connecttimeout",
            "logintimeout",
            "currentschema",
            "options",
            "applicationname",
            "sockettimeout",
        )
    ]
    rebuilt = urlunsplit(
        (parts.scheme, parts.netloc, "/" + base_db, "&".join(f"{k}={v}" for k, v in kept), "")
    )
    _ = timeout
    return rebuilt


def ensure_tools(spec: MigrateSpec, console: Console) -> tuple[Path, Path]:
    """Download Liquibase and the JDBC driver unless cached."""
    if spec.liquibase_bin is not None and spec.driver_jar is not None:
        return spec.liquibase_bin, spec.driver_jar
    if shutil.which("java") is None:
        raise CleanError("java is required to run Liquibase but was not found.")
    cache = spec.cache_dir or (default_cache_dir() / f"liquibase-{spec.liquibase_version}")
    cache.mkdir(parents=True, exist_ok=True)
    liquibase_bin = cache / "liquibase"
    if liquibase_bin.is_file() and os.access(liquibase_bin, os.X_OK):
        console.print(f"[dim]==> Using cached Liquibase {spec.liquibase_version}[/dim]")
    else:
        tarball_url = (
            "https://github.com/liquibase/liquibase/releases/download/"
            f"v{spec.liquibase_version}/liquibase-{spec.liquibase_version}.tar.gz"
        )
        console.print(f"[bold]==> Downloading Liquibase {spec.liquibase_version}...[/bold]")
        try:
            with urllib.request.urlopen(tarball_url) as response:
                with tarfile.open(fileobj=response, mode="r|gz") as tar:
                    tar.extractall(path=cache)
        except Exception as exc:
            raise CleanError(f"could not download Liquibase: {exc}") from exc
        liquibase_bin.chmod(
            liquibase_bin.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH
        )
        console.print(f"[green]==> Liquibase cached at {cache}[/green]")
    driver_jar = cache / "drivers" / f"postgresql-{spec.pg_driver_version}.jar"
    if driver_jar.is_file():
        console.print("[dim]==> Using cached PostgreSQL JDBC driver[/dim]")
    else:
        driver_jar.parent.mkdir(parents=True, exist_ok=True)
        driver_url = (
            "https://jdbc.postgresql.org/download/"
            f"postgresql-{spec.pg_driver_version}.jar"
        )
        console.print(
            f"[bold]==> Downloading PostgreSQL JDBC driver {spec.pg_driver_version}...[/bold]"
        )
        try:
            with urllib.request.urlopen(driver_url) as response, driver_jar.open("wb") as handle:
                shutil.copyfileobj(response, handle)
        except Exception as exc:
            raise CleanError(f"could not download JDBC driver: {exc}") from exc
        console.print(f"[green]==> PostgreSQL driver cached at {driver_jar}[/green]")
    return liquibase_bin, driver_jar


def ensure_database(
    spec: MigrateSpec, db_name: str, admin_db_name: str, timeout: int
) -> None:
    """Ping the target database and create it via the admin DB if missing."""
    import psycopg

    target_error: Exception | None = None
    try:
        conn = psycopg.connect(
            libpq_conninfo(spec.db_url, db_name, timeout),
            user=spec.db_user,
            password=spec.db_pass,
            connect_timeout=timeout,
        )
    except Exception as exc:
        target_error = exc
        conn = None
    if conn is not None:
        conn.close()
        return
    try:
        admin = psycopg.connect(
            libpq_conninfo(spec.db_url, admin_db_name, timeout),
            user=spec.db_user,
            password=spec.db_pass,
            connect_timeout=timeout,
            autocommit=True,
        )
    except Exception as exc:
        raise CleanError(
            f"cannot connect to {db_name} ({target_error}) or to the maintenance "
            f"database {admin_db_name} ({exc}) — create the database manually, "
            "point --maintenance-db / DB_NAME at an existing database, "
            "or fix the URL/credentials."
        ) from exc
    with admin:
        with admin.cursor() as cur:
            cur.execute("SELECT 1 FROM pg_database WHERE datname = %s", (db_name,))
            exists = cur.fetchone() is not None
            if not exists:
                quoted = '"' + db_name.replace('"', '""') + '"'
                cur.execute(f"CREATE DATABASE {quoted}")


def load_manifests(changelog_dir: Path) -> list[ManifestEntry]:
    """Read every tenant manifest, skipping ``_templates``."""
    tenant_dir = changelog_dir / "tenant"
    if not tenant_dir.is_dir():
        return []
    manifests = sorted(tenant_dir.glob("*/manifest.xml"))
    entries: list[ManifestEntry] = []
    for manifest in manifests:
        alias = manifest.parent.name
        if alias == "_templates":
            continue
        try:
            root = ET.parse(manifest).getroot()
        except ET.ParseError as exc:
            raise CleanError(f"cannot parse manifest {manifest}: {exc}") from exc
        schema = (root.findtext("schema") or "").strip()
        if not schema:
            raise CleanError(f"Missing <schema> in manifest: {manifest}")
        entries.append(ManifestEntry(alias=alias, schema=schema))
    return entries


def resolve_schema(ref: str, manifests: list[ManifestEntry]) -> str:
    """Resolve a tenant alias or schema name to its schema."""
    for entry in manifests:
        if entry.alias == ref or entry.schema == ref:
            return entry.schema
    return ref


def resolve_alias(ref: str, manifests: list[ManifestEntry]) -> str | None:
    """Resolve a tenant ref to its manifest alias, if any."""
    schema = resolve_schema(ref, manifests)
    for entry in manifests:
        if entry.schema == schema:
            return entry.alias
    return None


def split_tenant_refs(value: str) -> list[str]:
    """Split a comma-separated tenant list, trimming blanks."""
    return [part.strip() for part in value.split(",") if part.strip()]


def load_client_mappings(path: Path) -> list[tuple[str, str]]:
    """Parse a ``tenant_id=client_id1,client_id2`` tenants file."""
    mappings: list[tuple[str, str]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.replace("\r", "")
        key, sep, value = line.partition("=")
        key = "".join(key.split())
        if key.startswith("#") or not key:
            continue
        if not sep or not value:
            value = key
        mappings.append((key, value))
    return mappings


def get_client_ids(
    ref: str,
    mappings: list[tuple[str, str]],
    manifests: list[ManifestEntry],
) -> list[str]:
    """Client ids for a tenant ref, defaulting to the ref itself."""
    schema = resolve_schema(ref, manifests)
    for tenant_id, clients in mappings:
        if tenant_id == ref or tenant_id == schema:
            return [c.strip() for c in clients.split(",") if c.strip()]
    return [ref]


def collect_template_uuids(templates_dir: Path) -> list[str]:
    """Sorted unique lowercase UUIDs across all template seed files."""
    found: set[str] = set()
    for path in list_changelog_files(templates_dir):
        found.update(UUID_RE.findall(path.read_text(encoding="utf-8")))
    return sorted(found)


def rewrite_logical_path(text: str, logical_path: str) -> str:
    """Point a seed file at its tenant-unique logicalFilePath."""
    if "logicalFilePath=" in text:
        return LOGICAL_PATH_RE.sub(
            f'logicalFilePath="{logical_path}"', text, count=1
        )
    return text.replace("<databaseChangeLog", f'<databaseChangeLog logicalFilePath="{logical_path}"', 1)


def bless_checksums(text: str) -> str:
    """Add ``<validCheckSum>ANY</validCheckSum>`` to changesets lacking one."""
    out: list[str] = []
    in_cs = False
    has_vc = False
    tag = ""
    buf: list[str] = []
    for line in text.splitlines(keepends=True):
        if CHANGESET_OPEN_RE.search(line):
            in_cs = True
            has_vc = False
            tag = line
            buf = []
            continue
        if in_cs and VALID_CHECKSUM_RE.search(line):
            has_vc = True
        if in_cs and CHANGESET_CLOSE_RE.search(line):
            out.append(tag)
            if not has_vc:
                out.append("        <validCheckSum>ANY</validCheckSum>\n")
            out.extend(buf)
            out.append(line)
            in_cs = False
            continue
        if in_cs:
            buf.append(line)
            continue
        out.append(line)
    return "".join(out)


def validate_spec(spec: MigrateSpec) -> tuple[Path, bool]:
    """Validate spec inputs, returning the changelog dir and global flag."""
    if not spec.db_url or not spec.db_user or not spec.db_pass:
        missing = [
            name
            for name, value in (
                ("DB_URL", spec.db_url),
                ("DB_USER", spec.db_user),
                ("DB_PASS", spec.db_pass),
            )
            if not value
        ]
        raise CleanError(f"missing required values: {', '.join(missing)}.")
    changelog_dir = spec.changelog_dir.resolve()
    if not changelog_dir.is_dir():
        raise CleanError(f"Changelog directory not found: {spec.changelog_dir}")
    if not (changelog_dir / MASTER_CHANGELOG).is_file():
        raise CleanError(
            f"{MASTER_CHANGELOG} not found in {changelog_dir} — "
            "directory does not follow the expected layout."
        )
    if spec.mode not in ("multi-schema", "single-schema"):
        raise CleanError("--mode must be 'multi-schema' or 'single-schema'.")
    if spec.changelog_type not in ("common", "tenant"):
        raise CleanError("--changelog-type must be 'common' or 'tenant'.")
    if spec.mode == "single-schema" and not spec.schema_name:
        raise CleanError("--schema-name is required for single-schema mode.")
    has_global = (changelog_dir / GLOBAL_MASTER_CHANGELOG).is_file()
    if has_global and not spec.app_name:
        raise CleanError(
            f"{GLOBAL_MASTER_CHANGELOG} exists (tenant_registry in use) — "
            "an application name (--app-name) is required."
        )
    if spec.tenants_file is not None and not spec.tenants_file.is_file():
        raise CleanError(f"Tenants file not found: {spec.tenants_file}")
    return changelog_dir, has_global


def run_subprocess(argv: list[str], env: dict[str, str], capture: bool) -> int:
    """Execute a child process, inheriting stdio unless capturing."""
    if capture:
        return subprocess.run(argv, env=env, capture_output=True, text=True).returncode
    return subprocess.run(argv, env=env).returncode


class Migration:
    """One migration run, mirroring liquibase-migrate.sh phase by phase."""

    def __init__(
        self,
        spec: MigrateSpec,
        console: Console,
        env: dict[str, str] | None = None,
    ) -> None:
        self.spec = spec
        self.console = console
        self.env = dict(os.environ if env is None else env)
        self.env.setdefault("LIQUIBASE_ANALYTICS_ENABLED", "false")
        self.env.setdefault("LIQUIBASE_ANALYTICS_CONFIG_ENDPOINT_TIMEOUT_MILLIS", "3000")
        self.env.setdefault("LIQUIBASE_ANALYTICS_TIMEOUT_MILLIS", "3000")
        self.temp_files: list[Path] = []
        self.success = 0
        self.failed = 0
        self.failed_tenants: list[str] = []
        self.changelog_dir = spec.changelog_dir.resolve()
        self.manifests: list[ManifestEntry] = []
        self.mappings: list[tuple[str, str]] = []
        self.liquibase_bin = Path()
        self.driver_jar = Path()
        self.db_url = spec.db_url

    def lb_opts(self) -> list[str]:
        """Global Liquibase flags, with debug log level when requested."""
        level = "debug" if self.spec.debug else "warning"
        return [
            "--show-banner=false",
            f"--log-level={level}",
            f"--changelog-lock-wait-time-in-minutes={self.spec.lock_wait_minutes}",
        ]

    def run_lb(self, args: list[str], capture: bool = False) -> int:
        """Invoke the Liquibase CLI, optionally capturing output."""
        argv = [
            str(self.liquibase_bin),
            *self.lb_opts(),
            f"--classpath={self.driver_jar}",
            *args,
        ]
        if capture:
            return run_subprocess(argv, self.env, True)
        return run_subprocess(argv, self.env, False)

    def release_stale_lock(self, base_args: list[str]) -> None:
        """Best-effort release of a lock stranded by an interrupted run."""
        self.run_lb([*base_args, "release-locks"], capture=not self.spec.debug)

    def track_temp(self, path: Path) -> Path:
        """Register a temp file for cleanup at the end of the run."""
        self.temp_files.append(path)
        return path

    def cleanup(self) -> None:
        """Remove every staged temp file."""
        for path in self.temp_files:
            try:
                if path.is_file():
                    path.unlink()
            except OSError:
                pass
        self.temp_files.clear()

    def stage_template_seed(
        self, tenant_id: str, generated_master: Path, templates_dir: Path
    ) -> None:
        """Stage template seeds as tenant-unique temp copies."""
        if not templates_dir.is_dir():
            return
        mapping = {old: str(uuid.uuid4()) for old in collect_template_uuids(templates_dir)}
        with generated_master.open("a", encoding="utf-8") as master:
            for num, path in enumerate(list_changelog_files(templates_dir), start=1):
                logical_path = f"tenant/{tenant_id}/seed/{path.name}"
                staged = Path(
                    tempfile.NamedTemporaryFile(
                        delete=False,
                        dir=self.changelog_dir,
                        prefix=f"liquibase-tenant-seed-{tenant_id}-{num}-",
                        suffix=".xml",
                    ).name
                )
                self.track_temp(staged)
                text = rewrite_logical_path(
                    path.read_text(encoding="utf-8"), logical_path
                )
                for old, new in mapping.items():
                    text = text.replace(old, new)
                staged.write_text(bless_checksums(text), encoding="utf-8")
                master.write(f'    <include file="{staged.name}" relativeToChangelogFile="false"/>\n')

    def generate_tenant_changelog(
        self, target_schema: str, tenant_ref: str, tenant_id: str
    ) -> Path:
        """Build the per-tenant master changelog for one run."""
        alias: str | None = None
        if (self.changelog_dir / "tenant" / tenant_ref).is_dir():
            alias = tenant_ref
        else:
            alias = resolve_alias(tenant_ref, self.manifests)
        generated = Path(
            tempfile.NamedTemporaryFile(
                delete=False,
                dir=self.changelog_dir,
                prefix="liquibase-tenant-master-",
                suffix=".xml",
            ).name
        )
        self.track_temp(generated)
        generated.write_text(
            '<?xml version="1.0" encoding="UTF-8"?>\n'
            '<databaseChangeLog xmlns="http://www.liquibase.org/xml/ns/dbchangelog"\n'
            '                   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"\n'
            '                   xsi:schemaLocation="http://www.liquibase.org/xml/ns/dbchangelog\n'
            '                       https://www.liquibase.org/xml/ns/dbchangelog/dbchangelog-4.20.xsd">\n'
            f'    <property name="tenantId" value="{tenant_id}"/>\n'
            f'    <property name="targetSchema" value="{target_schema}"/>\n',
            encoding="utf-8",
        )
        with generated.open("a", encoding="utf-8") as master:
            if alias is not None:
                tenant_dir = self.changelog_dir / "tenant" / alias
                for path in [
                    *list_changelog_files(tenant_dir / "migration"),
                    *list_changelog_files(tenant_dir / "seed"),
                ]:
                    relative = path.relative_to(self.changelog_dir).as_posix()
                    master.write(f'    <include file="{relative}" relativeToChangelogFile="false"/>\n')
            else:
                self.stage_template_seed(
                    tenant_id, generated, self.changelog_dir / "tenant/_templates/seed"
                )
            master.write("</databaseChangeLog>\n")
        return generated

    def migration_url(self, schema_name: str, tenant_id: str) -> str:
        """Tenant-pinned JDBC URL carrying currentSchema and app.tenant_id."""
        sep = "&" if "?" in self.db_url else "?"
        url = f"{self.db_url}{sep}currentSchema={schema_name},public"
        if tenant_id:
            url += f"&options=-c%20app.tenant_id%3D{tenant_id}"
        return url

    def base_auth_args(self, url: str) -> list[str]:
        """URL plus credentials preamble shared by every invocation."""
        return [
            f"--url={url}",
            f"--username={self.spec.db_user}",
            f"--password={self.spec.db_pass}",
        ]

    def run_tenant_migration(
        self, schema_name: str, tenant_ref: str, tenant_id: str, changelog_file: str
    ) -> None:
        """Release lock, ensure schema, clear checksums, and update once."""
        search_path = self.changelog_dir
        active_file = changelog_file
        if changelog_file == TENANT_MASTER_CHANGELOG:
            generated = self.generate_tenant_changelog(schema_name, tenant_ref, tenant_id)
            search_path = generated.parent
            active_file = generated.name
        lb_args = [
            *self.base_auth_args(self.migration_url(schema_name, tenant_id)),
            f"--search-path={search_path}",
            f"--changelog-file={active_file}",
            f"--default-schema-name={schema_name}",
            f"--liquibase-schema-name={schema_name}",
        ]
        label = tenant_id if tenant_id else "<none>"
        self.console.print(f"--> [{schema_name}] Releasing any stale changelog lock...")
        self.release_stale_lock(lb_args)
        self.console.print(f"--> [{schema_name}] Creating schema if not exists...")
        quoted = '"' + schema_name.replace('"', '""') + '"'
        self.run_lb(
            [
                *self.base_auth_args(self.db_url),
                "execute-sql",
                f'--sql=CREATE SCHEMA IF NOT EXISTS {quoted}',
            ]
        )
        self.console.print(f"--> [{schema_name}] Clearing checksums...")
        ok = False
        if self.run_lb([*lb_args, "clearCheckSums"]) == 0:
            self.console.print(f"--> [{schema_name}] Running migrations (tenant_id={label})...")
            ok = self.run_lb([*lb_args, "update"]) == 0
        if ok:
            self.console.print(f"--> OK: {schema_name} ({label})")
            self.success += 1
        else:
            self.console.print(f"--> FAILED: {schema_name} ({label})")
            self.failed += 1
            self.failed_tenants.append(f"{schema_name}:{tenant_id}")

    def run_global_migration(self, has_global: bool) -> None:
        """Run the public-schema control changelog once per database."""
        if not has_global:
            return
        sep = "&" if "?" in self.db_url else "?"
        global_url = f"{self.db_url}{sep}currentSchema=public"
        user = self.spec.db_user
        quoted_user = '"' + user.replace('"', '""') + '"'
        self.console.print("==> Ensuring privileges on public schema...")
        self.run_lb(
            [
                *self.base_auth_args(global_url),
                "execute-sql",
                f"--sql=GRANT ALL ON SCHEMA public TO {quoted_user}; "
                "GRANT ALL ON SCHEMA public TO public;",
            ],
            capture=True,
        )
        self.console.print(
            f"==> Running global changelog '{GLOBAL_MASTER_CHANGELOG}' against public schema..."
        )
        self.run_lb(
            [
                *self.base_auth_args(global_url),
                f"--search-path={self.changelog_dir}",
                f"--changelog-file={GLOBAL_MASTER_CHANGELOG}",
                "--default-schema-name=public",
                "--liquibase-schema-name=public",
                "update",
            ]
        )

    def upsert_registry(
        self, has_global: bool, schema_name: str, tenant_id: str, clients: list[str]
    ) -> None:
        """Register tenant client mappings, preserving manual rotations."""
        if not has_global or not tenant_id:
            return
        for client_id in clients:
            self.console.print(
                f"--> [{schema_name}] Registering tenant_registry mapping "
                f"(client_id={client_id} -> tenant_id={tenant_id}, app={self.spec.app_name})..."
            )
            sql = (
                "INSERT INTO public.tenant_registry "
                "(client_id, application_name, tenant_id, schema_name) VALUES "
                f"('{client_id}', '{self.spec.app_name}', '{tenant_id}', '{schema_name}') "
                "ON CONFLICT (client_id, application_name) DO NOTHING"
            )
            self.run_lb([*self.base_auth_args(self.db_url), "execute-sql", f"--sql={sql}"])

    def resolve_targets(self) -> list[TenantTarget]:
        """Resolve tenant refs to schemas, ids, and client mappings."""
        refs = list(self.spec.tenants)
        if not refs and self.mappings:
            refs = [tenant_id for tenant_id, _ in self.mappings]
        targets: list[TenantTarget] = []
        for ref in refs:
            if self.spec.mode == "single-schema":
                tenant_id = self.spec.tenant_id_override or ref
                targets.append(
                    TenantTarget(
                        ref=ref,
                        schema=self.spec.schema_name,
                        tenant_id=tenant_id,
                        clients=get_client_ids(ref, self.mappings, self.manifests),
                    )
                )
            else:
                schema = resolve_schema(ref, self.manifests)
                tenant_id = self.spec.tenant_id_override or schema
                targets.append(
                    TenantTarget(
                        ref=ref,
                        schema=schema,
                        tenant_id=tenant_id,
                        clients=get_client_ids(ref, self.mappings, self.manifests),
                    )
                )
        return targets

    def run_single_schema(self, has_global: bool, targets: list[TenantTarget]) -> int:
        """Shared-schema flow: common DDL once, then per-tenant seeds."""
        if self.spec.tenant_id_override and len(targets) > 1:
            raise CleanError(
                "TENANT_ID/--tenant-id override can only be used when targeting a single tenant."
            )
        needs_tenants = self.spec.changelog_type == "tenant" or self.spec.with_seed
        if needs_tenants and not targets:
            raise CleanError(
                "tenant seed runs require --tenant <alias-or-schema>[,...] "
                "or a --tenants-file with entries."
            )
        if self.spec.changelog_type == "common" or self.spec.with_seed:
            self.console.print(
                f"==> Single-schema mode: running schema migrations once "
                f"for shared schema '{self.spec.schema_name}'"
            )
            first = targets[0] if targets else None
            self.run_tenant_migration(
                self.spec.schema_name,
                first.ref if first else self.spec.schema_name,
                first.tenant_id if first else "",
                MASTER_CHANGELOG,
            )
        if needs_tenants and self.failed == 0:
            for target in targets:
                self.console.print("")
                self.console.print(
                    f"==> Seeding tenant '{target.ref}' (tenant_id={target.tenant_id}) "
                    f"into shared schema '{self.spec.schema_name}'"
                )
                self.run_tenant_migration(
                    self.spec.schema_name,
                    target.ref,
                    target.tenant_id,
                    TENANT_MASTER_CHANGELOG,
                )
        if self.failed == 0 and targets:
            for target in targets:
                self.upsert_registry(
                    has_global, self.spec.schema_name, target.tenant_id, target.clients
                )
        self.console.print("")
        self.console.print(
            f"==> Single-schema migration complete for '{self.spec.schema_name}'. "
            f"Success: {self.success}, Failed: {self.failed}"
        )
        if self.failed:
            self.console.print(f"==> Failed runs: {' '.join(self.failed_tenants)}")
            return 1
        return 0

    def run_multi_schema(
        self, has_global: bool, targets: list[TenantTarget], requested: list[str]
    ) -> int:
        """Per-tenant-schema flow with optional seed phases."""
        if not targets:
            raise CleanError(
                "no tenants to migrate — provide --tenant <alias-or-schema>[,...] "
                "or --tenants-file with entries."
            )
        if self.spec.tenant_id_override and len(targets) > 1:
            raise CleanError(
                "TENANT_ID/--tenant-id override can only be used when targeting a single tenant."
            )
        if self.spec.with_seed:
            self.console.print(
                f"==> Running schema + seed for {len(targets)} tenant(s): "
                f"{' '.join(requested)}"
            )
            for target in targets:
                self.console.print("")
                self.console.print(f"==> Processing tenant: {target.schema}")
                self.console.print("--> Phase 1: Running schema migrations...")
                self.run_tenant_migration(
                    target.schema, target.ref, target.tenant_id, MASTER_CHANGELOG
                )
                if f"{target.schema}:" not in [
                    entry.rsplit(":", 1)[0] + ":" for entry in self.failed_tenants
                ]:
                    self.console.print("--> Phase 2: Running seed data...")
                    self.run_tenant_migration(
                        target.schema,
                        target.ref,
                        target.tenant_id,
                        TENANT_MASTER_CHANGELOG,
                    )
                else:
                    self.console.print("--> Skipping seed data due to schema migration failure")
                self.upsert_registry(
                    has_global, target.schema, target.tenant_id, target.clients
                )
        else:
            changelog_file = (
                TENANT_MASTER_CHANGELOG
                if self.spec.changelog_type == "tenant"
                else MASTER_CHANGELOG
            )
            self.console.print(
                f"==> Running {self.spec.changelog_type} changelog '{changelog_file}' "
                f"for {len(targets)} tenant(s): {' '.join(requested)}"
            )
            for target in targets:
                self.console.print("")
                self.run_tenant_migration(
                    target.schema, target.ref, target.tenant_id, changelog_file
                )
                self.upsert_registry(
                    has_global, target.schema, target.tenant_id, target.clients
                )
        self.console.print("")
        self.console.print(
            f"==> Migration complete. Success: {self.success}, "
            f"Failed: {self.failed}, Total: {len(targets)}"
        )
        if self.failed:
            self.console.print(f"==> Failed tenants: {' '.join(self.failed_tenants)}")
            return 1
        return 0

    def describe_plan(self, targets: list[TenantTarget]) -> list[str]:
        """Human-readable phase list for ``--dry-run`` without side effects."""
        _, db_name, _ = split_db_url(self.spec.db_url)
        lines = [
            f"Mode: {self.spec.mode} | Changelog dir: {self.changelog_dir}",
            f"Database: {db_name} (create via '{self.spec.admin_db_name}' if missing)",
            f"Tenants ({len(targets)}): "
            + (
                ", ".join(
                    f"{t.ref}->{t.schema} [{t.tenant_id}] clients={','.join(t.clients)}"
                    for t in targets
                )
                or "<none>"
            ),
        ]
        if self.spec.mode == "single-schema":
            if self.spec.changelog_type == "common" or self.spec.with_seed:
                lines.append(f"Phase 1: {MASTER_CHANGELOG} once into '{self.spec.schema_name}'")
            if self.spec.changelog_type == "tenant" or self.spec.with_seed:
                staged = "template fallback" if not any(
                    (self.changelog_dir / "tenant" / t.ref).is_dir()
                    or resolve_alias(t.ref, self.manifests) is not None
                    for t in targets
                ) else "tenant dirs"
                lines.append(
                    f"Phase 2: {TENANT_MASTER_CHANGELOG} per tenant ({staged})"
                )
        elif self.spec.with_seed:
            lines.append(f"Per tenant: {MASTER_CHANGELOG} then {TENANT_MASTER_CHANGELOG}")
        else:
            name = (
                TENANT_MASTER_CHANGELOG
                if self.spec.changelog_type == "tenant"
                else MASTER_CHANGELOG
            )
            lines.append(f"Per tenant: {name}")
        return lines


def describe_dry_run(spec: MigrateSpec) -> list[str]:
    """Plan lines for ``--dry-run`` without downloads, DB, or temp files."""
    changelog_dir, _ = validate_spec(spec)
    spec.changelog_dir = changelog_dir
    if spec.liquibase_bin is not None and spec.driver_jar is not None:
        tool_line = f"Liquibase: {spec.liquibase_bin} (explicit)"
    else:
        cache = spec.cache_dir or (
            default_cache_dir() / f"liquibase-{spec.liquibase_version}"
        )
        cached = (cache / "liquibase").is_file() and (
            cache / "drivers" / f"postgresql-{spec.pg_driver_version}.jar"
        ).is_file()
        tool_line = (
            f"Liquibase {spec.liquibase_version}: "
            f"{'cached at ' + str(cache) if cached else 'will download on run'}"
        )
    migration = Migration(spec, Console())
    migration.manifests = load_manifests(changelog_dir)
    if spec.tenants_file is not None:
        migration.mappings = load_client_mappings(spec.tenants_file)
    targets = migration.resolve_targets()
    if spec.tenant_id_override and len(targets) > 1:
        raise CleanError(
            "TENANT_ID/--tenant-id override can only be used when targeting a single tenant."
        )
    if spec.mode == "single-schema":
        if (spec.changelog_type == "tenant" or spec.with_seed) and not targets:
            raise CleanError(
                "tenant seed runs require --tenant <alias-or-schema>[,...] "
                "or a --tenants-file with entries."
            )
    elif not targets:
        raise CleanError(
            "no tenants to migrate — provide --tenant <alias-or-schema>[,...] "
            "or --tenants-file with entries."
        )
    return [tool_line, *migration.describe_plan(targets)]


def run_migrate(spec: MigrateSpec, console: Console) -> int:
    """Execute the full migration flow, returning a process exit code."""
    changelog_dir, has_global = validate_spec(spec)
    spec.changelog_dir = changelog_dir
    migration = Migration(spec, console)
    try:
        migration.db_url, applied = apply_connect_timeout(
            spec.db_url, spec.connect_timeout
        )
        if applied:
            console.print(
                f"==> Applied connectTimeout={spec.connect_timeout}s "
                f"(effective DB_URL: {migration.db_url})"
            )
        _, db_name, _ = split_db_url(migration.db_url)
        timeout = int(spec.connect_timeout)
        migration.liquibase_bin, migration.driver_jar = ensure_tools(spec, console)
        console.print(
            f"==> Ensuring database '{db_name}' exists "
            f"(maintenance database: '{spec.admin_db_name}')"
        )
        ensure_database(spec, db_name, spec.admin_db_name, timeout)
        migration.manifests = load_manifests(changelog_dir)
        console.print("Releasing any stale changelog lock in the default schema...")
        migration.release_stale_lock(migration.base_auth_args(migration.db_url))
        migration.run_global_migration(has_global)
        if spec.tenants_file is not None:
            migration.mappings = load_client_mappings(spec.tenants_file)
        requested = list(spec.tenants)
        targets = migration.resolve_targets()
        if spec.mode == "single-schema":
            return migration.run_single_schema(has_global, targets)
        return migration.run_multi_schema(has_global, targets, requested or [t.ref for t in targets])
    finally:
        migration.cleanup()
